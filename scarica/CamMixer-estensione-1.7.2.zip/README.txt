CAMMIXER - extension for Chrome and Edge

Creates virtual webcams with effects and backgrounds and makes them available to websites:
video chats, Meet, Teams on the web and so on. Websites need no drivers or external programs.
With a small program for Windows 11 or macOS (optional, see below) the virtual webcam also
reaches Microsoft Teams desktop, Zoom and the other apps on the computer.

LANGUAGE
The interface is in English. Use the flags at the top of the settings page (or in the panel
inside websites) to switch to Italian; the choice applies everywhere, also to the programs.

All CamMixer releases (extension, Windows installer, macOS program) are in
https://github.com/BBerry2020/cammixer-releases
On Windows the CamMixer-Setup installer is enough: it also contains the extension and keeps it
up to date (see below); the following steps are only for those who install the extension by hand.

INSTALLATION
1. Download CamMixer-estensione-<version>.zip from cammixer-releases and extract it to a folder
   you will not move (for example Documents\CamMixer).
2. Open chrome://extensions (in Edge: edge://extensions).
3. Turn on "Developer mode".
4. Click "Load unpacked" and choose the extracted folder (the one that contains manifest.json).
5. The settings page opens: allow access to the webcam.
   Pin the extension icon to the toolbar to find the settings again.
Updates: the settings ("Version and components" box) tell you when cammixer-releases has a new
version. Download the zip and extract it to the same folder, overwriting the files: the extension
reloads itself and the settings stay. On Windows the CamMixer program does this.

SETTINGS
The preview of the virtual webcam stays at the top while you scroll the settings, so you see
every change at once; the real webcam is the small picture at the side.

USE IN A VIDEO CHAT
- The virtual webcam labelled "in websites" replaces the real webcam in all websites: websites
  only see the virtual webcams and get it even if they had remembered the real webcam.
- The browser's camera menu (icon in the address bar) only shows the real webcams: that is
  normal, no need to touch it.
- On websites that let you choose the camera, the virtual webcams appear in the list with their name.
- During the chat, a panel appears at the bottom right to change background and effects on the fly.
  It can be collapsed to a pill and moved by dragging its title.
- If a website was already open when you installed or updated the extension, reload it.
- To use the real webcam again, untick "Use it in websites instead of the real webcam":
  the extension becomes invisible to websites.

BACKGROUNDS, EFFECTS AND ELEMENTS
- Animated backgrounds: neon grid, starfield, ring tunnel, northern lights, oscilloscope,
  lava lamp, plasma, VHS noise; retro computers: green phosphor terminal, CGA graphics
  (4 colours), EGA graphics (16 colours), digital rain; or blurred, solid colour or your own image.
- Video effects: TV scanlines, glitch, film grain, vignette; retro: green phosphor monitor,
  CGA palette (4 colours) and EGA palette (16 colours), with the dithering of the time.
- Overlay elements (up to 12): texts, emoji and your images (transparent PNGs too), with
  position, size and animation (pulse, bounce, float, spin, blink, scroll, rainbow).
- Reset: "Reset effects" (also from the panel in the chat), "Reset all" for one webcam,
  "Reset the extension" at the bottom of the page to start from scratch.

BACKGROUND BEHIND YOU
The person cut-out uses MediaPipe (included in the extension). The model is downloaded from the
Internet only once, the first time, and then stays in the cache.
- Cut-out sensitivity: higher removes more background (no halo around you); if parts of you
  disappear (hair, shoulders), lower it. It is also in the panel during the chat.
- Soft edge: softens or sharpens the outline.
- Stability: reduces outline flicker, with a slight delay in movements.

LOWER THIRD (TV NEWS STYLE)
- Label, name, role, headline, scrolling ticker (news items separated by |) and time.
- Styles: Breaking news, TV news, Minimal, Neon, Sport.
- It can be moved and resized: drag it on the preview in the settings or use the Horizontal,
  Vertical and Size sliders. The scrolling ticker stays at the bottom.
  The chat panel has "Lower third height".
- Texts, emoji and images can also be dragged directly on the preview.

3D EXAMPLES (OPTIONAL)
In the settings, box "3D examples (experimental)", tick "Turn on the 3D examples". You get:
- backgrounds: 3D TV studio, 3D crystals;
- effects: Glow, CRT monitor, Chromatic aberration (computed by the graphics card);
- 3D object on your face (a single control under the effects): None, Glasses, Crown or Robot
  (it covers the face and follows eyes and mouth), with its size; the first time it downloads
  the MediaPipe face model;
- Rotating 3D logo: free text or your own image (otherwise the overlay text or the webcam's
  name); the slider sets its size, and "Rotation" turns the content to straighten it
  (double-click the slider to go back to 0).
They use the graphics card: on a computer without graphics acceleration the video may slow
down; if the graphics card is not available the example turns itself off. Untick the box to
hide them again.

COMPONENTS UPDATABLE ON THE FLY
Animated backgrounds, effects and animations are in componenti\componenti.js. When that file
changes, the extension reloads it by itself (within a few seconds with the settings open,
within about 10 seconds in open chats): no "Reload", settings untouched.
If the new file contains an error the previous components stay active; if a single component
fails it is turned off and the others go on.
The engine (the other files) updates itself too: when it changes, the extension reloads
automatically as soon as no chat is using a virtual webcam; the settings stay and the settings
page, if it was open, opens again. Chats already open must be reloaded to use the new engine
(the panel says so; the video keeps going in the meantime).

TEAMS DESKTOP, ZOOM AND THE OTHER APPS ON THE COMPUTER
The computer's apps do not see webcams that exist only in the browser. The installers are in
https://github.com/BBerry2020/cammixer-releases.

Windows 11 - "CamMixer" system webcam:
1. Only once: download and run CamMixer-Setup-<version>.exe and answer Yes to the Windows
   prompt (administrator permission is needed). The installer asks for the language (English
   or Italian), explains what it installs and shows the versions of Windows, Edge, Chrome and
   Teams it finds, with the camera privacy settings; they are saved in
   C:\Program Files\CamMixer\install.log, useful for troubleshooting. It also contains this extension: it copies it to Documents\CamMixer or
   Documents\webcam-virtuali (if it already exists) or to AppData\Local\CamMixer\estensione and
   updates it at every version; the first time it must be loaded in Edge ("Load unpacked"): a
   guide opens at the end. The installer is not signed: if "Windows protected your PC" appears,
   choose More info > Run anyway.
   The video source and the bridge program CamMixer.exe (no windows) are installed in
   C:\Program Files\CamMixer; from then on the program starts by itself at every Windows sign-in.
2. In Teams: Settings > Devices > Camera > "CamMixer (Windows Virtual Camera)".
3. In the extension settings, box "Webcam for Teams, Zoom and the other apps on the computer",
   choose which virtual webcam to send (normally the one used in websites) and check the status.
How it works: when an app opens "CamMixer", the extension turns on the real webcam, applies
background and effects and sends the video to the bridge program (on the PC only, address
127.0.0.1); when the app closes it, the real webcam turns off. Microsoft Edge must be open: if
it is closed, the app shows a message instead of the video.
If the status says "access denied": Windows Settings > Privacy & security > Camera, turn on
camera access and access for desktop apps.
Tip: in Edge, Settings > System and performance, turn on "Continue running background extensions
and apps when Microsoft Edge is closed": the video then arrives even with the windows closed.
Updates: when a new version comes out, the box shows "Open the releases page": download
CamMixer-Setup-<version>.exe and run it (the program does not update itself).
To uninstall: Windows Settings > Apps > CamMixer > Uninstall.

macOS - with the OBS Studio virtual camera (system webcams for the Mac need a paid Apple
signature):
1. Install OBS Studio (https://obsproject.com).
2. In Terminal:
   curl -fsSL https://raw.githubusercontent.com/BBerry2020/cammixer-releases/main/installa-mac.sh | bash
   It installs the bridge program for your user (no administrator) and copies the address for
   OBS to the clipboard (you also find it in the extension settings).
3. In OBS: Sources > + > Browser, paste the address, 1280x720, fit to screen; then
   "Start Virtual Camera". In Teams choose "OBS Virtual Camera".
The macOS program updates itself.

NOTES
- The settings are shared by all websites and between the panel and the settings page.
- On some company PCs unpacked extensions are blocked by the organisation's policies.
