/*
 * CamMixer - COMPONENTI
 *
 * Sfondi animati, effetti e animazioni degli elementi.
 * Questo file si può modificare o sostituire mentre l'estensione è in uso:
 * l'estensione se ne accorge entro pochi secondi e lo ricarica al volo nella
 * pagina delle impostazioni e nelle chat aperte, senza riavvio e senza
 * toccare le impostazioni salvate.
 *
 * Regole:
 * - "versione" è un'etichetta libera, mostrata nelle impostazioni.
 * - Ogni componente ha un id (minuscole, cifre e trattini) e un'etichetta.
 * - sfondi:     draw(o, W, H, t, stato)  disegna l'intero fotogramma (t in secondi)
 * - effetti:    apply({ o, W, H, k, out, canvas, stato })  k = intensità 0..1
 * - animazioni: apply({ t, now, W, H, size, width })  restituisce
 *               { dx, dy, x, scale, rot, hidden, color } (tutti facoltativi)
 * - sottopancia: blocco(o, W, H, t, testi, stato) disegna nome, ruolo e notizia e
 *               restituisce il riquadro { x, y, w, h } (spostabile dall'utente);
 *               striscia(o, W, H, t, testi, stato) disegna la striscia che scorre.
 *               testi = { etichetta, nome, ruolo, notizia, scorrimento (elenco), ora }
 * - "stato" è un oggetto privato del componente per ogni webcam virtuale.
 * Se un componente genera un errore viene disattivato da solo; gli altri continuano.
 * - tre_d: true   esempio 3D (Three.js): elencato solo se «Esempi 3D» è attivo nelle impostazioni;
 *                 U.risorsa('three/three.module.js') dà l'indirizzo della libreria nell'estensione.
 * - volto: true   (effetti) il motore cerca il volto e passa { punti, matrice, espressioni } in «volto».
 */
(() => {
  'use strict';
  const C = typeof WebcamVirtualiCore !== 'undefined' ? WebcamVirtualiCore : null;
  if (!C || typeof C.register !== 'function') return;
  const U = C.util;
  // texts shown on the video, translated into the chosen language (lingua.js)
  const tr = (s, v) => (U.T ? U.T(s, v) : s);

  // -------------------------------------------------------------------
  // Sfondi
  // -------------------------------------------------------------------
    function drawSynthwave(o, W, H, t) {
      const horizon = H * 0.58;
      const sky = o.createLinearGradient(0, 0, 0, horizon);
      sky.addColorStop(0, '#0d0221');
      sky.addColorStop(0.6, '#3b0a57');
      sky.addColorStop(1, '#c2186b');
      o.fillStyle = sky;
      o.fillRect(0, 0, W, horizon);

      const r = H * 0.22, cx = W / 2, cy = horizon - r * 0.2;
      o.save();
      o.beginPath();
      o.arc(cx, cy, r, 0, Math.PI * 2);
      o.clip();
      const sun = o.createLinearGradient(0, cy - r, 0, cy + r);
      sun.addColorStop(0, '#ffe66d');
      sun.addColorStop(1, '#ff2e97');
      o.fillStyle = sun;
      o.fillRect(cx - r, cy - r, 2 * r, 2 * r);
      o.fillStyle = sky;
      const step = r * 0.12, top = cy - r * 0.55;
      for (let i = 0; i < 7; i++) {
        const y = top + i * step + ((t * 8) % step);
        o.fillRect(cx - r, y, 2 * r, (1.5 + i * 1.5) * (H / 720));
      }
      o.restore();

      const ground = o.createLinearGradient(0, horizon, 0, H);
      ground.addColorStop(0, '#1a0633');
      ground.addColorStop(1, '#05010d');
      o.fillStyle = ground;
      o.fillRect(0, horizon, W, H - horizon);
      o.save();
      o.beginPath();
      o.rect(0, horizon, W, H - horizon);
      o.clip();
      o.beginPath();
      const phase = (t * 0.7) % 1;
      for (let i = 0; i < 22; i++) {
        const z = i + 1 - phase;
        if (z < 0.6) continue;
        const y = horizon + (H - horizon) / z;
        o.moveTo(0, y);
        o.lineTo(W, y);
      }
      for (let j = -16; j <= 16; j++) {
        o.moveTo(cx + j * W * 0.01, horizon);
        o.lineTo(cx + j * W * 0.14, H);
      }
      const lw = Math.max(1, H / 400);
      o.strokeStyle = 'rgba(255, 60, 172, 0.22)';   // alone
      o.lineWidth = lw * 5;
      o.stroke();
      o.strokeStyle = '#ff3cac';
      o.lineWidth = lw;
      o.stroke();
      o.restore();
      o.fillStyle = '#ff9ad5';
      o.fillRect(0, horizon - 1, W, Math.max(2, H / 360));
    }

    function newStar(anyDepth) {
      return { x: Math.random() * 2 - 1, y: (Math.random() * 2 - 1) * 0.6, z: anyDepth ? Math.random() : 1, h: 180 + Math.random() * 140 };
    }

    function drawStars(o, W, H, t, st) {
      if (!st.stars) { st.stars = Array.from({ length: 420 }, () => newStar(true)); st.last = t; }
      const dt = Math.min(0.1, Math.max(0, t - st.last));
      st.last = t;
      o.fillStyle = '#02010a';
      o.fillRect(0, 0, W, H);
      const cx = W / 2, cy = H / 2, fov = W * 0.6;
      o.lineCap = 'round';
      for (const s of st.stars) {
        const pz = s.z;
        s.z -= dt * 0.45;
        if (s.z <= 0.02) { Object.assign(s, newStar(false)); continue; }
        const x = cx + (s.x / s.z) * fov, y = cy + (s.y / s.z) * fov;
        if (x < -50 || x > W + 50 || y < -50 || y > H + 50) { Object.assign(s, newStar(false)); continue; }
        const px = cx + (s.x / pz) * fov, py = cy + (s.y / pz) * fov;
        const b = Math.min(1, (1 - s.z) * 1.3);
        o.strokeStyle = `hsla(${s.h}, 90%, ${60 + 30 * b}%, ${b})`;
        o.lineWidth = Math.max(1, (1 - s.z) * 3 * (H / 720));
        o.beginPath();
        o.moveTo(px, py);
        o.lineTo(x, y);
        o.stroke();
      }
    }

    function drawPlasma(o, W, H, t, st) {
      const pw = 160, ph = 90;
      if (!st.c) { st.c = U.makeCanvas(pw, ph); st.x = st.c.getContext('2d'); st.img = st.x.createImageData(pw, ph); }
      const d = st.img.data, k = Math.PI * 2;
      for (let y = 0; y < ph; y++) {
        for (let x = 0; x < pw; x++) {
          const u = (x / pw) * 6, v = (y / ph) * 4;
          const val = Math.sin(u + t) + Math.sin((v + t * 0.7) * 1.3) + Math.sin(u + v + t * 0.5)
            + Math.sin(Math.hypot(u - 3 + Math.sin(t * 0.3) * 2, v - 2) * 1.5 - t);
          const c = (val + 4) / 8, i = (y * pw + x) * 4;
          d[i] = 120 + 120 * Math.sin(k * c);
          d[i + 1] = 30 + 30 * Math.sin(k * c + 2.1);
          d[i + 2] = 150 + 105 * Math.sin(k * c + 4.2);
          d[i + 3] = 255;
        }
      }
      st.x.putImageData(st.img, 0, 0);
      o.imageSmoothingEnabled = true;
      o.drawImage(st.c, 0, 0, W, H);
    }

    function drawVhs(o, W, H, t, st) {
      const nw = 320, nh = 180;
      if (!st.c) { st.c = U.makeCanvas(nw, nh); st.x = st.c.getContext('2d'); st.img = st.x.createImageData(nw, nh); }
      const d = st.img.data;
      for (let i = 0; i < d.length; i += 4) {
        const v = Math.random() * 190;
        d[i] = v * 0.85; d[i + 1] = v * 0.9; d[i + 2] = v; d[i + 3] = 255;
      }
      st.x.putImageData(st.img, 0, 0);
      o.imageSmoothingEnabled = false;
      o.drawImage(st.c, 0, 0, W, H);
      o.imageSmoothingEnabled = true;
      o.fillStyle = 'rgba(0, 0, 0, 0.25)';
      for (let y = 0; y < H; y += 4) o.fillRect(0, y, W, 2);
      const band = H * 0.06, by = ((t * 0.25) % 1) * (H + 4 * band) - 2 * band;
      const g = o.createLinearGradient(0, by - band, 0, by + band);
      g.addColorStop(0, 'rgba(255, 255, 255, 0)');
      g.addColorStop(0.5, 'rgba(255, 255, 255, 0.18)');
      g.addColorStop(1, 'rgba(255, 255, 255, 0)');
      o.fillStyle = g;
      o.fillRect(0, by - band, W, 2 * band);
      o.fillStyle = 'rgba(40, 0, 80, 0.18)';
      o.fillRect(0, 0, W, H);
    }

    // Tunnel di anelli al neon che vengono incontro
    function drawTunnel(o, W, H, t) {
      o.fillStyle = '#05000f';
      o.fillRect(0, 0, W, H);
      const cx = W / 2 + Math.sin(t * 0.6) * W * 0.06, cy = H / 2 + Math.cos(t * 0.5) * H * 0.06;
      const N = 18, R = Math.hypot(W, H) * 0.75;
      for (let i = 0; i < N; i++) {
        const z = ((i + t * 1.1) % N) / N;                       // 0 lontano, 1 vicino
        const r = Math.pow(z, 2.4) * R;
        if (r < 2) continue;
        const hue = (i * 22 + t * 50) % 360, a = Math.min(1, z * 1.4), lw = 1 + z * H * 0.025;
        o.beginPath();
        o.arc(cx, cy, r, 0, Math.PI * 2);
        o.strokeStyle = `hsla(${hue}, 95%, 60%, ${a * 0.22})`;   // alone
        o.lineWidth = lw * 4;
        o.stroke();
        o.strokeStyle = `hsla(${hue}, 95%, 68%, ${a})`;
        o.lineWidth = lw;
        o.stroke();
      }
    }

    // Aurora boreale su cielo stellato, con profilo di montagne
    function drawAurora(o, W, H, t, st) {
      const sky = o.createLinearGradient(0, 0, 0, H);
      sky.addColorStop(0, '#01030d');
      sky.addColorStop(1, '#0b1d3a');
      o.fillStyle = sky;
      o.fillRect(0, 0, W, H);
      if (!st.stars) st.stars = Array.from({ length: 160 }, () => ({ x: Math.random(), y: Math.random() * 0.7, p: Math.random() * 6 }));
      for (const s of st.stars) {
        o.fillStyle = `rgba(255, 255, 255, ${0.35 + 0.35 * Math.sin(t * 1.5 + s.p)})`;
        o.fillRect(s.x * W, s.y * H, Math.max(1, H / 500), Math.max(1, H / 500));
      }
      o.save();
      o.globalCompositeOperation = 'lighter';
      const layers = [[150, 0.0], [175, 1.7], [280, 3.1]];
      for (const [hue, k] of layers) {
        const g = o.createLinearGradient(0, H * 0.15, 0, H * 0.75);
        g.addColorStop(0, `hsla(${hue}, 90%, 60%, 0)`);
        g.addColorStop(0.45, `hsla(${hue}, 90%, 60%, 0.35)`);
        g.addColorStop(1, `hsla(${hue}, 90%, 60%, 0)`);
        o.fillStyle = g;
        o.beginPath();
        const steps = 48;
        for (let i = 0; i <= steps; i++) {
          const x = (i / steps) * W, u = i / steps;
          const y = H * (0.3 + 0.09 * Math.sin(u * 5 + t * 0.45 + k) + 0.04 * Math.sin(u * 13 - t * 0.8 + k));
          if (i) o.lineTo(x, y); else o.moveTo(x, y);
        }
        for (let i = steps; i >= 0; i--) {
          const x = (i / steps) * W, u = i / steps;
          const y = H * (0.62 + 0.06 * Math.sin(u * 4 - t * 0.35 + k));
          o.lineTo(x, y);
        }
        o.closePath();
        o.fill();
      }
      o.restore();
      o.fillStyle = '#02040a';
      o.beginPath();
      o.moveTo(0, H);
      for (let i = 0; i <= 12; i++) {
        const x = (i / 12) * W;
        o.lineTo(x, H * (0.8 + 0.08 * Math.sin(i * 1.9) + 0.04 * Math.cos(i * 3.7)));
      }
      o.lineTo(W, H);
      o.closePath();
      o.fill();
    }

    // Oscilloscopio: reticolo e traccia luminosa
    function drawScope(o, W, H, t) {
      const bg = o.createRadialGradient(W / 2, H / 2, H * 0.1, W / 2, H / 2, Math.hypot(W, H) * 0.6);
      bg.addColorStop(0, '#04210f');
      bg.addColorStop(1, '#000000');
      o.fillStyle = bg;
      o.fillRect(0, 0, W, H);
      o.strokeStyle = 'rgba(90, 255, 150, 0.14)';
      o.lineWidth = Math.max(1, H / 600);
      o.beginPath();
      for (let i = 1; i < 10; i++) { o.moveTo((i / 10) * W, 0); o.lineTo((i / 10) * W, H); }
      for (let i = 1; i < 8; i++) { o.moveTo(0, (i / 8) * H); o.lineTo(W, (i / 8) * H); }
      o.stroke();
      const lw = Math.max(2, H / 260);
      const glow = (alpha) => {   // alone largo e tenue, poi traccia nitida
        o.strokeStyle = `rgba(109, 255, 166, ${0.18 * alpha})`;
        o.lineWidth = lw * 5;
        o.stroke();
        o.strokeStyle = `rgba(150, 255, 190, ${alpha})`;
        o.lineWidth = lw;
        o.stroke();
      };
      o.lineJoin = 'round';
      o.beginPath();
      const a = 3, b = 2 + 0.5 * Math.sin(t * 0.2);
      for (let i = 0; i <= 600; i++) {
        const u = (i / 600) * Math.PI * 2;
        const x = W / 2 + Math.sin(a * u + t * 0.9) * W * 0.32;
        const y = H / 2 + Math.sin(b * u) * H * 0.32;
        if (i) o.lineTo(x, y); else o.moveTo(x, y);
      }
      glow(1);
      o.beginPath();
      for (let i = 0; i <= 200; i++) {
        const x = (i / 200) * W;
        const y = H * 0.88 + Math.sin(i / 200 * Math.PI * 6 - t * 4) * H * 0.04;
        if (i) o.lineTo(x, y); else o.moveTo(x, y);
      }
      glow(0.5);
    }

    // Lampada di lava: bolle che si fondono
    function drawLava(o, W, H, t, st) {
      const pw = 160, ph = 90;
      if (!st.c) { st.c = U.makeCanvas(pw, ph); st.x = st.c.getContext('2d'); st.img = st.x.createImageData(pw, ph); }
      const blobs = [];
      for (let k = 0; k < 6; k++) {
        blobs.push({
          x: pw * (0.5 + 0.38 * Math.sin(t * (0.21 + k * 0.05) + k * 1.7)),
          y: ph * (0.5 + 0.42 * Math.sin(t * (0.17 + k * 0.04) + k * 2.3)),
          r: ph * (0.13 + 0.04 * (k % 3))
        });
      }
      const d = st.img.data;
      for (let y = 0; y < ph; y++) {
        for (let x = 0; x < pw; x++) {
          let v = 0;
          for (const b of blobs) { const dx = x - b.x, dy = y - b.y; v += (b.r * b.r) / (dx * dx + dy * dy + 1); }
          const i = (y * pw + x) * 4;
          // passaggio morbido tra fondo e bolla (niente bordi a scalini)
          const m = Math.min(1, Math.max(0, (v - 0.85) / 0.3)), s = m * m * (3 - 2 * m);
          const glow = Math.min(1, v * v), c = Math.min(1, Math.max(0, (v - 1) * 1.5));
          const bgR = 40 + 120 * glow, bgG = 8 + 20 * glow, bgB = 50 + 60 * glow;
          const lvR = 255, lvG = 90 + 110 * c, lvB = 60 + 40 * (1 - c);
          d[i] = bgR + (lvR - bgR) * s;
          d[i + 1] = bgG + (lvG - bgG) * s;
          d[i + 2] = bgB + (lvB - bgB) * s;
          d[i + 3] = 255;
        }
      }
      st.x.putImageData(st.img, 0, 0);
      o.imageSmoothingEnabled = true;
      o.drawImage(st.c, 0, 0, W, H);
    }


  // -------------------------------------------------------------------
  // Effetti (sul video finale, sotto testi ed elementi)
  // -------------------------------------------------------------------

  function scanlines({ o, W, H, k, stato }) {
    const step = Math.max(3, Math.round(H / 240));
    if (!stato.pattern || stato.step !== step) {
      const c = U.makeCanvas(1, step);
      const x = c.getContext('2d');
      x.fillStyle = '#000';
      x.fillRect(0, 0, 1, Math.ceil(step / 2));
      stato.pattern = o.createPattern(c, 'repeat');
      stato.step = step;
    }
    o.globalAlpha = k * 0.5;
    o.fillStyle = stato.pattern;
    o.fillRect(0, 0, W, H);
  }

  // Canali rosso e ciano separati e fasce orizzontali spostate a caso
  function glitch({ o, W, H, k, out, canvas }) {
    const scene = canvas('scena'), red = canvas('rosso'), cyan = canvas('ciano');
    const sx = scene.getContext('2d');
    sx.globalCompositeOperation = 'copy';
    sx.drawImage(out, 0, 0);
    sx.globalCompositeOperation = 'source-over';
    const tint = (c, color) => {
      const x = c.getContext('2d');
      x.globalCompositeOperation = 'copy';
      x.drawImage(scene, 0, 0);
      x.globalCompositeOperation = 'multiply';
      x.fillStyle = color;
      x.fillRect(0, 0, W, H);
      x.globalCompositeOperation = 'source-over';
    };
    tint(red, '#ff0000');
    tint(cyan, '#00ffff');
    const jitter = Math.random() < 0.12 * k ? (Math.random() - 0.5) * W * 0.04 * k : 0;
    const off = Math.round(W * 0.008 * k + jitter);
    o.fillStyle = '#000';
    o.fillRect(0, 0, W, H);
    o.drawImage(red, -off, 0);
    o.globalCompositeOperation = 'lighter';
    o.drawImage(cyan, off, 0);
    o.globalCompositeOperation = 'source-over';
    if (Math.random() < 0.1 + 0.5 * k) {
      const n = 1 + Math.floor(Math.random() * 3 * k + 0.5);
      for (let i = 0; i < n; i++) {
        const y = Math.random() * H, h = H * (0.015 + Math.random() * 0.06), dx = (Math.random() - 0.5) * W * 0.1 * k;
        o.drawImage(scene, 0, y, W, h, dx, y, W, h);
      }
    }
  }

  function grain({ o, W, H, k, stato }) {
    if (!stato.c) {
      stato.c = U.makeCanvas(256, 144);
      stato.x = stato.c.getContext('2d');
      stato.img = stato.x.createImageData(256, 144);
    }
    const d = stato.img.data;
    for (let i = 0; i < d.length; i += 4) { const v = Math.random() * 255; d[i] = v; d[i + 1] = v; d[i + 2] = v; d[i + 3] = 255; }
    stato.x.putImageData(stato.img, 0, 0);
    o.globalAlpha = k * 0.45;
    o.globalCompositeOperation = 'overlay';
    o.drawImage(stato.c, 0, 0, W, H);
  }

  function vignette({ o, W, H, k }) {
    const g = o.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.3, W / 2, H / 2, Math.hypot(W, H) * 0.55);
    g.addColorStop(0, 'rgba(0, 0, 0, 0)');
    g.addColorStop(1, `rgba(0, 0, 0, ${k * 0.85})`);
    o.fillStyle = g;
    o.fillRect(0, 0, W, H);
  }


  // -------------------------------------------------------------------
  // Grafica d'epoca: monitor a fosfori verdi, schede grafiche CGA ed EGA
  // Sfondi disegnati a bassa risoluzione (come allora) e ingranditi a pixel netti;
  // effetti che riducono il video ai colori della scheda, con retinatura ordinata.
  // -------------------------------------------------------------------
  const CGA = [[0, 0, 0], [85, 255, 255], [255, 85, 255], [255, 255, 255]];   // tavolozza 1, alta intensità
  const EGA = [[0, 0, 0], [0, 0, 170], [0, 170, 0], [0, 170, 170], [170, 0, 0], [170, 0, 170], [170, 85, 0], [170, 170, 170],
    [85, 85, 85], [85, 85, 255], [85, 255, 85], [85, 255, 255], [255, 85, 85], [255, 85, 255], [255, 255, 85], [255, 255, 255]];
  const BAYER4 = [0, 8, 2, 10, 12, 4, 14, 6, 3, 11, 1, 9, 15, 7, 13, 5];
  const soglia = (x, y) => (BAYER4[((y & 3) << 2) | (x & 3)] + 0.5) / 16;   // 0..1, per la retinatura
  const tabelle = new Map();

  // colore (5 bit per canale) -> indice del colore più vicino della tavolozza, calcolato una volta
  function tabellaColori(pal) {
    let tab = tabelle.get(pal);
    if (tab) return tab;
    tab = new Uint8Array(32768);
    for (let i = 0; i < 32768; i++) {
      const r = ((i >> 10) & 31) * 8.23, g = ((i >> 5) & 31) * 8.23, b = (i & 31) * 8.23;
      let migliore = 0, dist = Infinity;
      for (let j = 0; j < pal.length; j++) {
        const p = pal[j];
        const d = 0.3 * (r - p[0]) ** 2 + 0.59 * (g - p[1]) ** 2 + 0.11 * (b - p[2]) ** 2;   // l'occhio pesa di più il verde
        if (d < dist) { dist = d; migliore = j; }
      }
      tab[i] = migliore;
    }
    tabelle.set(pal, tab);
    return tab;
  }

  // tela di lavoro piccola; «leggi»: se ne leggono spesso i pixel (resta nella memoria del processore,
  // altrimenti sta sulla scheda video e copiarla nel fotogramma costa poco)
  function telaPiccola(stato, nome, w, h, leggi = true) {
    const c = stato[nome];
    if (c && c.width === w && c.height === h) return stato[nome + 'X'];
    stato[nome] = U.makeCanvas(w, h);
    stato[nome + 'X'] = stato[nome].getContext('2d', leggi ? { willReadFrequently: true } : undefined);
    return stato[nome + 'X'];
  }

  // indici di colore (Uint8Array w*h) -> pixel, poi ingranditi a pixel netti su tutto il fotogramma
  function mostraIndici(o, W, H, st, pal, w, h) {
    const x = telaPiccola(st, 'tela', w, h);
    if (!st.img || st.img.width !== w || st.img.height !== h) st.img = x.createImageData(w, h);
    const d = st.img.data, idx = st.idx;
    for (let i = 0, j = 0; i < idx.length; i++, j += 4) {
      const p = pal[idx[i]];
      d[j] = p[0]; d[j + 1] = p[1]; d[j + 2] = p[2]; d[j + 3] = 255;
    }
    x.putImageData(st.img, 0, 0);
    o.imageSmoothingEnabled = false;
    o.drawImage(st.tela, 0, 0, W, H);
    o.imageSmoothingEnabled = true;
  }

  // linee di scansione e bordi scuri da tubo catodico
  function tubo(o, W, H, st, forza) {
    const passo = Math.max(3, Math.round(H / 240));
    if (!st.righe || st.passo !== passo) {
      const c = U.makeCanvas(1, passo);
      const x = c.getContext('2d');
      x.fillStyle = '#000';
      x.fillRect(0, 0, 1, Math.ceil(passo / 2));
      st.righe = o.createPattern(c, 'repeat');
      st.passo = passo;
    }
    o.save();
    o.globalAlpha = 0.45 * forza;
    o.fillStyle = st.righe;
    o.fillRect(0, 0, W, H);
    o.globalAlpha = forza;
    const g = o.createRadialGradient(W / 2, H / 2, Math.min(W, H) * 0.42, W / 2, H / 2, Math.hypot(W, H) * 0.56);
    g.addColorStop(0, 'rgba(0, 0, 0, 0)');
    g.addColorStop(1, 'rgba(0, 0, 0, 0.75)');
    o.fillStyle = g;
    o.fillRect(0, 0, W, H);
    o.restore();
  }

  // bagliore del fosforo: la stessa immagine molto rimpicciolita e ingrandita, in somma di luce
  function bagliore(o, W, H, st, sorgente, forza) {
    const w = Math.max(8, Math.round(sorgente.width / 6)), h = Math.max(6, Math.round(sorgente.height / 6));
    const x = telaPiccola(st, 'alone', w, h, false);
    x.imageSmoothingEnabled = true;
    x.clearRect(0, 0, w, h);
    x.drawImage(sorgente, 0, 0, w, h);
    o.save();
    o.globalCompositeOperation = 'lighter';
    o.globalAlpha = forza;
    o.imageSmoothingEnabled = true;
    o.drawImage(st.alone, 0, 0, W, H);
    o.restore();
  }

  // --- Sfondo: terminale a fosfori verdi ----------------------------------
  const TERMINALE = [
    'CAMMIXER BIOS V1.07   (C) 1984', 'MEMORY TEST: 640K OK', 'VIDEO ADAPTER: MONOCHROME, 80 COLUMNS', 'DRIVE A: READY',
    'BOOTING FROM DRIVE A: ...', '', 'A> DIR', ' VOLUME IN DRIVE A IS STUDIO', ' COMMAND  COM   25307  10-31-84',
    ' CAMMIXER EXE   41984  11-01-84', ' EFFECTS  DAT   12288  11-01-84', ' NEWS     TXT    2048  11-01-84',
    '        4 FILE(S)   278528 BYTES FREE', '', 'A> TYPE NEWS.TXT', 'LIVE FROM THE STUDIO.', 'ALL SYSTEMS NOMINAL.', '',
    'A> CAMMIXER /LIVE', 'CONNECTING CAMERA ........ OK', 'SIGNAL: STRONG    LATENCY: 33 MS', 'ON AIR.', ''
  ];
  const TERMINALE_CARATTERI = TERMINALE.reduce((n, r) => n + r.length + 1, 0);

  function drawFosfori(o, W, H, t, st) {
    const w = 640, h = Math.round((640 * H) / W), righe = 20, alt = h / righe;
    const x = telaPiccola(st, 'testo', w, h, false);
    // il testo si scrive a 30 caratteri al secondo, poi si ricomincia dopo una pausa
    const ciclo = TERMINALE_CARATTERI / 30 + 6;
    const scritti = Math.min(TERMINALE_CARATTERI, Math.floor(((t % ciclo) / ciclo) * (TERMINALE_CARATTERI + 180)));
    const cursore = Math.floor(t * 2.2) % 2 === 0;
    const chiave = `${w}x${h}:${scritti}:${cursore}`;
    if (st.chiave !== chiave) {
      st.chiave = chiave;
      const visibili = [];
      let resto = scritti;
      for (const r of TERMINALE) {
        if (resto <= 0) break;
        visibili.push(r.slice(0, resto));
        resto -= r.length + 1;
      }
      if (!visibili.length) visibili.push('');
      const mostrate = visibili.slice(-(righe - 1));
      x.fillStyle = '#000';
      x.fillRect(0, 0, w, h);
      x.font = `700 ${Math.round(alt * 0.78)}px ${MONO}`;
      x.textBaseline = 'top';
      x.fillStyle = '#41ff70';
      mostrate.forEach((r, i) => x.fillText(r, alt * 0.9, alt * (i + 0.6)));
      if (cursore) {
        const ultima = mostrate[mostrate.length - 1];
        x.fillRect(alt * 0.9 + x.measureText(ultima).width + 2, alt * (mostrate.length - 1 + 0.6), alt * 0.5, alt * 0.8);
      }
    }
    o.fillStyle = '#03120a';   // i bordi scuri li fa tubo()
    o.fillRect(0, 0, W, H);
    o.save();
    o.globalCompositeOperation = 'lighter';
    o.globalAlpha = 0.93 + 0.07 * Math.sin(t * 47);   // leggero sfarfallio
    o.drawImage(st.testo, 0, 0, W, H);
    o.restore();
    bagliore(o, W, H, st, st.testo, 0.55);
    // fascia luminosa che scorre lenta, come un tubo un po' stanco
    const fascia = H * 0.12, y = ((t * 0.12) % 1) * (H + 2 * fascia) - fascia;
    const g = o.createLinearGradient(0, y - fascia, 0, y + fascia);
    g.addColorStop(0, 'rgba(65, 255, 112, 0)');
    g.addColorStop(0.5, 'rgba(65, 255, 112, 0.06)');
    g.addColorStop(1, 'rgba(65, 255, 112, 0)');
    o.fillStyle = g;
    o.fillRect(0, y - fascia, W, 2 * fascia);
    tubo(o, W, H, st, 1);
  }

  // --- Sfondo: grafica CGA (320 pixel, 4 colori) --------------------------
  function drawCga(o, W, H, t, st) {
    const w = 320, h = Math.max(100, Math.round((320 * H) / W)), oriz = Math.round(h * 0.56);
    if (!st.idx || st.idx.length !== w * h) st.idx = new Uint8Array(w * h);
    const idx = st.idx, sx = w / 2, sole = h * 0.3;
    const scorri = (t * 0.9) % 1;
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        let c = 0;
        if (y < oriz) {
          // cielo: dal nero al magenta verso l'orizzonte, retinato; stelle che brillano
          const v = Math.pow(y / oriz, 1.6);
          c = v > soglia(x, y) ? 2 : 0;
          const dx = x - sx, dy = y - (oriz - sole * 0.35);
          if (dx * dx + dy * dy < sole * sole) {
            // sole a strisce: le strisce si allargano e scendono
            const f = (oriz - y) / sole;
            c = f < 0.55 && ((y + Math.floor(t * 8)) % 6) < 6 * (0.55 - f) * 1.4 ? 2 : 3;
          } else if (c === 0 && ((x * 7919 + y * 104729) % 977) === 0 && Math.sin(t * 3 + x) > 0) {
            c = 3;
          }
        } else {
          // pavimento a griglia in prospettiva, che scorre verso chi guarda: una riga di pixel per linea;
          // dove le linee sarebbero più fitte di 3 pixel (verso l'orizzonte) resta una foschia retinata
          const d = y - oriz + 0.5, z0 = 120 / d, z1 = 120 / (d + 1);
          const riga = z0 - z1 < 0.5 && Math.floor(z0 + scorri * 2) !== Math.floor(z1 + scorri * 2);
          const passo = d / 4;   // distanza in pixel tra due linee verticali, su questa riga
          const colonna = passo >= 3 && Math.floor((x - sx) / passo) !== Math.floor((x + 1 - sx) / passo);
          const foschia = Math.max(0, 1 - d / ((h - oriz) * 0.35)) * 0.6 > soglia(x, y);
          c = riga || colonna || foschia ? 1 : 0;
          if (y - oriz < 1) c = 2;
        }
        idx[y * w + x] = c;
      }
    }
    mostraIndici(o, W, H, st, CGA, w, h);
    tubo(o, W, H, st, 0.5);
  }

  // --- Sfondo: grafica EGA (320 pixel, 16 colori) -------------------------
  function drawEga(o, W, H, t, st) {
    const w = 320, h = Math.max(100, Math.round((320 * H) / W)), oriz = Math.round(h * 0.62);
    if (!st.idx || st.idx.length !== w * h) st.idx = new Uint8Array(w * h);
    const idx = st.idx;
    const sx = w * 0.72, sy = h * 0.2, sr = h * 0.07;
    // nuvole che scorrono piano verso destra (posizioni ricalcolate a ogni fotogramma, poche e piccole)
    const nuvole = [];
    [[0, 0.12, 1], [110, 0.2, 0.8], [210, 0.1, 1.2], [290, 0.24, 0.7]].forEach(([x0, y0, s]) => {
      const cx = ((x0 + t * 7 * s) % (w + 80)) - 40, cy = h * y0, r0 = h * 0.045 * s;
      nuvole.push({ x: cx, y: cy, r: r0 }, { x: cx - r0 * 1.1, y: cy + r0 * 0.35, r: r0 * 0.75 }, { x: cx + r0 * 1.15, y: cy + r0 * 0.3, r: r0 * 0.8 });
    });
    const monti = (x) => h * 0.36 + Math.sin(x * 0.021) * h * 0.08 + Math.sin(x * 0.053 + 1.3) * h * 0.04;
    const colli = (x) => h * 0.5 + Math.sin(x * 0.034 + 2) * h * 0.05 + Math.sin(x * 0.09) * h * 0.018;
    for (let x = 0; x < w; x++) {
      const m = monti(x + t * 6), q = colli(x + t * 18);
      const albero = ((x + Math.floor(t * 18)) % 37 + 37) % 37;   // un albero ogni 37 pixel, sulle colline
      for (let y = 0; y < h; y++) {
        let c;
        if (y >= oriz) {
          // lago: blu e ciano a righe che ondeggiano, riflesso del sole
          const onda = Math.sin(y * 0.9 + t * 3 + x * 0.05);
          c = onda > 0.6 ? 3 : 1;
          if (Math.abs(x - sx + Math.sin(y * 1.7 + t * 4) * 3) < sr * (1 - (y - oriz) / (h - oriz)) * 1.4 && onda > -0.2) c = 14;
        } else if (y >= q) {
          c = y < q + 2 ? 10 : (((x + y) & 1) && y > q + 6 ? 2 : 2);
          if (albero < 5 && y < q + 2) c = 6;
        } else if (albero < 5 && y >= q - 14 && y < q) {
          // albero: chioma a triangolo e tronco
          const centro = Math.abs(albero - 2);
          c = y > q - 4 ? (centro < 1 ? 6 : -1) : (centro <= (y - (q - 14)) * 0.25 ? 2 : -1);
          if (c < 0) c = y >= m ? 8 : -1;
        } else if (y >= m) {
          c = y < m + 2 ? 7 : 8;
        } else {
          c = -1;
        }
        if (c < 0) {
          // cielo: blu scuro, blu, azzurro verso l'orizzonte (retinato); sole; nuvole
          const v = y / oriz;
          const sopra = v < 0.45 ? 1 : (v < 0.8 ? 9 : 11), sotto = v < 0.45 ? 9 : (v < 0.8 ? 11 : 15);
          const f = v < 0.45 ? v / 0.45 : (v < 0.8 ? (v - 0.45) / 0.35 : (v - 0.8) / 0.2);
          c = f * f > soglia(x, y) ? sotto : sopra;
          const dx = x - sx, dy = y - sy;
          if (dx * dx + dy * dy < sr * sr) c = dx * dx + dy * dy < sr * sr * 0.4 ? 15 : 14;
          // nuvole: ciascuna fatta di tre sbuffi rotondi, bianche con il fondo grigio retinato
          for (const n of nuvole) {
            const dx2 = x - n.x, dy2 = y - n.y;
            if (dx2 * dx2 + dy2 * dy2 < n.r * n.r) { c = dy2 > n.r * 0.35 && 0.5 > soglia(x, y) ? 7 : 15; break; }
          }
        }
        idx[y * w + x] = c;
      }
    }
    mostraIndici(o, W, H, st, EGA, w, h);
    tubo(o, W, H, st, 0.4);
  }

  // --- Sfondo: pioggia digitale -------------------------------------------
  // Colonne di caratteri verdi che cadono a velocità diverse (le più lontane più lente e scure),
  // con la testa chiara e la scia che sfuma; i caratteri cambiano di tanto in tanto.
  // I caratteri sono disegnati una volta in una tavola (verdi e chiari) e poi solo copiati.
  const PIOGGIA_CARATTERI = '0123456789ABCDEFGHJKLMNPQRSTUVWXYZ+-*=<>/\\|:;#$%&@?!'.split('');

  function drawPioggia(o, W, H, t, st) {
    const cella = Math.max(10, Math.round(H / 36)), cw = Math.round(cella * 0.72);
    const colonne = Math.ceil(W / cw), righe = Math.ceil(H / cella) + 1;
    if (!st.tavola || st.cella !== cella) {
      // tavola dei caratteri: riga 0 verde, riga 1 quasi bianca (testa della colonna)
      st.cella = cella;
      st.tavola = U.makeCanvas(cw * PIOGGIA_CARATTERI.length, cella * 2);
      const x = st.tavola.getContext('2d');
      x.font = `700 ${Math.round(cella * 0.82)}px ${MONO}`;
      x.textAlign = 'center';
      x.textBaseline = 'middle';
      PIOGGIA_CARATTERI.forEach((ch, i) => {
        x.fillStyle = '#3dff7a';
        x.fillText(ch, i * cw + cw / 2, cella / 2);
        x.fillStyle = '#e4ffec';
        x.fillText(ch, i * cw + cw / 2, cella * 1.5);
      });
      st.colonne = null;
    }
    const nuova = (c, sopra) => {
      c.prof = 0.35 + Math.random() * 0.65;                 // 1 = vicina: più veloce e luminosa
      c.v = (5 + Math.random() * 12) * c.prof;              // celle al secondo
      c.lung = 8 + Math.floor(Math.random() * 22);
      c.y = sopra ? -Math.random() * righe : Math.random() * righe;
    };
    if (!st.colonne || st.colonne.length !== colonne) {
      st.colonne = [];
      for (let i = 0; i < colonne; i++) {
        const c = { segni: new Uint8Array(righe) };
        for (let r = 0; r < righe; r++) c.segni[r] = Math.floor(Math.random() * PIOGGIA_CARATTERI.length);
        nuova(c, false);
        st.colonne.push(c);
      }
      st.prima = t;
    }
    const dt = Math.min(0.1, Math.max(0, t - (st.prima === undefined ? t : st.prima)));
    st.prima = t;
    o.fillStyle = '#000';
    o.fillRect(0, 0, W, H);
    for (let i = 0; i < colonne; i++) {
      const c = st.colonne[i];
      c.y += c.v * dt;
      if (c.y - c.lung > righe) nuova(c, true);
      // qualche carattere cambia
      if (Math.random() < 0.35) c.segni[Math.floor(Math.random() * righe)] = Math.floor(Math.random() * PIOGGIA_CARATTERI.length);
      const testa = Math.floor(c.y);
      for (let k = 0; k <= c.lung; k++) {
        const r = testa - k;
        if (r < 0 || r >= righe) continue;
        const s = c.segni[r];
        o.globalAlpha = k === 0 ? Math.min(1, 0.55 + c.prof * 0.45) : c.prof * Math.pow(1 - k / (c.lung + 1), 1.6);
        o.drawImage(st.tavola, s * cw, k === 0 ? cella : 0, cw, cella, i * cw, r * cella, cw, cella);
      }
    }
    o.globalAlpha = 1;
  }

  // --- Effetti sul video --------------------------------------------------
  // Monitor a fosfori verdi: luminosità del video in verde, bagliore, linee di scansione
  function fosforiVerdi({ o, W, H, k, out, stato, t }) {
    const w = 400, h = Math.max(2, Math.round((400 * H) / W));
    const x = telaPiccola(stato, 'tela', w, h);
    x.imageSmoothingEnabled = true;
    x.drawImage(out, 0, 0, w, h);
    const img = x.getImageData(0, 0, w, h), d = img.data;
    // luminosità (0-255) -> colore del fosforo, in una tabella calcolata una volta
    if (!stato.verde) {
      stato.verde = new Uint8Array(256 * 3);
      for (let v = 0; v < 256; v++) {
        const l = Math.min(1, Math.pow(v / 255, 1.15) * 1.2);
        stato.verde[v * 3] = 70 * l * l; stato.verde[v * 3 + 1] = 255 * l; stato.verde[v * 3 + 2] = 120 * l * l;
      }
    }
    const tab = stato.verde;
    for (let i = 0; i < d.length; i += 4) {
      const v = ((77 * d[i] + 151 * d[i + 1] + 28 * d[i + 2]) >> 8) * 3;
      d[i] = tab[v]; d[i + 1] = tab[v + 1]; d[i + 2] = tab[v + 2];
    }
    x.putImageData(img, 0, 0);
    o.globalAlpha = k * (0.94 + 0.06 * Math.sin((t || 0) * 53));   // leggero sfarfallio
    o.imageSmoothingEnabled = true;
    o.drawImage(stato.tela, 0, 0, W, H);
    o.globalAlpha = 1;
    bagliore(o, W, H, stato, stato.tela, 0.45 * k);
    tubo(o, W, H, stato, k);
  }

  // Video ridotto a 320 pixel e ai colori di una scheda grafica, con retinatura ordinata
  function effettoTavolozza(pal, retina) {
    return ({ o, W, H, k, out, stato }) => {
      const w = 320, h = Math.max(2, Math.round((320 * H) / W));
      const x = telaPiccola(stato, 'tela', w, h);
      x.imageSmoothingEnabled = true;
      x.drawImage(out, 0, 0, w, h);
      const img = x.getImageData(0, 0, w, h), d = img.data, tab = tabellaColori(pal);
      for (let y = 0, i = 0; y < h; y++) {
        for (let xx = 0; xx < w; xx++, i += 4) {
          const s = (soglia(xx, y) - 0.5) * retina;
          let r = d[i] + s, g = d[i + 1] + s, b = d[i + 2] + s;
          r = r < 0 ? 0 : r > 255 ? 255 : r; g = g < 0 ? 0 : g > 255 ? 255 : g; b = b < 0 ? 0 : b > 255 ? 255 : b;
          const p = pal[tab[((r >> 3) << 10) | ((g >> 3) << 5) | (b >> 3)]];
          d[i] = p[0]; d[i + 1] = p[1]; d[i + 2] = p[2]; d[i + 3] = 255;
        }
      }
      x.putImageData(img, 0, 0);
      o.globalAlpha = k;
      o.imageSmoothingEnabled = false;
      o.drawImage(stato.tela, 0, 0, W, H);
    };
  }


  // -------------------------------------------------------------------
  // Sottopancia (stile telegiornale)
  // -------------------------------------------------------------------

  const SANS = 'system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif';
  const MONO = 'Consolas, "Cascadia Mono", "Courier New", monospace';
  const easeOut = (k) => 1 - Math.pow(1 - Math.min(1, Math.max(0, k)), 3);

  // Entrata animata: riparte quando cambiano etichetta, nome o notizia
  function entrata(t, T, stato) {
    const key = `${T.etichetta}|${T.nome}|${T.notizia}`;
    if (stato.key !== key) { stato.key = key; stato.t0 = t; }
    return easeOut((t - stato.t0) / 0.6);
  }

  // Riduce il carattere finché il testo entra nella larghezza disponibile
  function adatta(o, testo, peso, px, famiglia, maxW) {
    let size = Math.round(px);
    o.font = `${peso} ${size}px ${famiglia}`;
    while (size > 8 && o.measureText(testo).width > maxW) { size -= 1; o.font = `${peso} ${size}px ${famiglia}`; }
    return size;
  }

  // Striscia di notizie che scorre da destra a sinistra dentro un rettangolo
  function striscia(o, voci, x, y, w, h, t, { font, color, sep, speed }) {
    if (!voci.length || w <= 0) return;
    const testo = voci.join(sep) + sep;
    o.save();
    o.beginPath();
    o.rect(x, y, w, h);
    o.clip();
    o.font = font;
    o.fillStyle = color;
    o.textAlign = 'left';
    o.textBaseline = 'middle';
    const tw = Math.max(1, o.measureText(testo).width);
    let px = x - ((t * (speed || h * 2.4)) % tw);
    while (px < x + w) { o.fillText(testo, px, y + h / 2); px += tw; }
    o.restore();
  }

  function orologio(o, ora, x, y, h, u, fondo, colore, font) {
    if (!ora) return 0;
    o.font = font;
    const w = o.measureText(ora).width + 28 * u;
    o.fillStyle = fondo;
    o.fillRect(x, y, w, h);
    o.fillStyle = colore;
    o.textAlign = 'left';
    o.textBaseline = 'middle';
    o.fillText(ora, x + 14 * u, y + h / 2);
    return w;
  }

  // Ogni stile ha due parti:
  // - blocco(o, W, H, t, testi, stato): nome, ruolo, notizia. Si sposta e si ridimensiona
  //   con le impostazioni; restituisce il riquadro occupato { x, y, w, h } (per il mouse).
  // - striscia(o, W, H, t, testi, stato): la striscia che scorre, sempre in basso.
  const box = (x1, y1, x2, y2) => ({ x: x1, y: y1, w: Math.max(1, x2 - x1), h: Math.max(1, y2 - y1) });

  // 1. Ultim'ora: etichetta rossa pulsante, notizia su bianco, striscia scura
  function ultimoraBlocco(o, W, H, t, T, stato) {
    const u = H / 720, k = entrata(t, T, stato);
    o.textAlign = 'left';
    o.textBaseline = 'middle';
    const x0 = W * 0.04 - (1 - k) * W * 0.8;
    const barY = H * 0.71, barH = 72 * u;
    let top = barY, right = x0;
    const chi = [T.nome, T.ruolo].filter(Boolean).join(' — ');
    if (chi) {
      adatta(o, chi, 600, 26 * u, SANS, W * 0.6);
      const tw = o.measureText(chi).width;
      o.fillStyle = 'rgba(15, 15, 18, 0.88)';
      o.fillRect(x0, barY - 44 * u, tw + 28 * u, 40 * u);
      o.fillStyle = '#ffffff';
      o.fillText(chi, x0 + 14 * u, barY - 24 * u);
      top = barY - 44 * u;
      right = Math.max(right, x0 + tw + 28 * u);
    }
    let x = x0;
    if (T.etichetta) {
      o.font = `800 ${Math.round(30 * u)}px ${SANS}`;
      const lw = o.measureText(T.etichetta).width + 36 * u;
      const p = 0.82 + 0.18 * Math.sin(t * 4);
      o.fillStyle = `rgb(${Math.round(222 * p)}, 22, 30)`;
      o.fillRect(x, barY, lw, barH);
      o.fillStyle = '#ffffff';
      o.fillText(T.etichetta, x + 18 * u, barY + barH / 2);
      x += lw;
    }
    if (T.notizia) {
      adatta(o, T.notizia, 800, 36 * u, SANS, W * 0.92 - (x - x0) - 40 * u);
      const tw = o.measureText(T.notizia).width;
      o.fillStyle = '#ffffff';
      o.fillRect(x, barY, tw + 40 * u, barH);
      o.fillStyle = '#111111';
      o.fillText(T.notizia, x + 20 * u, barY + barH / 2);
      x += tw + 40 * u;
    }
    right = Math.max(right, x);
    return box(x0, top, right, barY + barH);
  }
  function ultimoraStriscia(o, W, H, t, T) {
    if (!T.scorrimento.length && !T.ora) return;
    const u = H / 720, sy = H - 50 * u, sh = 40 * u;
    o.fillStyle = 'rgba(12, 12, 14, 0.92)';
    o.fillRect(0, sy, W, sh);
    const ow = orologio(o, T.ora, 0, sy, sh, u, '#d7141a', '#ffffff', `800 ${Math.round(24 * u)}px ${SANS}`);
    striscia(o, T.scorrimento, ow + 12 * u, sy, W - ow - 12 * u, sh, t, { font: `600 ${Math.round(24 * u)}px ${SANS}`, color: '#f2f2f2', sep: '      •      ' });
  }

  // 2. Telegiornale: barra blu che si allunga, accento giallo, striscia del nome sotto
  function telegiornaleBlocco(o, W, H, t, T, stato) {
    const u = H / 720, k = entrata(t, T, stato);
    o.textAlign = 'left';
    o.textBaseline = 'middle';
    const x0 = W * 0.05, y0 = H * 0.66, fullW = W * 0.9, barH = 70 * u, subH = 36 * u;
    const top = T.etichetta ? y0 - 38 * u : y0;
    const bottom = y0 + barH + (T.nome || T.ruolo ? subH : 0);
    o.save();
    o.beginPath();
    o.rect(x0, y0 - 44 * u, Math.max(1, fullW * k), 44 * u + barH + subH);
    o.clip();
    if (T.etichetta) {
      o.font = `800 ${Math.round(22 * u)}px ${SANS}`;
      const lw = o.measureText(T.etichetta).width + 28 * u;
      o.fillStyle = '#ffc400';
      o.fillRect(x0, y0 - 38 * u, lw, 38 * u);
      o.fillStyle = '#0a1a3a';
      o.fillText(T.etichetta, x0 + 14 * u, y0 - 19 * u);
    }
    const g = o.createLinearGradient(x0, 0, x0 + fullW, 0);
    g.addColorStop(0, '#0a2a6b');
    g.addColorStop(1, '#1e6fd0');
    o.fillStyle = g;
    o.fillRect(x0, y0, fullW, barH);
    o.fillStyle = '#ffc400';
    o.fillRect(x0, y0, 8 * u, barH);
    if (T.notizia) {
      adatta(o, T.notizia, 800, 34 * u, SANS, fullW - 50 * u);
      o.fillStyle = '#ffffff';
      o.fillText(T.notizia, x0 + 28 * u, y0 + barH / 2);
    }
    if (T.nome || T.ruolo) {
      o.fillStyle = 'rgba(5, 18, 48, 0.94)';
      o.fillRect(x0, y0 + barH, fullW, subH);
      let x = x0 + 28 * u;
      if (T.nome) {
        o.font = `700 ${Math.round(22 * u)}px ${SANS}`;
        o.fillStyle = '#ffffff';
        o.fillText(T.nome, x, y0 + barH + subH / 2);
        x += o.measureText(T.nome).width + 16 * u;
      }
      if (T.ruolo) {
        o.font = `400 ${Math.round(20 * u)}px ${SANS}`;
        o.fillStyle = '#9cc9ff';
        o.fillText(T.ruolo, x, y0 + barH + subH / 2);
      }
    }
    o.restore();
    return box(x0, top, x0 + fullW * k, bottom);
  }
  function telegiornaleStriscia(o, W, H, t, T) {
    if (!T.scorrimento.length && !T.ora) return;
    const u = H / 720, sy = H - 44 * u, sh = 36 * u;
    o.fillStyle = 'rgba(4, 16, 44, 0.94)';
    o.fillRect(0, sy, W, sh);
    const ow = orologio(o, T.ora, 0, sy, sh, u, '#ffc400', '#0a1a3a', `800 ${Math.round(22 * u)}px ${SANS}`);
    striscia(o, T.scorrimento, ow + 12 * u, sy, W - ow - 12 * u, sh, t, { font: `500 ${Math.round(22 * u)}px ${SANS}`, color: '#e3f0ff', sep: '      ◆      ' });
  }

  // 3. Minimal: niente riquadri, linea bianca e testi eleganti; sfumatura scura in basso
  function minimalBlocco(o, W, H, t, T, stato) {
    const u = H / 720, k = entrata(t, T, stato);
    o.globalAlpha = k;
    o.textAlign = 'left';
    o.textBaseline = 'middle';
    const x = W * 0.07, top = H * 0.7 - 16 * u;
    let y = H * 0.7, right = x;
    const line = (font, color, text) => {
      o.font = font;
      o.fillStyle = color;
      o.fillText(text, x, y);
      right = Math.max(right, x + o.measureText(text).width);
    };
    if (T.etichetta) { line(`700 ${Math.round(17 * u)}px ${SANS}`, 'rgba(255, 255, 255, 0.75)', T.etichetta.toUpperCase().split('').join(' ')); y += 34 * u; }
    if (T.nome) { line(`700 ${Math.round(40 * u)}px ${SANS}`, '#ffffff', T.nome); y += 36 * u; }
    if (T.ruolo) { line(`400 ${Math.round(23 * u)}px ${SANS}`, '#d6d6d6', T.ruolo); y += 34 * u; }
    if (T.notizia) {
      adatta(o, T.notizia, 300, 26 * u, SANS, W * 0.82);
      o.fillStyle = '#ffffff';
      o.fillText(T.notizia, x, y);
      right = Math.max(right, x + o.measureText(T.notizia).width);
      y += 16 * u;
    } else {
      y -= 18 * u;
    }
    o.fillStyle = '#ffffff';
    o.fillRect(x - 20 * u, top, 4 * u, (y - top) * k);
    return box(x - 24 * u, top, right + 8 * u, y);
  }
  function minimalStriscia(o, W, H, t, T, stato) {
    const u = H / 720, k = Math.min(1, ((t - (stato.t0 || t)) / 0.6) + 0.0001);
    const g = o.createLinearGradient(0, H * 0.55, 0, H);
    g.addColorStop(0, 'rgba(0, 0, 0, 0)');
    g.addColorStop(1, `rgba(0, 0, 0, ${0.7 * Math.max(0.3, k)})`);
    o.fillStyle = g;
    o.fillRect(0, H * 0.55, W, H * 0.45);
    if (T.ora) {
      o.font = `300 ${Math.round(24 * u)}px ${SANS}`;
      o.textAlign = 'right';
      o.textBaseline = 'middle';
      o.fillStyle = '#ffffff';
      o.fillText(T.ora, W - W * 0.04, H - 60 * u);
      o.textAlign = 'left';
    }
    striscia(o, T.scorrimento, 0, H - 34 * u, W, 28 * u, t, { font: `400 ${Math.round(19 * u)}px ${SANS}`, color: 'rgba(255, 255, 255, 0.8)', sep: '      ·      ' });
  }

  // 4. Neon: pannello scuro con bordo luminoso, caratteri da terminale, cursore che lampeggia
  function neonBlocco(o, W, H, t, T, stato) {
    const u = H / 720, k = entrata(t, T, stato);
    o.textAlign = 'left';
    o.textBaseline = 'middle';
    const x0 = W * 0.05, y0 = H * 0.65, w = Math.max(1, W * 0.9 * k), h = 128 * u;
    o.globalAlpha = Math.sin(t * 37) > 0.97 ? 0.55 : 1;
    o.fillStyle = 'rgba(6, 0, 22, 0.78)';
    o.fillRect(x0, y0, w, h);
    o.strokeStyle = 'rgba(0, 240, 255, 0.25)';
    o.lineWidth = 10 * u;
    o.strokeRect(x0, y0, w, h);
    o.strokeStyle = 'rgba(0, 240, 255, 1)';
    o.lineWidth = 2 * u;
    o.strokeRect(x0, y0, w, h);
    o.save();
    o.beginPath();
    o.rect(x0, y0 - 40 * u, w, h + 40 * u);
    o.clip();
    if (T.etichetta) {
      o.font = `700 ${Math.round(20 * u)}px ${MONO}`;
      const lw = o.measureText(T.etichetta).width + 24 * u;
      o.fillStyle = '#ff2bd6';
      o.fillRect(x0 + 16 * u, y0 - 16 * u, lw, 32 * u);
      o.fillStyle = '#0a0014';
      o.fillText(T.etichetta, x0 + 28 * u, y0);
    }
    if (T.notizia) {
      adatta(o, T.notizia, 700, 32 * u, MONO, w - 60 * u);
      o.lineWidth = 6 * u;
      o.strokeStyle = 'rgba(0, 240, 255, 0.25)';
      o.strokeText(T.notizia, x0 + 28 * u, y0 + 50 * u);
      o.fillStyle = '#9ff9ff';
      o.fillText(T.notizia, x0 + 28 * u, y0 + 50 * u);
    }
    const chi = [T.nome, T.ruolo].filter(Boolean).join(' // ');
    if (chi || T.ora) {
      const riga = `> ${chi}${T.ora ? `   [${T.ora}]` : ''}`;
      o.font = `400 ${Math.round(21 * u)}px ${MONO}`;
      o.fillStyle = '#ff9cf0';
      o.fillText(riga, x0 + 28 * u, y0 + 96 * u);
      if (Math.floor(t * 2) % 2 === 0) {
        const cw = o.measureText(riga).width;
        o.fillRect(x0 + 34 * u + cw, y0 + 86 * u, 12 * u, 22 * u);
      }
    }
    o.restore();
    return box(x0, T.etichetta ? y0 - 16 * u : y0, x0 + w, y0 + h);
  }
  function neonStriscia(o, W, H, t, T) {
    if (!T.scorrimento.length) return;
    const u = H / 720, sy = H - 42 * u, sh = 32 * u;
    o.fillStyle = 'rgba(6, 0, 22, 0.85)';
    o.fillRect(0, sy, W, sh);
    o.fillStyle = 'rgba(0, 240, 255, 0.9)';
    o.fillRect(0, sy, W, Math.max(1, 2 * u));
    striscia(o, T.scorrimento, 0, sy, W, sh, t, { font: `400 ${Math.round(20 * u)}px ${MONO}`, color: '#7ff6ff', sep: '   //   ' });
  }

  // 5. Sport: forme inclinate verde e blu notte con accento giallo
  const SKEW = 0.32;
  function para(o, x, y, w, h, color) {
    o.fillStyle = color;
    o.beginPath();
    o.moveTo(x + h * SKEW, y);
    o.lineTo(x + w + h * SKEW, y);
    o.lineTo(x + w, y + h);
    o.lineTo(x, y + h);
    o.closePath();
    o.fill();
  }
  function sportBlocco(o, W, H, t, T, stato) {
    const u = H / 720, k = entrata(t, T, stato);
    o.textAlign = 'left';
    o.textBaseline = 'middle';
    const x0 = W * 0.04 - (1 - k) * W * 0.9, y0 = H * 0.7, h = 64 * u;
    let x = x0, right = x0, bottom = y0 + h + 6 * u;
    if (T.etichetta) {
      o.font = `italic 800 ${Math.round(26 * u)}px ${SANS}`;
      const lw = o.measureText(T.etichetta).width + 44 * u;
      para(o, x, y0, lw, h, '#00b140');
      o.fillStyle = '#ffffff';
      o.fillText(T.etichetta, x + 26 * u, y0 + h / 2);
      x += lw + 6 * u;
    }
    if (T.notizia) {
      adatta(o, T.notizia, 'italic 800', 32 * u, SANS, W * 0.9 - (x - x0) - 50 * u);
      const tw = o.measureText(T.notizia).width + 50 * u;
      para(o, x, y0, tw, h, '#0d1b2a');
      para(o, x + 8 * u, y0 + h, tw - 8 * u, 6 * u, '#ffd400');
      o.fillStyle = '#ffffff';
      o.fillText(T.notizia, x + 28 * u, y0 + h / 2);
      x += tw;
    }
    right = x + h * SKEW;
    const chi = [T.nome, T.ruolo].filter(Boolean).join(' · ');
    if (chi) {
      o.font = `italic 700 ${Math.round(21 * u)}px ${SANS}`;
      const cw = o.measureText(chi).width + 40 * u;
      para(o, x0 + 20 * u, y0 + h + 12 * u, cw, 34 * u, '#ffffff');
      o.fillStyle = '#0d1b2a';
      o.fillText(chi, x0 + 40 * u, y0 + h + 29 * u);
      right = Math.max(right, x0 + 20 * u + cw + 34 * u * SKEW);
      bottom = y0 + h + 46 * u;
    }
    return box(x0, y0, right, bottom);
  }
  function sportStriscia(o, W, H, t, T) {
    if (!T.scorrimento.length && !T.ora) return;
    const u = H / 720, sy = H - 42 * u, sh = 34 * u;
    o.fillStyle = '#00b140';
    o.fillRect(0, sy, W, sh);
    const ow = orologio(o, T.ora, 0, sy, sh, u, '#ffd400', '#0d1b2a', `italic 800 ${Math.round(22 * u)}px ${SANS}`);
    striscia(o, T.scorrimento, ow + 12 * u, sy, W - ow - 12 * u, sh, t, { font: `italic 700 ${Math.round(21 * u)}px ${SANS}`, color: '#062b12', sep: '      ▸      ' });
  }

  // -------------------------------------------------------------------
  // Esempi 3D (Three.js, r187). Compaiono solo con «Esempi 3D» attivo nelle impostazioni
  // (tre_d: true); la libreria si carica al primo uso. Tutti gli esempi usano un solo
  // renderer WebGL per pagina, che disegna su una tela fuori schermo poi copiata nel fotogramma.
  // Se la scheda video non è disponibile il componente va in errore e si disattiva da solo.
  // -------------------------------------------------------------------
  const T3 = { lib: null, errore: '', promessa: null, renderer: null, tela: null };

  function three() {
    if (T3.lib) return T3.lib;
    if (!T3.promessa && !T3.errore) {
      const url = U.risorsa ? U.risorsa('three/three.module.js') : '';
      if (!url) { T3.errore = tr('extension folder not reachable'); return null; }
      T3.promessa = import(url).then((m) => { T3.lib = m; }, (e) => { T3.errore = String((e && e.message) || e).slice(0, 120); });
    }
    return null;
  }

  function renderer3D(W, H) {
    const THREE = T3.lib;
    if (!T3.renderer) {
      const tela = typeof OffscreenCanvas !== 'undefined' ? new OffscreenCanvas(W, H) : Object.assign(document.createElement('canvas'), { width: W, height: H });
      const r = new THREE.WebGLRenderer({ canvas: tela, alpha: true, antialias: true, preserveDrawingBuffer: true, powerPreference: 'high-performance' });
      r.outputColorSpace = THREE.SRGBColorSpace;
      T3.renderer = r;
      T3.tela = tela;
    }
    if (T3.tela.width !== W || T3.tela.height !== H) T3.renderer.setSize(W, H, false);
    return T3.renderer;
  }

  // disegna una scena 3D sopra il fotogramma (sfondo trasparente se la scena non ne ha uno)
  function disegna3D(o, W, H, scena, camera) {
    const r = renderer3D(W, H);
    r.setClearColor(0x000000, 0);
    r.render(scena, camera);
    o.drawImage(T3.tela, 0, 0, W, H);
  }

  // finché la libreria si carica (o se non si carica): una scritta discreta
  function attesa3D(o, W, H, pieno) {
    const u = H / 720;
    if (pieno) { o.fillStyle = '#06080f'; o.fillRect(0, 0, W, H); }
    o.font = `600 ${Math.round(18 * u)}px ${SANS}`;
    o.textBaseline = 'bottom';
    o.fillStyle = T3.errore ? '#ff8080' : 'rgba(255,255,255,0.7)';
    o.fillText(T3.errore ? tr('3D examples not available: {error}', { error: T3.errore }) : tr('Loading the 3D examples…'), 16 * u, H - 14 * u);
  }

  function telaTesto(stato, testo, disegno) {
    if (!stato.tt) { stato.tt = U.makeCanvas(512, 512); stato.ttx = stato.tt.getContext('2d'); }
    if (stato.testoTela !== testo) { disegno(stato.ttx, 512, 512, testo); stato.testoTela = testo; return true; }
    return false;
  }

  // --- Sfondo: studio televisivo 3D --------------------------------------
  function studioSchermo(x, w, h, t) {
    const g = x.createLinearGradient(0, 0, w, 0);
    g.addColorStop(0, '#061a3d'); g.addColorStop(0.5, '#0b3d91'); g.addColorStop(1, '#061a3d');
    x.fillStyle = g; x.fillRect(0, 0, w, h);
    x.strokeStyle = 'rgba(120,190,255,0.25)'; x.lineWidth = 2;
    for (let i = 0; i < 24; i++) {   // griglia che scorre
      const px = ((i * 64 + t * 40) % (w + 64)) - 32;
      x.beginPath(); x.moveTo(px, 0); x.lineTo(px - 60, h); x.stroke();
    }
    for (let k = 0; k < 3; k++) {    // onde luminose
      x.strokeStyle = ['rgba(0,200,255,0.8)', 'rgba(255,60,120,0.7)', 'rgba(255,210,0,0.6)'][k]; x.lineWidth = 4;
      x.beginPath();
      for (let px = 0; px <= w; px += 16) x.lineTo(px, h * (0.5 + 0.18 * Math.sin(px / 90 + t * (1 + k * 0.4) + k * 2)));
      x.stroke();
    }
    x.fillStyle = 'rgba(255,255,255,0.9)'; x.font = `800 ${Math.round(h * 0.16)}px ${SANS}`;
    x.textAlign = 'right'; x.textBaseline = 'top'; x.fillText('LIVE', w - 24, 18);
    x.fillStyle = '#ff2e4d'; x.beginPath(); x.arc(w - 24 - x.measureText('LIVE').width - 22, 18 + h * 0.08, h * 0.035 * (0.7 + 0.3 * Math.sin(t * 6)), 0, 6.3); x.fill();
    x.textAlign = 'left';
  }

  function drawStudio3D(o, W, H, t, stato) {
    const THREE = three();
    if (!THREE) return attesa3D(o, W, H, true);
    if (!stato.scena) {
      const s = new THREE.Scene();
      s.background = new THREE.Color(0x03050c);
      s.fog = new THREE.Fog(0x03050c, 14, 34);
      const pav = new THREE.Mesh(new THREE.PlaneGeometry(60, 60), new THREE.MeshStandardMaterial({ color: 0x0a1226, metalness: 0.7, roughness: 0.28 }));
      pav.rotation.x = -Math.PI / 2;
      s.add(pav);
      stato.tela = U.makeCanvas(1024, 256);
      stato.tx = stato.tela.getContext('2d');
      stato.mappa = new THREE.CanvasTexture(stato.tela);
      stato.mappa.colorSpace = THREE.SRGBColorSpace;
      stato.mappa.wrapS = THREE.RepeatWrapping;   // lo schermo si vede dall'interno: immagine ribaltata
      stato.mappa.repeat.x = -1;
      const schermo = new THREE.Mesh(new THREE.CylinderGeometry(13, 13, 6, 64, 1, true, Math.PI - 0.75, 1.5),
        new THREE.MeshBasicMaterial({ map: stato.mappa, side: THREE.BackSide }));
      schermo.position.set(0, 4.2, 4);
      s.add(schermo);
      const cornice = new THREE.Mesh(new THREE.TorusGeometry(13.05, 0.06, 8, 96, 1.5), new THREE.MeshBasicMaterial({ color: 0x3fa9ff }));
      cornice.rotation.x = Math.PI / 2; cornice.rotation.z = Math.PI / 2 - 0.75 + Math.PI; cornice.position.set(0, 1.2, 4);
      s.add(cornice);
      stato.pilastri = [];
      for (let i = -3; i <= 3; i++) {
        if (i === 0) continue;
        const col = i % 2 ? 0x2b7bff : 0xff2e6d;
        // pilastri luminosi ai lati dello schermo, fari bassi davanti
        const alto = Math.abs(i) === 3;
        const p = new THREE.Mesh(alto ? new THREE.BoxGeometry(0.22, 6, 0.22) : new THREE.CylinderGeometry(0.22, 0.28, 0.35, 20),
          new THREE.MeshBasicMaterial({ color: col }));
        p.position.set(alto ? i * 3.4 : i * 3.2, alto ? 3 : 0.18, alto ? -7.5 : -5.5 - Math.abs(i) * 0.6);
        s.add(p);
        const luce = new THREE.PointLight(col, 18, 9, 2);
        luce.position.set(i * 3.2, 1.5, -5.5 - Math.abs(i) * 0.6);
        s.add(luce);
        stato.pilastri.push(luce);
      }
      const anello = new THREE.Mesh(new THREE.TorusKnotGeometry(0.9, 0.22, 160, 16), new THREE.MeshStandardMaterial({ color: 0xffc83d, metalness: 0.35, roughness: 0.25, emissive: 0x3a2400 }));
      anello.position.set(-5.2, 3.6, -4);
      s.add(anello);
      stato.anello = anello;
      s.add(new THREE.HemisphereLight(0x8fb8ff, 0x101020, 1.1));
      const sp = new THREE.SpotLight(0xffffff, 60, 30, 0.5, 0.6, 1.5);
      sp.position.set(0, 9, 6); sp.target.position.set(0, 0, -4);
      s.add(sp, sp.target);
      stato.scena = s;
      stato.camera = new THREE.PerspectiveCamera(42, W / H, 0.1, 100);
    }
    const c = stato.camera;
    c.aspect = W / H; c.updateProjectionMatrix();
    c.position.set(Math.sin(t * 0.12) * 1.6, 2.3 + Math.sin(t * 0.09) * 0.2, 9.5);
    c.lookAt(0, 2.4, -6);
    studioSchermo(stato.tx, 1024, 256, t);
    stato.mappa.needsUpdate = true;
    stato.anello.rotation.set(t * 0.4, t * 0.7, 0);
    stato.pilastri.forEach((l, i) => { l.intensity = 14 + 8 * Math.sin(t * 1.7 + i); });
    disegna3D(o, W, H, stato.scena, c);
  }

  // --- Sfondo: cristalli 3D ----------------------------------------------
  function drawCristalli3D(o, W, H, t, stato) {
    const THREE = three();
    if (!THREE) return attesa3D(o, W, H, true);
    if (!stato.scena) {
      const s = new THREE.Scene();
      s.background = new THREE.Color(0x0c0420);
      s.fog = new THREE.FogExp2(0x0c0420, 0.06);
      const forme = [new THREE.IcosahedronGeometry(0.7, 0), new THREE.OctahedronGeometry(0.8, 0), new THREE.DodecahedronGeometry(0.65, 0)];
      const colori = [0x7b5cff, 0x00d4ff, 0xff4fd8, 0xffc23d, 0x3dffb0];
      stato.cristalli = [];
      for (let i = 0; i < 34; i++) {
        const m = new THREE.Mesh(forme[i % 3], new THREE.MeshStandardMaterial({ color: colori[i % 5], metalness: 0.35, roughness: 0.15, flatShading: true }));
        const a = i * 2.39996, r = 3 + (i % 7) * 1.1;
        m.userData = { a, r, y: ((i * 37) % 11) - 5, v: 0.2 + (i % 5) * 0.06 };
        m.scale.setScalar(0.6 + (i % 4) * 0.25);
        s.add(m);
        stato.cristalli.push(m);
      }
      const nodo = new THREE.Mesh(new THREE.TorusKnotGeometry(1.4, 0.35, 220, 24), new THREE.MeshStandardMaterial({ color: 0xe8e8ff, metalness: 0.3, roughness: 0.15 }));
      nodo.position.set(4, 0.5, -6);
      s.add(nodo);
      stato.nodo = nodo;
      s.add(new THREE.AmbientLight(0x6040a0, 0.6));
      stato.luci = [0xff2e9a, 0x00c8ff, 0xffd000].map((col) => { const l = new THREE.PointLight(col, 60, 30, 1.6); s.add(l); return l; });
      stato.scena = s;
      stato.camera = new THREE.PerspectiveCamera(55, W / H, 0.1, 100);
    }
    const c = stato.camera;
    c.aspect = W / H; c.updateProjectionMatrix();
    c.position.set(Math.sin(t * 0.07) * 2, Math.sin(t * 0.05), 10);
    c.lookAt(0, 0, 0);
    for (const m of stato.cristalli) {
      const d = m.userData, a = d.a + t * d.v * 0.3;
      m.position.set(Math.cos(a) * d.r, d.y + Math.sin(t * d.v + d.a) * 0.6, Math.sin(a) * d.r - 6);
      m.rotation.set(t * d.v, t * d.v * 1.3, 0);
    }
    stato.nodo.rotation.set(t * 0.3, t * 0.45, 0);
    stato.luci.forEach((l, i) => l.position.set(Math.cos(t * 0.5 + i * 2.1) * 7, Math.sin(t * 0.7 + i) * 4, Math.sin(t * 0.5 + i * 2.1) * 7 - 4));
    disegna3D(o, W, H, stato.scena, c);
  }

  // --- Effetti sulla scheda video (shader su tutto il fotogramma) ---------
  const VERTICE_PIENO = 'varying vec2 vUv; void main() { vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }';
  const SHADER = {
    bagliore: `uniform sampler2D mappa; uniform float k; uniform vec2 passo; varying vec2 vUv;
      void main() {
        vec4 base = texture2D(mappa, vUv);
        vec3 alone = vec3(0.0); float peso = 0.0;
        for (int a = 0; a < 12; a++) {
          float ang = float(a) * 0.5236;
          for (int r = 1; r <= 4; r++) {
            vec2 d = vec2(cos(ang), sin(ang)) * passo * float(r) * 7.0;
            float w = 1.0 / float(r);
            alone += max(texture2D(mappa, vUv + d).rgb - 0.55, 0.0) * w; peso += w;
          }
        }
        gl_FragColor = vec4(base.rgb + alone / peso * 5.0 * k, 1.0);
      }`,
    crt: `uniform sampler2D mappa; uniform float k; uniform float t; uniform vec2 ris; varying vec2 vUv;
      void main() {
        vec2 c = vUv - 0.5; float r2 = dot(c, c);
        vec2 uv = 0.5 + c * (1.0 - k * 0.12 + k * 0.3 * r2);
        if (uv.x < 0.0 || uv.x > 1.0 || uv.y < 0.0 || uv.y > 1.0) { gl_FragColor = vec4(0.0, 0.0, 0.0, 1.0); return; }
        float ab = k * 0.0025;
        vec3 col = vec3(texture2D(mappa, uv + vec2(ab, 0.0)).r, texture2D(mappa, uv).g, texture2D(mappa, uv - vec2(ab, 0.0)).b);
        float riga = 0.5 + 0.5 * sin(uv.y * ris.y * 3.14159);
        col *= mix(1.0, 0.6 + 0.4 * riga, k);
        float m = mod(floor(uv.x * ris.x), 3.0);
        vec3 maschera = m < 1.0 ? vec3(1.0, 0.7, 0.7) : (m < 2.0 ? vec3(0.7, 1.0, 0.7) : vec3(0.7, 0.7, 1.0));
        col *= mix(vec3(1.0), maschera, k * 0.7);
        col *= 1.0 - k * 0.6 * smoothstep(0.12, 0.5, r2);
        col *= 1.0 + k * (0.25 + 0.03 * sin(t * 50.0));
        gl_FragColor = vec4(col, 1.0);
      }`,
    aberrazione: `uniform sampler2D mappa; uniform float k; uniform float t; varying vec2 vUv;
      void main() {
        vec2 d = (vUv - 0.5) * k * 0.035 * (1.0 + 0.35 * sin(t * 2.3));
        gl_FragColor = vec4(texture2D(mappa, vUv + d).r, texture2D(mappa, vUv).g, texture2D(mappa, vUv - d).b, 1.0);
      }`
  };

  function effettoGPU(nome) {
    return ({ o, W, H, k, out, stato, t }) => {
      const THREE = three();
      if (!THREE) return attesa3D(o, W, H, false);
      if (!stato.scena) {
        stato.mappa = new THREE.CanvasTexture(out);
        stato.mappa.minFilter = THREE.LinearFilter;
        stato.mappa.generateMipmaps = false;
        stato.mat = new THREE.ShaderMaterial({
          uniforms: { mappa: { value: stato.mappa }, k: { value: 0 }, t: { value: 0 }, passo: { value: new THREE.Vector2() }, ris: { value: new THREE.Vector2() } },
          vertexShader: VERTICE_PIENO, fragmentShader: SHADER[nome], depthTest: false, depthWrite: false
        });
        stato.scena = new THREE.Scene();
        stato.scena.add(new THREE.Mesh(new THREE.PlaneGeometry(2, 2), stato.mat));
        stato.camera = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1);
      }
      if (stato.mappa.image !== out) stato.mappa.image = out;
      stato.mappa.needsUpdate = true;
      const u = stato.mat.uniforms;
      u.k.value = k; u.t.value = t;
      u.passo.value.set(1 / W, 1 / H);
      u.ris.value.set(W, H);
      disegna3D(o, W, H, stato.scena, stato.camera);
    };
  }

  // --- Oggetti 3D che seguono il volto ------------------------------------
  // Posizione e dimensione dai punti del volto (MediaPipe FaceLandmarker), rotazione dalla
  // matrice della posa della testa. Unità degli oggetti: 1 = larghezza del volto.
  const IDX = { occhioD: 33, occhioS: 263, radice: 168, fronte: 10, mento: 152, guanciaD: 234, guanciaS: 454 };

  function posaVolto(THREE, v, stato) {
    const P = v.punti, W = v.W, H = v.H;
    const p = (i) => new THREE.Vector3(P[i].x * W - W / 2, H / 2 - P[i].y * H, 0);
    const larg = p(IDX.guanciaD).distanceTo(p(IDX.guanciaS));
    const alt = p(IDX.fronte).distanceTo(p(IDX.mento));
    const q = new THREE.Quaternion();
    if (v.matrice) {
      const m = new THREE.Matrix4().fromArray(v.matrice);
      m.decompose(new THREE.Vector3(), q, new THREE.Vector3());
    } else {
      const a = p(IDX.occhioD), b = p(IDX.occhioS);
      q.setFromAxisAngle(new THREE.Vector3(0, 0, 1), Math.atan2(b.y - a.y, b.x - a.x));
    }
    const nuova = { radice: p(IDX.radice), fronte: p(IDX.fronte), centro: p(IDX.fronte).lerp(p(IDX.mento), 0.5), larg, alt, q };
    // un po' di smorzamento contro il tremolio
    const prec = stato.posa;
    if (prec) {
      const f = 0.55;
      nuova.radice.lerp(prec.radice, 1 - f); nuova.fronte.lerp(prec.fronte, 1 - f); nuova.centro.lerp(prec.centro, 1 - f);
      nuova.larg = prec.larg * (1 - f) + larg * f; nuova.alt = prec.alt * (1 - f) + alt * f;
      nuova.q = prec.q.clone().slerp(q, f);
    }
    stato.posa = nuova;
    return nuova;
  }

  function scenaVolto(THREE, stato, W, H) {
    if (!stato.scena) {
      const s = new THREE.Scene();
      s.add(new THREE.AmbientLight(0xffffff, 1.4));
      const d = new THREE.DirectionalLight(0xffffff, 2.2);
      d.position.set(-0.4, 0.8, 1);
      s.add(d);
      // testa invisibile: nasconde le parti degli oggetti che passano dietro la testa
      const testa = new THREE.Mesh(new THREE.SphereGeometry(1, 32, 24), new THREE.MeshBasicMaterial({ colorWrite: false }));
      testa.renderOrder = -1;
      s.add(testa);
      stato.testa = testa;
      stato.scena = s;
      stato.camera = new THREE.OrthographicCamera(-W / 2, W / 2, H / 2, -H / 2, -20000, 20000);
      stato.camera.position.z = 10000;
    }
    const c = stato.camera;
    if (c.right !== W / 2 || c.top !== H / 2) { c.left = -W / 2; c.right = W / 2; c.top = H / 2; c.bottom = -H / 2; c.updateProjectionMatrix(); }
    return stato.scena;
  }

  // la testa invisibile, nel sistema della testa (unità = larghezza del volto)
  function piazzaTesta(stato, posa, origine, s) {
    const t = stato.testa;
    t.position.copy(origine).add(THREE_TMP.v.set(0, -0.1 * s, -0.62 * s).applyQuaternion(posa.q));
    t.quaternion.copy(posa.q);
    t.scale.set(0.5 * s, 0.68 * s, 0.6 * s);
  }
  const THREE_TMP = { v: null };

  function statoVoltoTesto(o, W, H, vs) {
    if (vs.state === 'ready') return;
    const u = H / 720;
    o.font = `600 ${Math.round(18 * u)}px ${SANS}`;
    o.textBaseline = 'bottom';
    o.fillStyle = vs.state === 'error' ? '#ff8080' : 'rgba(255,255,255,0.75)';
    o.fillText(vs.state === 'error' ? tr('Face tracking not available: {error}', { error: vs.error }) : tr('Loading face tracking…'), 16 * u, H - 14 * u);
  }

  function effettoVolto(costruisci, aggiorna) {
    return ({ o, W, H, k, stato, volto, voltoStato }) => {
      const THREE = three();
      if (!THREE) return attesa3D(o, W, H, false);
      if (!THREE_TMP.v) THREE_TMP.v = new THREE.Vector3();
      statoVoltoTesto(o, W, H, voltoStato);
      if (!volto) { stato.posa = null; return; }
      const scena = scenaVolto(THREE, stato, W, H);
      if (!stato.oggetto) { stato.oggetto = costruisci(THREE); scena.add(stato.oggetto); }
      const posa = posaVolto(THREE, volto, stato);
      aggiorna(THREE, stato, posa, 0.8 + 0.4 * k, volto.espressioni || {});
      disegna3D(o, W, H, scena, stato.camera);
    };
  }

  function costruisciOcchiali(THREE) {
    const g = new THREE.Group();
    const montatura = new THREE.MeshStandardMaterial({ color: 0xd11f3a, metalness: 0.4, roughness: 0.3 });
    const lente = new THREE.MeshStandardMaterial({ color: 0x10204a, metalness: 0.2, roughness: 0.05, transparent: true, opacity: 0.55, side: THREE.DoubleSide });
    for (const x of [-0.225, 0.225]) {
      const anello = new THREE.Mesh(new THREE.TorusGeometry(0.19, 0.028, 14, 40), montatura);
      anello.position.x = x;
      const vetro = new THREE.Mesh(new THREE.CircleGeometry(0.185, 40), lente);
      vetro.position.set(x, 0, -0.005);
      const asta = new THREE.Mesh(new THREE.BoxGeometry(0.03, 0.035, 0.6), montatura);
      asta.position.set(x * 1.93, 0.02, -0.3);
      g.add(anello, vetro, asta);
    }
    const ponte = new THREE.Mesh(new THREE.TorusGeometry(0.05, 0.02, 10, 20, Math.PI), montatura);
    ponte.position.y = 0.03;
    g.add(ponte);
    return g;
  }

  function aggiornaOcchiali(THREE, stato, posa, dim) {
    const s = posa.larg * dim;
    stato.oggetto.position.copy(posa.radice).add(THREE_TMP.v.set(0, -0.02 * s, 0.08 * s).applyQuaternion(posa.q));
    stato.oggetto.quaternion.copy(posa.q);
    stato.oggetto.scale.setScalar(s);
    piazzaTesta(stato, posa, posa.radice, posa.larg);
  }

  function costruisciCorona(THREE) {
    const g = new THREE.Group();
    const oro = new THREE.MeshStandardMaterial({ color: 0xffc83d, metalness: 0.45, roughness: 0.28, emissive: 0x4a2f00, side: THREE.DoubleSide });
    g.add(new THREE.Mesh(new THREE.CylinderGeometry(0.36, 0.4, 0.16, 48, 1, true), oro));
    const gemme = [0xe0115f, 0x1e90ff, 0x2ecc71];
    for (let i = 0; i < 8; i++) {
      const a = (i / 8) * Math.PI * 2;
      const punta = new THREE.Mesh(new THREE.ConeGeometry(0.055, 0.2, 12), oro);
      punta.position.set(Math.sin(a) * 0.37, 0.17, Math.cos(a) * 0.37);
      const sfera = new THREE.Mesh(new THREE.SphereGeometry(0.025, 12, 8), oro);
      sfera.position.set(Math.sin(a) * 0.37, 0.28, Math.cos(a) * 0.37);
      const gemma = new THREE.Mesh(new THREE.OctahedronGeometry(0.04, 0), new THREE.MeshStandardMaterial({ color: gemme[i % 3], metalness: 0.3, roughness: 0.1 }));
      gemma.position.set(Math.sin(a) * 0.395, 0, Math.cos(a) * 0.395);
      g.add(punta, sfera, gemma);
    }
    return g;
  }

  function aggiornaCorona(THREE, stato, posa, dim) {
    const s = posa.larg * dim;
    const o = stato.oggetto;
    o.position.copy(posa.fronte).add(THREE_TMP.v.set(0, 0.2 * posa.larg, -0.42 * posa.larg).applyQuaternion(posa.q));
    o.quaternion.copy(posa.q).multiply(new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1, 0, 0), -0.18));
    o.scale.setScalar(s);
    piazzaTesta(stato, posa, posa.radice, posa.larg);
  }

  function costruisciAvatar(THREE) {
    const g = new THREE.Group();
    const metallo = new THREE.MeshStandardMaterial({ color: 0xc9d3e0, metalness: 0.35, roughness: 0.35 });
    const scuro = new THREE.MeshStandardMaterial({ color: 0x11161f, metalness: 0.3, roughness: 0.4 });
    const luce = new THREE.MeshBasicMaterial({ color: 0x35e7ff });
    const testa = new THREE.Mesh(new THREE.BoxGeometry(0.9, 1.05, 0.8), metallo);
    const visiera = new THREE.Mesh(new THREE.BoxGeometry(0.74, 0.42, 0.04), scuro);
    visiera.position.set(0, 0.12, 0.41);
    const occhi = [-0.18, 0.18].map((x) => { const e = new THREE.Mesh(new THREE.SphereGeometry(0.075, 20, 14), luce); e.position.set(x, 0.12, 0.44); return e; });
    const bocca = new THREE.Mesh(new THREE.BoxGeometry(0.36, 0.06, 0.04), luce);
    bocca.position.set(0, -0.27, 0.41);
    const orecchie = [-0.48, 0.48].map((x) => { const e = new THREE.Mesh(new THREE.CylinderGeometry(0.11, 0.11, 0.08, 24), scuro); e.rotation.z = Math.PI / 2; e.position.set(x, 0.05, 0); return e; });
    const asta = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.02, 0.26, 8), metallo);
    asta.position.y = 0.65;
    const pallina = new THREE.Mesh(new THREE.SphereGeometry(0.06, 16, 12), new THREE.MeshBasicMaterial({ color: 0xff3d6e }));
    pallina.position.y = 0.8;
    g.add(testa, visiera, ...occhi, bocca, ...orecchie, asta, pallina);
    g.userData = { occhi, bocca, pallina };
    return g;
  }

  function aggiornaAvatar(THREE, stato, posa, dim, esp) {
    const s = posa.alt * 1.35 * dim;
    const o = stato.oggetto, u = o.userData;
    o.position.copy(posa.centro).add(THREE_TMP.v.set(0, 0.06 * s, -0.42 * s).applyQuaternion(posa.q));
    o.quaternion.copy(posa.q);
    o.scale.setScalar(s);
    u.occhi[0].scale.y = Math.max(0.08, 1 - (esp.eyeBlinkRight || 0) * 1.1);
    u.occhi[1].scale.y = Math.max(0.08, 1 - (esp.eyeBlinkLeft || 0) * 1.1);
    u.bocca.scale.y = 1 + (esp.jawOpen || 0) * 6;
    u.bocca.scale.x = 1 + ((esp.mouthSmileLeft || 0) + (esp.mouthSmileRight || 0)) * 0.35;
    u.pallina.material.color.setHSL((performance.now() / 4000) % 1, 0.9, 0.6);
    stato.testa.scale.setScalar(0.0001);   // l'avatar copre tutto: niente testa invisibile
  }

  // --- Logo 3D rotante nell'angolo ------------------------------------------
  function disegnaMoneta(x, w, h, testo, img) {
    const g = x.createRadialGradient(w / 2, h / 2, 20, w / 2, h / 2, w / 2);
    g.addColorStop(0, '#1e5bff'); g.addColorStop(1, '#0a1f66');
    x.clearRect(0, 0, w, h);
    x.fillStyle = g; x.beginPath(); x.arc(w / 2, h / 2, w / 2, 0, 6.3); x.fill();
    if (img) {
      // immagine dell'utente, adattata dentro il cerchio
      x.save();
      x.beginPath(); x.arc(w / 2, h / 2, w / 2 - 28, 0, 6.3); x.clip();
      const r = w - 56, k = Math.min(r / img.width, r / img.height);
      x.fillStyle = '#ffffff'; x.fillRect(28, 28, r, r);
      x.drawImage(img, (w - img.width * k) / 2, (h - img.height * k) / 2, img.width * k, img.height * k);
      x.restore();
      x.strokeStyle = '#ffd34d'; x.lineWidth = 18; x.beginPath(); x.arc(w / 2, h / 2, w / 2 - 20, 0, 6.3); x.stroke();
      return;
    }
    x.strokeStyle = '#ffd34d'; x.lineWidth = 18; x.beginPath(); x.arc(w / 2, h / 2, w / 2 - 20, 0, 6.3); x.stroke();
    let size = 150;
    x.font = `900 ${size}px ${SANS}`;
    while (x.measureText(testo).width > w * 0.74 && size > 28) { size -= 4; x.font = `900 ${size}px ${SANS}`; }
    x.fillStyle = '#ffffff'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(testo, w / 2, h / 2 + size * 0.05);
    x.textAlign = 'left';
  }

  function logo3D({ o, W, H, k, stato, info, t }) {
    const THREE = three();
    if (!THREE) return attesa3D(o, W, H, false);
    // immagine del logo, se c'è (decodificata una volta); altrimenti testo del logo,
    // testo sovrapposto o nome della webcam
    const logo = (info && info.logo) || {};
    if (logo.immagine !== stato.logoSrc) {
      stato.logoSrc = logo.immagine;
      stato.logoImg = null;
      if (logo.immagine && U.decodeDataUrl) {
        const src = logo.immagine;
        U.decodeDataUrl(src).then((b) => { if (stato.logoSrc === src) stato.logoImg = b; }).catch(() => {});
      }
    }
    const scritta = ((logo.testo || (info && (info.testo || info.nome)) || 'CamMixer').trim().slice(0, 24)) || 'CamMixer';
    const testo = stato.logoImg ? `img:${stato.logoSrc.length}:${stato.logoSrc.slice(-32)}` : scritta;
    const disegna = (x, w, h) => disegnaMoneta(x, w, h, scritta, stato.logoImg);
    if (!stato.scena) {
      const s = new THREE.Scene();
      s.add(new THREE.AmbientLight(0xffffff, 1.2));
      const d = new THREE.DirectionalLight(0xffffff, 2.5);
      d.position.set(1, 1, 2);
      s.add(d);
      telaTesto(stato, testo, disegna);
      stato.mappa = new THREE.CanvasTexture(stato.tt);
      stato.mappa.colorSpace = THREE.SRGBColorSpace;
      stato.mappa.center.set(0.5, 0.5);
      const faccia = new THREE.MeshStandardMaterial({ map: stato.mappa, metalness: 0.2, roughness: 0.4 });
      const bordo = new THREE.MeshStandardMaterial({ color: 0xffc83d, metalness: 0.45, roughness: 0.3, emissive: 0x3a2400 });
      const moneta = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 0.16, 64), [bordo, faccia, faccia]);
      moneta.rotation.x = Math.PI / 2;
      stato.perno = new THREE.Group();
      stato.perno.add(moneta);
      s.add(stato.perno);
      stato.scena = s;
      stato.camera = new THREE.OrthographicCamera(-W / 2, W / 2, H / 2, -H / 2, -5000, 5000);
      stato.camera.position.z = 1000;
    } else if (telaTesto(stato, testo, disegna)) {
      stato.mappa.needsUpdate = true;
    }
    const c = stato.camera;
    if (c.right !== W / 2 || c.top !== H / 2) { c.left = -W / 2; c.right = W / 2; c.top = H / 2; c.bottom = -H / 2; c.updateProjectionMatrix(); }
    const r = H * (0.06 + 0.08 * k), m = H * 0.04;
    stato.perno.position.set(W / 2 - r - m, H / 2 - r - m, 0);
    stato.perno.scale.setScalar(r);
    stato.perno.rotation.y = t * 1.3;
    // sulle facce del cilindro la trama risulta girata di 90°: +90° la raddrizza (su entrambe le facce);
    // la rotazione scelta nelle impostazioni (gradi, senso orario) gira il contenuto dentro la moneta
    stato.mappa.rotation = Math.PI / 2 - ((Number(logo.rotazione) || 0) * Math.PI) / 180;
    disegna3D(o, W, H, stato.scena, c);
  }

  // -------------------------------------------------------------------
  // Registrazione
  // -------------------------------------------------------------------

  C.register({
    versione: '1.8 · 2026-11-01 · digital rain',
    sfondi: [
      { id: 'synthwave', label: 'Neon grid (animated)', draw: drawSynthwave },
      { id: 'stars',     label: 'Starfield (animated)',  draw: drawStars },
      { id: 'tunnel',    label: 'Ring tunnel (animated)', draw: drawTunnel },
      { id: 'aurora',    label: 'Northern lights (animated)',  draw: drawAurora },
      { id: 'scope',     label: 'Oscilloscope (animated)',   draw: drawScope },
      { id: 'lava',      label: 'Lava lamp (animated)', draw: drawLava },
      { id: 'plasma',    label: 'Plasma (animated)',          draw: drawPlasma },
      { id: 'vhs',       label: 'VHS noise (animated)',    draw: drawVhs },
      { id: 'fosfori',   label: 'Green phosphor terminal (animated)', draw: drawFosfori },
      { id: 'cga',       label: 'CGA graphics (animated)', draw: drawCga },
      { id: 'ega',       label: 'EGA graphics (animated)', draw: drawEga },
      { id: 'pioggia',   label: 'Digital rain (animated)', draw: drawPioggia },
      { id: 'studio-3d',    label: '3D TV studio (3D example)', draw: drawStudio3D, tre_d: true },
      { id: 'cristalli-3d', label: '3D crystals (3D example)', draw: drawCristalli3D, tre_d: true }
    ],
    effetti: [
      { id: 'scan',     label: 'TV scanlines',     apply: scanlines },
      { id: 'glitch',   label: 'Glitch',       apply: glitch },
      { id: 'grain',    label: 'Film grain',        apply: grain },
      { id: 'vignette', label: 'Vignette', apply: vignette },
      { id: 'fosfori-verdi', label: 'Green phosphor monitor', apply: fosforiVerdi },
      { id: 'cga-colori',    label: 'CGA palette (4 colours)', apply: effettoTavolozza(CGA, 150) },
      { id: 'ega-colori',    label: 'EGA palette (16 colours)', apply: effettoTavolozza(EGA, 80) },
      { id: 'bagliore-gpu',    label: 'Glow (3D, graphics card)',          apply: effettoGPU('bagliore'), tre_d: true },
      { id: 'crt-gpu',         label: 'CRT monitor (3D, graphics card)',       apply: effettoGPU('crt'), tre_d: true },
      { id: 'aberrazione-gpu', label: 'Chromatic aberration (3D, graphics card)', apply: effettoGPU('aberrazione'), tre_d: true },
      { id: 'occhiali-3d',     label: '3D glasses (follow your face)',       apply: effettoVolto(costruisciOcchiali, aggiornaOcchiali), tre_d: true, volto: true, breve: '🕶️ Glasses' },
      { id: 'corona-3d',       label: '3D crown (follows your face)',           apply: effettoVolto(costruisciCorona, aggiornaCorona), tre_d: true, volto: true, breve: '👑 Crown' },
      { id: 'avatar-3d',       label: '3D robot avatar (covers your face)',     apply: effettoVolto(costruisciAvatar, aggiornaAvatar), tre_d: true, volto: true, breve: '🤖 Robot' },
      { id: 'logo-3d',         label: 'Rotating 3D logo',                      apply: logo3D, tre_d: true }
    ],
    sottopancia: [
      { id: 'ultimora',     label: 'Breaking news (red)',  blocco: ultimoraBlocco,     striscia: ultimoraStriscia },
      { id: 'telegiornale', label: 'TV news (blue)', blocco: telegiornaleBlocco, striscia: telegiornaleStriscia },
      { id: 'minimal',      label: 'Minimal',            blocco: minimalBlocco,      striscia: minimalStriscia },
      { id: 'neon',         label: 'Neon',               blocco: neonBlocco,         striscia: neonStriscia },
      { id: 'sport',        label: 'Sport',              blocco: sportBlocco,        striscia: sportStriscia }
    ],
    animazioni: [
      { id: 'pulse',   label: 'Pulse',      apply: ({ t }) => ({ scale: 1 + 0.12 * Math.sin(t * Math.PI * 2.4) }) },
      { id: 'bounce',  label: 'Bounce',   apply: ({ t, size }) => ({ dy: -Math.abs(Math.sin(t * Math.PI * 1.4)) * size * 0.6 }) },
      { id: 'float',   label: 'Float',    apply: ({ t, W, H }) => ({ dx: Math.sin(t * 0.9) * W * 0.02, dy: Math.sin(t * 1.3) * H * 0.02, rot: Math.sin(t * 0.7) * 0.08 }) },
      { id: 'spin',    label: 'Spin',      apply: ({ t }) => ({ rot: (t * Math.PI * 2) / 3 }) },
      { id: 'blink',   label: 'Blink',  apply: ({ t }) => ({ hidden: (t * 1.4) % 1 > 0.6 }) },
      { id: 'marquee', label: 'Scroll',     apply: ({ now, W, width }) => ({ x: W + width / 2 - ((now * W * 0.15) % (W + width + W * 0.1)) }) },
      { id: 'rainbow', label: 'Rainbow', soloTesto: true, apply: ({ t }) => ({ color: `hsl(${(t * 90) % 360}, 95%, 62%)` }) }
    ]
  });
})();
