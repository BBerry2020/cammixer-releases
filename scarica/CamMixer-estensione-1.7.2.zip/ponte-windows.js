/*
 * CamMixer - invio alle app del computer (documento offscreen)
 *
 * Si collega al programma ponte (Windows: CamMixer.exe; macOS: cammixer-ponte
 * per OBS) su ws://127.0.0.1:47801. Quando un'app apre la webcam "CamMixer" (Windows)
 * o OBS legge il flusso (macOS), il ponte lo segnala con la risoluzione richiesta: qui si
 * avvia la webcam virtuale scelta e se ne inviano i fotogrammi in JPEG. Quando l'app la
 * chiude, la webcam reale si spegne.
 * Nei documenti offscreen c'è solo chrome.runtime: impostazioni e stato passano dal service worker.
 */
(() => {
  'use strict';
  const C = WebcamVirtualiCore;
  const T = C.T;   // messaggi nella lingua scelta (lingua.js)
  const URL_PONTE = 'ws://127.0.0.1:47801/';
  const QUALITA_JPEG = 0.8;
  const MAX_LATO = 1280;   // oltre non serve: la webcam virtuale esce al massimo a 1280 pixel di larghezza

  let ws = null;
  let collegato = false;
  let ritardo = 1000;
  let ponte = {};                  // ultimo stato dal programma ponte
  let impostazioni = { attiva: true, webcam: '' };
  let vcam = null;
  let spegni = null;
  let avvisoInviato = '';
  let inVolo = false;
  let inviati = 0, fps = 0, contaDa = performance.now();
  // Versione dell'estensione: nei documenti offscreen di Edge chrome.runtime.getManifest non c'è,
  // quindi si legge manifest.json (all'avvio, prima di collegarsi)
  let versioneEstensione = '';
  async function leggiVersione() {
    try { if (typeof chrome.runtime.getManifest === 'function') return chrome.runtime.getManifest().version || ''; } catch { /* sotto */ }
    try { return (await (await fetch(chrome.runtime.getURL('manifest.json'))).json()).version || ''; } catch { return ''; }
  }
  const tela = new OffscreenCanvas(1280, 720);
  const tctx = tela.getContext('2d');

  const env = {
    getUserMedia: (c) => navigator.mediaDevices.getUserMedia(c),
    enumerateDevices: () => navigator.mediaDevices.enumerateDevices(),
    onChange: () => { avvisa(); riferisci(); },
    onFrame: (v) => invia(v)
  };

  C.setBase(chrome.runtime.getURL(''));
  C.setSegmentationProvider(async (nome = 'ritaglio') => {
    const vision = await import(chrome.runtime.getURL('mediapipe/vision_bundle.mjs'));
    const r = await chrome.runtime.sendMessage({ type: 'get-model', modello: nome });
    if (!r || !r.ok) throw new Error((r && r.error) || T('model not available'));
    const bin = atob(r.data);
    const model = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) model[i] = bin.charCodeAt(i);
    return { vision, wasmPath: chrome.runtime.getURL('mediapipe/wasm'), model };
  });

  const chiedi = async (msg) => {
    const r = await chrome.runtime.sendMessage(msg);
    if (!r || !r.ok) throw new Error((r && r.error) || T('no answer'));
    return r.data;
  };

  // ---------------------------------------------------------------------
  // Stato per la pagina delle impostazioni
  // ---------------------------------------------------------------------
  let riferito = '';
  function riferisci() {
    const stato = {
      collegato,
      versionePonte: ponte.versione || '',
      piattaforma: ponte.piattaforma || '',
      indirizzoObs: ponte.indirizzoObs || '',
      aggiornamento: ponte.aggiornamento || '',
      statoAggiornamento: ponte.statoAggiornamento || '',
      camera: ponte.camera || '',
      erroreCamera: ponte.errore || '',
      consumatore: !!(collegato && ponte.consumatore),
      larghezza: ponte.larghezza || 0,
      altezza: ponte.altezza || 0,
      app: ponte.app || '',
      fps,
      webcam: vcam ? vcam.name : '',
      acceso: !!(vcam && vcam.running),
      errore: vcam && vcam.status === 'error' ? vcam.error : ''
    };
    const testo = JSON.stringify(stato);
    if (testo === riferito) return;
    riferito = testo;
    chrome.runtime.sendMessage({ type: 'windows-stato', stato }).catch(() => {});
  }

  // Messaggio mostrato nella webcam di Windows al posto del video (es. webcam reale non disponibile)
  function avvisa() {
    const testo = vcam && vcam.status === 'error' ? vcam.error : '';
    if (testo === avvisoInviato || !ws || ws.readyState !== WebSocket.OPEN) return;
    avvisoInviato = testo;
    ws.send(JSON.stringify({ tipo: 'avviso', testo }));
  }

  // Lingua dell'interfaccia: anche il programma la usa per le sue schermate (attesa, messaggi)
  function impostaLingua(s) {
    if (!CamMixerLingua.imposta(s.lingua)) return;
    if (ws && ws.readyState === WebSocket.OPEN) ws.send(JSON.stringify({ tipo: 'lingua', lingua: CamMixerLingua.attuale }));
    avvisoInviato = '';   // il messaggio di errore, ora nella nuova lingua, si rimanda
    avvisa();
  }

  // ---------------------------------------------------------------------
  // Collegamento al programma ponte
  // ---------------------------------------------------------------------
  function collega() {
    if (ws) return;
    try {
      ws = new WebSocket(URL_PONTE);
    } catch {
      setTimeout(collega, ritardo);
      return;
    }
    ws.onopen = () => {
      collegato = true;
      ritardo = 1000;
      avvisoInviato = '';
      ws.send(JSON.stringify({ tipo: 'ciao', versione: versioneEstensione, webcam: vcam ? vcam.name : '', lingua: CamMixerLingua.attuale }));
      avvisa();
      riferisci();
    };
    ws.onmessage = (e) => {
      if (typeof e.data !== 'string') return;
      try { ponte = JSON.parse(e.data); } catch { return; }
      aggiornaUso();
      riferisci();
    };
    ws.onclose = () => {
      const era = collegato;
      ws = null;
      collegato = false;
      ponte = {};
      aggiornaUso();
      riferisci();
      setTimeout(collega, era ? 1000 : ritardo);
      if (!era) ritardo = Math.min(ritardo * 2, 30000);
    };
    ws.onerror = () => {};   // segue onclose
  }

  // ---------------------------------------------------------------------
  // Webcam virtuale accesa solo mentre un'app di Windows la usa
  // ---------------------------------------------------------------------
  async function aggiornaUso() {
    const serve = collegato && ponte.consumatore && impostazioni.attiva;
    if (serve) {
      clearTimeout(spegni);
      spegni = null;
      await preparaVcam(true).catch(() => {});
    } else if (vcam && (vcam.running || vcam.starting) && !spegni) {
      // breve attesa: le app a volte chiudono e riaprono subito la webcam
      spegni = setTimeout(() => {
        spegni = null;
        if (vcam && !(collegato && ponte.consumatore)) { vcam.stop(true); fps = 0; riferisci(); }
      }, 4000);
    }
  }

  async function preparaVcam(avvia) {
    const [state, imp] = await Promise.all([chiedi({ type: 'get-state' }), chiedi({ type: 'get-windows' })]);
    impostazioni = imp;
    const s = C.normalizeState(state);
    impostaLingua(s);
    C.setEsempi3D(s.esempi3d);
    const id = imp.webcam && s.vcams.some((c) => c.id === imp.webcam) ? imp.webcam : s.defaultId;
    const cfg = s.vcams.find((c) => c.id === id) || s.vcams[0];
    if (vcam && vcam.id !== cfg.id) { vcam.stop(false); vcam = null; }
    if (!vcam) vcam = new C.VCam(cfg, env);
    else vcam.update(cfg);
    if (avvia) {
      if (cfg.fx.bg !== 'none' && cfg.source !== C.NO_CAMERA) C.loadSegmenter();
      await vcam.ensure().catch(() => {});
    }
    riferisci();
  }

  // ---------------------------------------------------------------------
  // Invio dei fotogrammi: riempie la risoluzione chiesta dall'app, in JPEG
  // ---------------------------------------------------------------------
  async function invia(v) {
    const ora = performance.now();
    if (ora - contaDa >= 2000) {
      fps = Math.round((inviati * 1000) / (ora - contaDa));
      inviati = 0;
      contaDa = ora;
      riferisci();
    }
    if (inVolo || !ws || ws.readyState !== WebSocket.OPEN || !ponte.consumatore) return;
    if (ws.bufferedAmount > 1.5e6) return;   // il ponte è indietro: si salta un fotogramma
    // Se l'app chiede più della webcam virtuale (es. 1920x1080) si invia alla sua risoluzione:
    // ingrandire costerebbe una codifica JPEG molto più lenta senza dettagli in più; il programma
    // ponte adatta l'immagine alla risoluzione richiesta.
    const RL = ponte.larghezza || 1280, RA = ponte.altezza || 720;
    const ridotto = Math.min(1, MAX_LATO / RL, Math.max(v.out.width, 2) / RL);
    const L = Math.max(2, Math.round(RL * ridotto / 2) * 2), A = Math.max(2, Math.round(RA * ridotto / 2) * 2);
    if (tela.width !== L || tela.height !== A) { tela.width = L; tela.height = A; }
    const W = v.out.width, H = v.out.height;
    if (!W || !H) return;
    const k = Math.max(L / W, A / H), dw = W * k, dh = H * k;
    tctx.drawImage(v.out, (L - dw) / 2, (A - dh) / 2, dw, dh);
    inVolo = true;
    try {
      const blob = await tela.convertToBlob({ type: 'image/jpeg', quality: QUALITA_JPEG });
      if (ws && ws.readyState === WebSocket.OPEN) { ws.send(blob); inviati++; }
    } catch { /* fotogramma perso */ } finally {
      inVolo = false;
    }
  }

  // ---------------------------------------------------------------------
  // Componenti aggiornabili al volo (come nella pagina delle impostazioni)
  // ---------------------------------------------------------------------
  let componentsHash = '';
  function reloadComponents(hash) {
    if (!hash || hash === componentsHash) return;
    componentsHash = hash;
    const s = document.createElement('script');
    s.src = `componenti/componenti.js?v=${encodeURIComponent(hash)}`;
    s.onload = s.onerror = () => s.remove();
    document.head.append(s);
  }

  async function controllaComponenti() {
    // mentre un'app usa la webcam il motore non si ricarica (inUso)
    try {
      const r = await chiedi({ type: 'check-components', inUso: !!(vcam && vcam.running && ponte.consumatore) });
      reloadComponents(r.hash);
    } catch { /* ignora */ }
  }

  chrome.runtime.onMessage.addListener((msg, sender) => {
    // comandi dalla pagina delle impostazioni: aggiornare il programma per Windows/macOS
    if (msg && msg.type === 'windows-comando') {
      // solo dalla pagina delle impostazioni (non dagli script nei siti)
      if (sender.id !== chrome.runtime.id || !String(sender.url || '').startsWith(chrome.runtime.getURL('options.html'))) return false;
      if (['aggiorna', 'controlla-aggiornamenti'].includes(msg.comando) && ws && ws.readyState === WebSocket.OPEN) {
        ws.send(JSON.stringify({ tipo: msg.comando }));
      }
      return false;
    }
    if (!msg || msg.type !== 'windows-aggiorna') return false;
    if (msg.components) reloadComponents(msg.components);
    if (vcam || msg.impostazioni) preparaVcam(false).then(aggiornaUso).catch(() => {});
    else chiedi({ type: 'get-state' }).then((s) => impostaLingua(C.normalizeState(s))).catch(() => {});
    return false;
  });

  // ---------------------------------------------------------------------
  // Avvio
  // ---------------------------------------------------------------------
  (async () => {
    versioneEstensione = await leggiVersione();
    try { impostaLingua(C.normalizeState(await chiedi({ type: 'get-state' }))); } catch { /* inglese */ }
    try { impostazioni = await chiedi({ type: 'get-windows' }); } catch { /* predefinite */ }
    try { componentsHash = (await chiedi({ type: 'check-components' })).hash || ''; } catch { /* ignora */ }
    setInterval(controllaComponenti, 10000);
    collega();
    riferisci();
  })();
})();
