/*
 * CamMixer - interface languages: English (default) and Italian.
 *
 * Texts are written in English in the code; T('text', { values }) returns them in the chosen
 * language, with {name} placeholders filled in. Dictionaries for other languages are in
 * lingua-<id>.js (lingua-it.js: Italian) and are keyed by the English text.
 * In pages, elements with the data-t attribute are translated as a whole (static HTML of the
 * extension), and so are title, placeholder and aria-label attributes found in the dictionary.
 * The language is stored in the settings (state.lingua) and applies to the settings page,
 * the panel inside websites, the video and the CamMixer programs.
 */
var CamMixerLingua = CamMixerLingua || (() => {
  'use strict';

  const LINGUE = [
    { id: 'en', nome: 'English', bandiera: 'gb', locale: 'en-GB' },
    { id: 'it', nome: 'Italiano', bandiera: 'it', locale: 'it-IT' }
  ];
  const BASE = 'en';
  const DIZIONARI = {};                  // { it: { 'English text': 'Testo italiano' } }
  let attuale = BASE;
  const mancanti = new Set();            // texts without a translation (checked by the tests)
  const ascoltatori = new Set();
  const norm = (s) => String(s).replace(/\s+/g, ' ').trim();

  function T(testo, valori) {
    let r = testo;
    if (typeof testo === 'string' && testo && attuale !== BASE) {
      const d = DIZIONARI[attuale] || {};
      const t = d[testo] !== undefined ? d[testo] : d[norm(testo)];
      if (t !== undefined) r = t; else mancanti.add(testo);
    }
    if (valori && typeof r === 'string') {
      r = r.replace(/\{(\w+)\}/g, (m, k) => (valori[k] !== undefined && valori[k] !== null ? String(valori[k]) : m));
    }
    return r;
  }

  const valida = (l) => (LINGUE.some((x) => x.id === l) ? l : BASE);

  function imposta(l) {
    const n = valida(l);
    if (n === attuale) return false;
    attuale = n;
    for (const f of ascoltatori) { try { f(n); } catch { /* ignore */ } }
    return true;
  }

  const ATTRIBUTI = ['title', 'placeholder', 'aria-label'];
  function traduciPagina(radice) {
    const root = radice || (typeof document !== 'undefined' ? document : null);
    if (!root || !root.querySelectorAll) return;
    for (const el of root.querySelectorAll('[data-t]')) {
      if (el.dataset.tEn === undefined) el.dataset.tEn = norm(el.innerHTML);
      const html = T(el.dataset.tEn);
      if (norm(el.innerHTML) !== norm(html)) el.innerHTML = html;
    }
    for (const a of ATTRIBUTI) {
      const k = `tEn${a.replace('-', '')}`;
      for (const el of root.querySelectorAll(`[${a}]`)) {
        if (el.dataset[k] === undefined) {
          const v = el.getAttribute(a);
          if (!/[a-z]{3}/i.test(v)) continue;
          el.dataset[k] = v;
        }
        el.setAttribute(a, T(el.dataset[k]));
      }
    }
    if (root.documentElement) root.documentElement.lang = attuale;
  }

  // Drawn flags (flag emoji are not shown on Windows). Built with DOM calls, not HTML strings,
  // so they also work in the panel inside websites that enforce Trusted Types.
  const NS = 'http://www.w3.org/2000/svg';
  let n = 0;
  function el(tag, attrs, parent) {
    const e = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
    if (parent) parent.append(e);
    return e;
  }
  function bandiera(id) {
    if (id === 'it') {
      const svg = el('svg', { viewBox: '0 0 3 2', width: '21', height: '14', 'aria-hidden': 'true' });
      el('rect', { width: '1', height: '2', fill: '#009246' }, svg);
      el('rect', { x: '1', width: '1', height: '2', fill: '#ffffff' }, svg);
      el('rect', { x: '2', width: '1', height: '2', fill: '#ce2b37' }, svg);
      return svg;
    }
    const c = `cmx-uk-${++n}`;
    const svg = el('svg', { viewBox: '0 0 60 30', width: '28', height: '14', 'aria-hidden': 'true' });
    el('path', { d: 'M30,15h30v15zv15h-30zh-30v-15zv-15h30z' }, el('clipPath', { id: c }, svg));
    el('path', { d: 'M0,0v30h60v-30z', fill: '#012169' }, svg);
    el('path', { d: 'M0,0L60,30M60,0L0,30', stroke: '#ffffff', 'stroke-width': '6' }, svg);
    el('path', { d: 'M0,0L60,30M60,0L0,30', 'clip-path': `url(#${c})`, stroke: '#C8102E', 'stroke-width': '4' }, svg);
    el('path', { d: 'M30,0v30M0,15h60', stroke: '#ffffff', 'stroke-width': '10' }, svg);
    el('path', { d: 'M30,0v30M0,15h60', stroke: '#C8102E', 'stroke-width': '6' }, svg);
    return svg;
  }

  // Flag switch; scegli(id) saves the language. compatto: flags only, without names.
  function selettore(scegli, compatto) {
    const box = document.createElement('div');
    box.className = 'cmx-lingue';
    box.setAttribute('role', 'radiogroup');
    box.setAttribute('aria-label', 'Language · Lingua');
    for (const l of LINGUE) {
      const b = document.createElement('button');
      b.type = 'button';
      b.setAttribute('role', 'radio');
      b.dataset.lingua = l.id;
      b.title = l.nome;
      b.setAttribute('lang', l.id);
      b.append(bandiera(l.bandiera));
      if (compatto) b.setAttribute('aria-label', l.nome);
      else { const t = document.createElement('span'); t.textContent = l.nome; b.append(t); }
      b.addEventListener('click', () => scegli(l.id));
      box.append(b);
    }
    const aggiorna = () => { for (const b of box.children) b.setAttribute('aria-checked', String(b.dataset.lingua === attuale)); };
    aggiorna();
    ascoltatori.add(aggiorna);
    return box;
  }

  return {
    LINGUE, BASE, T, imposta, valida, traduciPagina, selettore, bandiera, mancanti,
    get attuale() { return attuale; },
    get locale() { return (LINGUE.find((x) => x.id === attuale) || LINGUE[0]).locale; },
    aggiungi(l, d) { DIZIONARI[l] = Object.assign(DIZIONARI[l] || {}, d); },
    dizionario(l) { return DIZIONARI[l] || {}; },
    onCambio(f) { ascoltatori.add(f); return () => ascoltatori.delete(f); }
  };
})();
