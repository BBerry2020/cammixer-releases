/*
 * CamMixer - motore condiviso
 * Usato dalla pagina delle impostazioni, dagli script nei siti e dal pannello.
 * Pipeline: webcam reale -> modifiche -> ritaglio e sfondo -> miscelazione -> webcam virtuale
 */
var WebcamVirtualiCore = WebcamVirtualiCore || (() => {
  'use strict';
  // Interface texts are in English; lingua.js translates them into the chosen language.
  // In websites lingua.js arrives a moment later (the service worker injects it with the components,
  // because Chrome injects a file only once per page and the panel needs it too): until then English.
  // setLingua() is used where the language comes with the settings (websites); elsewhere the pages
  // set it directly with CamMixerLingua.imposta().
  let linguaVoluta = null;
  const riempi = (s, v) => (v ? String(s).replace(/\{(\w+)\}/g, (m, k) => (v[k] !== undefined && v[k] !== null ? String(v[k]) : m)) : s);
  function lingua() {
    if (typeof CamMixerLingua === 'undefined') return null;
    if (linguaVoluta && CamMixerLingua.attuale !== linguaVoluta) CamMixerLingua.imposta(linguaVoluta);
    return CamMixerLingua;
  }
  const T = (s, v) => { const L = lingua(); return L ? L.T(s, v) : riempi(s, v); };
  const LOCALE = () => { const L = lingua(); return L ? L.locale : 'en-GB'; };
  function setLingua(l) { linguaVoluta = l === 'it' ? 'it' : 'en'; lingua(); }

  const NO_CAMERA = 'none';
  const MAX_WIDTH = 1280;
  const DEFAULT_ID = 'vcam-webcam1';
  // Webcam virtuali di sistema: mai usate come sorgente (si creerebbe un anello).
  // "CamMixer" (prima "Webcam virtuali") è la webcam di Windows creata dal programma ponte di questa estensione.
  const VIRTUAL_RE = /webcam1|cammixer|webcam virtuali|unity video capture|obs virtual camera/i;
  const isVirtualLabel = (label) => VIRTUAL_RE.test(label || '');

  // ---------------------------------------------------------------------
  // Parametri
  // ---------------------------------------------------------------------

  const ADJUST = [
    { id: 'brightness', label: 'Brightness',    min: 0,    max: 200, value: 100, unit: '%' },
    { id: 'contrast',   label: 'Contrast',     min: 0,    max: 200, value: 100, unit: '%' },
    { id: 'saturate',   label: 'Saturation',   min: 0,    max: 300, value: 100, unit: '%' },
    { id: 'hue',        label: 'Hue',      min: -180, max: 180, value: 0,   unit: '°' },
    { id: 'blur',       label: 'Blur',     min: 0,    max: 20,  value: 0,   unit: ' px' },
    { id: 'grayscale',  label: 'Black and white', min: 0,    max: 100, value: 0,   unit: '%' },
    { id: 'sepia',      label: 'Sepia',        min: 0,    max: 100, value: 0,   unit: '%' },
    { id: 'pixel',      label: 'Pixel',         min: 1,    max: 40,  value: 1,   unit: ' px', off: 1 },
    { id: 'zoom',       label: 'Zoom',          min: 100,  max: 300, value: 100, unit: '%' }
  ];
  const TOGGLES = [
    { id: 'invert', label: 'Negative' },
    { id: 'flipH',  label: 'Flip horizontally' },
    { id: 'flipV',  label: 'Flip vertically' }
  ];
  const MIXING = [
    { id: 'mix', label: 'Adjustment strength', min: 0, max: 100, value: 100, unit: '%' }
  ];
  const BG_BLUR = { id: 'bgBlur', label: 'Blur strength', min: 2, max: 40, value: 14, unit: ' px' };
  // Ritaglio della persona: quanto è severo nel togliere lo sfondo, morbidezza del bordo,
  // stabilità nel tempo. I valori iniziali riproducono il comportamento delle versioni precedenti.
  const SEGMENT = [
    { id: 'segSens', label: 'Cut-out sensitivity', min: 0, max: 100, value: 50, unit: '%',
      hint: 'Higher removes more background (no halo around you); if parts of you disappear, lower it.' },
    { id: 'segSoft', label: 'Soft edge', min: 0, max: 100, value: 50, unit: '%',
      hint: 'Higher softens the outline; lower makes it sharp.' },
    { id: 'segStab', label: 'Stability', min: 0, max: 90, value: 35, unit: '%',
      hint: 'Higher reduces outline flicker but follows movements with a slight delay.' }
  ];
  const SLIDERS = [...ADJUST, ...MIXING, BG_BLUR, ...SEGMENT];

  // Sfondi che dipendono dalla webcam e restano nel motore; gli altri sfondi,
  // gli effetti e le animazioni arrivano da componenti/componenti.js (aggiornabile al volo)
  const SPECIAL_BACKGROUNDS = [
    { id: 'none',  label: 'None' },
    { id: 'blur',  label: 'Blurred' },
    { id: 'color', label: 'Solid colour' },
    { id: 'media', label: 'Your image' }
  ];
  const COMPONENT_ID = /^[a-z][a-z0-9-]{0,39}$/;

  // Elementi sovrapposti: testi, emoji e immagini, ciascuno con posizione, dimensione e animazione
  const ELEMENT_TYPES = [
    { id: 'text',  label: 'Text' },
    { id: 'emoji', label: 'Emoji' },
    { id: 'image', label: 'Image' }
  ];
  const MAX_ELEMENTS = 12;
  const IMAGE_RE = /^data:image\/(jpeg|png|webp|gif);base64,[A-Za-z0-9+/=]+$/;

  const clampNum = (v, min, max, def) => {
    const n = Number(v);
    return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : def;
  };

  function newElement(type) {
    const el = { id: `el-${Math.random().toString(36).slice(2, 10)}`, type, x: 50, y: 20, size: 12, anim: 'none', color: '#ffffff', text: '', emoji: '', image: '' };
    if (type === 'text') { el.text = T('Hello!'); el.y = 15; el.size = 9; }
    if (type === 'emoji') { el.emoji = '⭐'; el.x = 85; el.y = 18; el.size = 14; el.anim = 'float'; }
    if (type === 'image') { el.x = 85; el.y = 80; el.size = 25; }
    return el;
  }

  function normalizeElement(e) {
    if (!e || typeof e !== 'object' || !ELEMENT_TYPES.some((t) => t.id === e.type)) return null;
    const el = {
      id: typeof e.id === 'string' && /^el-[a-z0-9]{1,16}$/.test(e.id) ? e.id : newElement(e.type).id,
      type: e.type,
      x: clampNum(e.x, 0, 100, 50),
      y: clampNum(e.y, 0, 100, 50),
      size: clampNum(e.size, 2, 100, 12),
      anim: typeof e.anim === 'string' && COMPONENT_ID.test(e.anim) ? e.anim : 'none',
      color: typeof e.color === 'string' && /^#[0-9a-f]{6}$/i.test(e.color) ? e.color : '#ffffff',
      text: typeof e.text === 'string' ? e.text.slice(0, 60) : '',
      emoji: typeof e.emoji === 'string' ? [...e.emoji].slice(0, 8).join('') : '',
      image: typeof e.image === 'string' && e.image.length < 3e6 && IMAGE_RE.test(e.image) ? e.image : ''
    };
    return el;
  }

  function defaultFx() {
    const fx = {};
    for (const s of SLIDERS) fx[s.id] = s.value;
    for (const t of TOGGLES) fx[t.id] = false;
    // effects: { idEffetto: intensità 0-100 } per gli effetti dei componenti
    Object.assign(fx, { text: '', clock: false, bg: 'none', bgColor: '#1d4ed8', bgImage: '', elements: [], effects: {}, news: defaultNews(),
      logo: { testo: '', immagine: '' } });   // logo: testo o immagine del «Logo 3D rotante»
    return fx;
  }

  // Valori iniziali di modifiche ed effetti: usati da "Ripristina effetti"
  function effectDefaults() {
    const out = {};
    for (const s of [...ADJUST, ...MIXING]) out[s.id] = s.value;
    for (const t of TOGGLES) out[t.id] = false;
    out.effects = {};
    return out;
  }

  // Sottopancia stile telegiornale: lo stile è un componente, i testi sono impostazioni
  const NEWS_FIELDS = [
    { id: 'label',    label: 'Label',            max: 24,  placeholder: 'E.g. BREAKING NEWS, LIVE' },
    { id: 'name',     label: 'Name',                 max: 40,  placeholder: 'E.g. First Last' },
    { id: 'role',     label: 'Role',                max: 60,  placeholder: 'E.g. Special correspondent' },
    { id: 'headline', label: 'Headline',              max: 90,  placeholder: 'The main headline' },
    { id: 'ticker',   label: 'Scrolling ticker',  max: 300, placeholder: 'News items separated by | (vertical bar)' }
  ];
  function defaultNews() {
    // x, y: spostamento in % del fotogramma; size: dimensione in % (la striscia che scorre resta in basso)
    return { style: '', label: T('BREAKING NEWS'), name: '', role: '', headline: '', ticker: '', clock: true, x: 0, y: 0, size: 100 };
  }
  const NEWS_POSITION = [
    { id: 'x',    label: 'Horizontal', min: -50, max: 50,  value: 0,   unit: '%' },
    { id: 'y',    label: 'Vertical',   min: -70, max: 20,  value: 0,   unit: '%' },
    { id: 'size', label: 'Size',  min: 40,  max: 160, value: 100, unit: '%' }
  ];
  function mergeNews(n) {
    const out = defaultNews();
    if (!n || typeof n !== 'object') return out;
    if (typeof n.style === 'string' && (n.style === '' || COMPONENT_ID.test(n.style))) out.style = n.style;
    for (const f of NEWS_FIELDS) if (typeof n[f.id] === 'string') out[f.id] = n[f.id].slice(0, f.max);
    if (typeof n.clock === 'boolean') out.clock = n.clock;
    for (const p of NEWS_POSITION) out[p.id] = clampNum(n[p.id], p.min, p.max, p.value);
    return out;
  }

  const OLD_EFFECT_KEYS = ['scan', 'glitch', 'grain', 'vignette'];   // salvati così fino alla 1.1

  function mergeEffects(saved) {
    const out = {};
    const src = saved && typeof saved.effects === 'object' && saved.effects ? { ...saved.effects } : {};
    for (const k of OLD_EFFECT_KEYS) if (saved && saved[k] !== undefined && src[k] === undefined) src[k] = saved[k];
    for (const [k, v] of Object.entries(src).slice(0, 40)) {
      if (!COMPONENT_ID.test(k)) continue;
      const n = clampNum(v, 0, 100, 0);
      if (n > 0) out[k] = n;
    }
    return out;
  }

  function mergeFx(saved) {
    const fx = defaultFx();
    if (saved && typeof saved === 'object') {
      for (const k of Object.keys(fx)) {
        if (k !== 'elements' && k !== 'effects' && k !== 'news' && k !== 'logo' && typeof saved[k] === typeof fx[k]) fx[k] = saved[k];
      }
      if (Array.isArray(saved.elements)) {
        fx.elements = saved.elements.map(normalizeElement).filter(Boolean).slice(0, MAX_ELEMENTS);
      }
    }
    fx.effects = mergeEffects(saved);
    fx.news = mergeNews(saved && saved.news);
    const lg = saved && saved.logo && typeof saved.logo === 'object' ? saved.logo : {};
    fx.logo = {
      testo: typeof lg.testo === 'string' ? lg.testo.slice(0, 24) : '',
      immagine: typeof lg.immagine === 'string' && lg.immagine.length < 3e6 && IMAGE_RE.test(lg.immagine) ? lg.immagine : ''
    };
    for (const s of SLIDERS) fx[s.id] = clampNum(fx[s.id], s.min, s.max, s.value);
    // lo sfondo può essere di un componente non ancora caricato: si tiene se l'id è valido
    if (typeof fx.bg !== 'string' || !COMPONENT_ID.test(fx.bg)) fx.bg = 'none';
    if (!/^#[0-9a-f]{6}$/i.test(fx.bgColor)) fx.bgColor = '#1d4ed8';
    if (fx.bgImage && !/^data:image\/(jpeg|png|webp);base64,/.test(fx.bgImage)) fx.bgImage = '';
    fx.text = String(fx.text).slice(0, 60);
    return fx;
  }

  const newId = () => `vcam-${Math.random().toString(36).slice(2, 10)}`;

  // Stato salvato: { vcams: [{ id, name, source, fx }], defaultId }
  // defaultId = webcam virtuale usata dai siti che non scelgono una fotocamera precisa (o null).
  function normalizeState(s) {
    const out = { vcams: [], defaultId: null, esempi3d: !!(s && s.esempi3d === true), lingua: s && s.lingua === 'it' ? 'it' : 'en' };
    const list = s && Array.isArray(s.vcams) ? s.vcams : [];
    const seen = new Set();
    for (const c of list) {
      if (!c || typeof c.id !== 'string' || seen.has(c.id)) continue;
      seen.add(c.id);
      out.vcams.push({
        id: c.id,
        name: (typeof c.name === 'string' && c.name.trim() ? c.name.trim() : T('Virtual webcam')).slice(0, 40),
        source: typeof c.source === 'string' ? c.source : '',
        fx: mergeFx(c.fx)
      });
    }
    if (!out.vcams.length) {
      out.vcams.push({ id: DEFAULT_ID, name: 'Webcam1', source: '', fx: defaultFx() });
      out.defaultId = DEFAULT_ID;   // al primo avvio Webcam1 è la fotocamera predefinita nei siti
    } else if (s && typeof s.defaultId === 'string' && seen.has(s.defaultId)) {
      out.defaultId = s.defaultId;
    }
    return out;
  }

  function filterString(fx, p) {
    const f = [];
    if (fx.brightness !== 100) f.push(`brightness(${fx.brightness}%)`);
    if (fx.contrast !== 100) f.push(`contrast(${fx.contrast}%)`);
    if (fx.saturate !== 100) f.push(`saturate(${fx.saturate}%)`);
    if (fx.hue) f.push(`hue-rotate(${fx.hue}deg)`);
    if (fx.grayscale) f.push(`grayscale(${fx.grayscale}%)`);
    if (fx.sepia) f.push(`sepia(${fx.sepia}%)`);
    if (fx.invert) f.push('invert(100%)');
    if (fx.blur) f.push(`blur(${(fx.blur / p).toFixed(2)}px)`);
    return f.length ? f.join(' ') : 'none';
  }

  function makeCanvas(w = 1280, h = 720) {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    return c;
  }

  function errorMessage(e) {
    switch (e && e.name) {
      case 'NotAllowedError': return T('Webcam access denied: allow it from the camera icon in the address bar.');
      case 'NotFoundError': return T('No webcam found. You can choose “No camera” as the source.');
      case 'NotReadableError': return T('The webcam is in use by another application.');
      case 'OverconstrainedError': return T('The chosen webcam is not available.');
      default: return T('Cannot start the webcam: {error}', { error: (e && (e.message || e.name)) || e });
    }
  }

  // ---------------------------------------------------------------------
  // Ritaglio della persona (MediaPipe). Chi usa il motore fornisce come
  // caricare la libreria e il modello (pagina impostazioni o sito).
  // ---------------------------------------------------------------------

  const seg = { state: 'idle', segmenter: null, lastTs: 0, error: '' };
  const segListeners = new Set();
  let segProvider = null;

  function setSegmentationProvider(fn) { segProvider = fn; }
  function onSegChange(fn) { segListeners.add(fn); }
  function segChanged() { segListeners.forEach((f) => { try { f(seg); } catch { /* ignora */ } }); }

  // MediaPipe all'avvio stampa messaggi tecnici (TensorFlow Lite, OpenGL, grafo) con
  // console.warn/error: Edge li mostra come "Errori" dell'estensione anche se tutto funziona.
  // Durante il caricamento e per i primi secondi di uso si scartano solo quei messaggi.
  const MEDIAPIPE_LOG = /^(?:[IWEF]\d{4}\s|INFO:|WARNING:|Created TensorFlow|Graph |.*\b(?:gl_context|OpenGL|XNNPACK|TfLite|calculator_graph)\b)/;
  let silenziatore = null;
  function silenziaMediaPipe(ms) {
    if (!silenziatore) {
      const orig = {};
      for (const k of ['log', 'info', 'warn', 'error', 'debug']) {
        orig[k] = console[k];
        console[k] = function (...a) {
          if (typeof a[0] === 'string' && MEDIAPIPE_LOG.test(a[0])) return;
          return orig[k].apply(this, a);
        };
      }
      silenziatore = { orig, timer: null };
    }
    clearTimeout(silenziatore.timer);
    silenziatore.timer = setTimeout(() => {
      Object.assign(console, silenziatore.orig);
      silenziatore = null;
    }, ms);
  }

  async function loadSegmenter() {
    if (seg.state !== 'idle' || !segProvider) return;
    seg.state = 'loading';
    segChanged();
    silenziaMediaPipe(60000);
    try {
      // fileset/prepara: nei siti il caricatore di MediaPipe arriva dall'estensione (vedi inject.js)
      const { vision, wasmPath, model, fileset: dato, prepara } = await segProvider();
      const fileset = dato || await vision.FilesetResolver.forVisionTasks(wasmPath);
      const crea = async (delegate) => {
        if (prepara) await prepara();
        return vision.ImageSegmenter.createFromOptions(fileset, {
          baseOptions: { modelAssetBuffer: model.slice(), delegate },
          runningMode: 'VIDEO', outputConfidenceMasks: true, outputCategoryMask: false
        });
      };
      try {
        seg.segmenter = await crea('GPU');
      } catch {
        seg.segmenter = await crea('CPU');
      }
      seg.state = 'ready';
      silenziaMediaPipe(15000);   // anche i primi fotogrammi avviano parti del grafo
    } catch (e) {
      seg.state = 'error';
      const msg = e && e.message ? e.message : (e && e.type ? T('the library could not be loaded') : String(e));
      seg.error = msg.split(/[;\n]|={3}/)[0].trim().slice(0, 140);
    }
    segChanged();
  }

  function retrySegmenter() {
    if (seg.state === 'error') { seg.state = 'idle'; seg.error = ''; }
    loadSegmenter();
  }

  // ---------------------------------------------------------------------
  // Tracciamento del volto (MediaPipe FaceLandmarker), solo per gli esempi 3D
  // che lo chiedono (effetti con volto: true). Stessa libreria del ritaglio,
  // modello «volto» procurato da chi usa il motore.
  // ---------------------------------------------------------------------

  const face = { state: 'idle', landmarker: null, error: '', trovati: 0 };   // trovati: fotogrammi con un volto (per le prove)

  async function loadFace() {
    if (face.state !== 'idle' || !segProvider) return;
    face.state = 'loading';
    silenziaMediaPipe(60000);
    try {
      const { vision, wasmPath, model, fileset: dato, prepara } = await segProvider('volto');
      const fileset = dato || await vision.FilesetResolver.forVisionTasks(wasmPath);
      const crea = async (delegate) => {
        if (prepara) await prepara();
        return vision.FaceLandmarker.createFromOptions(fileset, {
          baseOptions: { modelAssetBuffer: model.slice(), delegate },
          runningMode: 'VIDEO', numFaces: 1,
          outputFaceBlendshapes: true, outputFacialTransformationMatrixes: true
        });
      };
      try {
        face.landmarker = await crea('GPU');
      } catch {
        face.landmarker = await crea('CPU');
      }
      face.state = 'ready';
      silenziaMediaPipe(15000);
    } catch (e) {
      face.state = 'error';
      const msg = e && e.message ? e.message : String(e);
      face.error = msg.split(/[;\n]|={3}/)[0].trim().slice(0, 140);
    }
  }

  // Esempi 3D (Three.js): si caricano solo se attivati nelle impostazioni
  let esempi3d = false;
  let baseRisorse = '';
  function setEsempi3D(v) {
    const n = v === true;
    if (n === esempi3d) return;
    esempi3d = n;
    notifyRegistry();
  }
  function setBase(url) { if (typeof url === 'string' && /^(chrome-)?extension:\/\//.test(url)) baseRisorse = url; }
  const risorsa = (p) => (baseRisorse ? baseRisorse + p : '');
  const visibile = (c) => !c.tre_d || esempi3d;

  function nextTimestamp() {
    seg.lastTs = Math.max(seg.lastTs + 1, performance.now());
    return seg.lastTs;
  }

  function segStatusText(vcam) {
    if (!vcam) return '';
    if (vcam.fx.bg === 'none') return T('Choose a background: the person is cut out and placed in front of it.');
    if (vcam.source === NO_CAMERA) return T('Without a camera the background fills the whole video.');
    if (seg.state === 'ready') return T('Person cut-out active.');
    if (seg.state === 'error') return T('Cut-out not available ({error}).', { error: seg.error });
    return T('Loading the cut-out model…');
  }

  // ---------------------------------------------------------------------
  // Registro dei componenti (sfondi, effetti, animazioni)
  // componenti/componenti.js chiama register() al caricamento e a ogni
  // aggiornamento: il nuovo pacchetto sostituisce il precedente per intero.
  // ---------------------------------------------------------------------

  const registry = {
    backgrounds: new Map(), effects: new Map(), animations: new Map(), lowerThirds: new Map(),
    version: '', loaded: false, generation: 0, loadedAt: 0,
    broken: new Map()   // 'tipo:id' -> messaggio d'errore
  };
  const registryListeners = new Set();
  let resolveComponents;
  const componentsReady = new Promise((r) => { resolveComponents = r; });

  function notifyRegistry() {
    registryListeners.forEach((f) => { try { f(catalog()); } catch { /* ignora */ } });
  }

  function register(pack) {
    if (!pack || typeof pack !== 'object') throw new Error('invalid component package');
    const special = new Set(SPECIAL_BACKGROUNDS.map((b) => b.id));
    const take = (list, fnOk, skip) => {
      const map = new Map();
      if (!Array.isArray(list)) return map;
      for (const item of list) {
        if (!item || typeof item.id !== 'string' || !COMPONENT_ID.test(item.id) || skip.has(item.id)) continue;
        if (typeof item.label !== 'string' || !fnOk(item)) continue;
        map.set(item.id, Object.freeze({ ...item, label: item.label.slice(0, 60) }));
      }
      return map;
    };
    const has = (name) => (item) => typeof item[name] === 'function';
    registry.backgrounds = take(pack.sfondi, has('draw'), special);
    registry.effects = take(pack.effetti, has('apply'), new Set());
    registry.animations = take(pack.animazioni, has('apply'), new Set(['none']));
    registry.lowerThirds = take(pack.sottopancia, (i) => has('draw')(i) || has('blocco')(i), new Set());
    registry.version = String(pack.versione || '').slice(0, 40);
    registry.loaded = true;
    registry.loadedAt = Date.now();
    registry.generation++;
    registry.broken = new Map();
    resolveComponents();
    notifyRegistry();
  }

  // Un componente che genera un errore viene disattivato fino al prossimo aggiornamento
  function markBroken(kind, id, e) {
    const key = `${kind}:${id}`;
    if (registry.broken.has(key)) return;
    registry.broken.set(key, String((e && e.message) || e).slice(0, 160));
    notifyRegistry();
  }

  function catalog() {
    const list = (map) => [...map.values()].filter(visibile).map((c) => ({
      id: c.id, label: c.label, soloTesto: !!c.soloTesto, tre_d: !!c.tre_d, volto: !!c.volto,
      breve: typeof c.breve === 'string' ? c.breve.slice(0, 20) : ''
    }));
    return {
      version: registry.version,
      loaded: registry.loaded,
      loadedAt: registry.loadedAt,
      backgrounds: [...SPECIAL_BACKGROUNDS.slice(0, 3), ...list(registry.backgrounds), SPECIAL_BACKGROUNDS[3]],
      effects: list(registry.effects),
      animations: [{ id: 'none', label: 'No animation', soloTesto: false }, ...list(registry.animations)],
      lowerThirds: list(registry.lowerThirds),
      esempi3d,
      errors: [...registry.broken.entries()].map(([k, msg]) => ({ id: k, message: msg }))
    };
  }

  function onRegistryChange(fn) { registryListeners.add(fn); }

  function whenComponents(ms) {
    return Promise.race([componentsReady, new Promise((r) => setTimeout(r, ms))]);
  }

  // ---------------------------------------------------------------------
  // Elementi sovrapposti
  // ---------------------------------------------------------------------

  function phaseOf(id) {
    let h = 0;
    for (let i = 0; i < id.length; i++) h = (h * 31 + id.charCodeAt(i)) | 0;
    return (Math.abs(h) % 1000) / 1000 * 6.28;
  }

  function drawElements(o, elements, images, W, H, now, hits) {
    for (const el of elements) {
      const t = now + phaseOf(el.id);
      const size = (el.size / 100) * H;
      let x = (el.x / 100) * W, y = (el.y / 100) * H, scale = 1, rot = 0, color = null;
      let draw = null, width = 0;
      if (el.type === 'text' && el.text) {
        o.font = `800 ${size}px system-ui, -apple-system, "Segoe UI", sans-serif`;
        width = o.measureText(el.text).width;
        draw = () => {
          o.font = `800 ${size}px system-ui, -apple-system, "Segoe UI", sans-serif`;
          o.lineJoin = 'round';
          o.lineWidth = Math.max(2, size * 0.14);
          o.strokeStyle = 'rgba(0, 0, 0, 0.75)';
          o.strokeText(el.text, 0, 0);
          o.fillStyle = color || el.color;
          o.fillText(el.text, 0, 0);
        };
      } else if (el.type === 'emoji' && el.emoji) {
        const font = `${size}px "Segoe UI Emoji", "Apple Color Emoji", "Noto Color Emoji", sans-serif`;
        o.font = font;
        width = o.measureText(el.emoji).width;
        draw = () => { o.font = font; o.fillText(el.emoji, 0, 0); };
      } else if (el.type === 'image') {
        const bmp = images.get(el.id);
        if (!bmp) continue;
        const h = size, w = h * (bmp.width / bmp.height);
        width = w;
        draw = () => o.drawImage(bmp, -w / 2, -h / 2, w, h);
      }
      if (!draw) continue;
      const anim = el.anim !== 'none' && registry.animations.get(el.anim);
      if (anim && !registry.broken.has(`animazione:${anim.id}`)) {
        try {
          const r = anim.apply({ t, now, W, H, size, width }) || {};
          if (r.hidden) continue;
          if (Number.isFinite(r.x)) x = r.x;
          if (Number.isFinite(r.dx)) x += r.dx;
          if (Number.isFinite(r.dy)) y += r.dy;
          if (Number.isFinite(r.scale)) scale = r.scale;
          if (Number.isFinite(r.rot)) rot = r.rot;
          if (typeof r.color === 'string' && el.type === 'text') color = r.color;
        } catch (e) {
          markBroken('animazione', anim.id, e);
        }
      }
      o.save();
      o.translate(x, y);
      if (rot) o.rotate(rot);
      if (scale !== 1) o.scale(scale, scale);
      o.textAlign = 'center';
      o.textBaseline = 'middle';
      draw();
      o.restore();
      if (hits) {
        const w = Math.max(width, size * 0.6) * scale, h = size * scale * 1.1;
        hits.push({ kind: 'element', id: el.id, x: x - w / 2, y: y - h / 2, w, h });
      }
    }
  }

  function drawCover(o, media, W, H) {
    const mw = media.videoWidth || media.naturalWidth || media.width || 0;
    const mh = media.videoHeight || media.naturalHeight || media.height || 0;
    if (!mw || !mh) return false;
    const s = Math.max(W / mw, H / mh), dw = mw * s, dh = mh * s;
    o.drawImage(media, (W - dw) / 2, (H - dh) / 2, dw, dh);
    return true;
  }

  function drawMessage(o, W, H, text, bg = '#111') {
    o.setTransform(1, 0, 0, 1, 0, 0);
    o.filter = 'none';
    o.globalAlpha = 1;
    o.globalCompositeOperation = 'source-over';
    o.fillStyle = bg;
    o.fillRect(0, 0, W, H);
    o.fillStyle = '#9aa4b0';
    o.font = `600 ${Math.round(H * 0.045)}px system-ui, sans-serif`;
    o.textAlign = 'center';
    o.textBaseline = 'middle';
    o.fillText(text, W / 2, H / 2);
    o.textAlign = 'left';
  }

  function drawOverlays(o, fx, W, H) {
    const fs = Math.round(H * 0.045), pad = Math.round(fs * 0.5), bh = Math.round(fs * 1.7);
    o.font = `600 ${fs}px system-ui, -apple-system, "Segoe UI", sans-serif`;
    o.textBaseline = 'middle';
    o.textAlign = 'left';
    const box = (x, y, text, alignRight) => {
      const bw = o.measureText(text).width + pad * 2;
      const bx = alignRight ? x - bw : x;
      o.fillStyle = 'rgba(0, 0, 0, 0.55)';
      o.fillRect(bx, y, bw, bh);
      o.fillStyle = '#fff';
      o.fillText(text, bx + pad, y + bh / 2);
    };
    if (fx.text) box(pad * 2, H - pad * 2 - bh, fx.text, false);
    if (fx.clock) box(W - pad * 2, pad * 2, new Date().toLocaleString(LOCALE()), true);
  }

  // ---------------------------------------------------------------------
  // Ritmo dei fotogrammi senza telecamera: timer in un worker, che il
  // browser non rallenta quando la scheda è in secondo piano.
  // ---------------------------------------------------------------------

  const ticker = { worker: null, timer: null, subs: new Set() };
  function subscribeTick(fn) {
    if (!ticker.worker && !ticker.timer) {
      try {
        const code = 'setInterval(() => postMessage(0), 1000 / 30);';
        const url = URL.createObjectURL(new Blob([code], { type: 'text/javascript' }));
        // siti con Trusted Types (es. Teams sul web): l'indirizzo del worker passa da una policy
        let tt = null;
        try { tt = window.trustedTypes ? window.trustedTypes.createPolicy('cammixer-ticker', { createScriptURL: (u) => u }) : null; } catch { tt = null; }
        ticker.worker = new Worker(tt ? tt.createScriptURL(url) : url);
        ticker.worker.onmessage = () => ticker.subs.forEach((f) => f());
      } catch {
        ticker.timer = setInterval(() => ticker.subs.forEach((f) => f()), 1000 / 30);
      }
    }
    ticker.subs.add(fn);
    return () => ticker.subs.delete(fn);
  }

  // Limitatore: se disegnare un fotogramma costa troppo, i successivi vengono saltati
  // in modo da lasciare libera almeno metà del tempo alla pagina (niente blocchi).
  function makePacer(minGap = 28) {
    let last = -Infinity, cost = 0;
    return (draw) => {
      const now = performance.now();
      if (now - last < Math.max(minGap, cost * 2)) return false;
      last = now;
      draw();
      cost = performance.now() - now;
      return true;
    };
  }

  // Immagine di sfondo salvata come data URL: decodificata senza passare dalla
  // rete, così le regole di sicurezza del sito (CSP) non la bloccano.
  async function decodeDataUrl(url) {
    const m = /^data:([^;]+);base64,(.*)$/.exec(url);
    if (!m) return null;
    const bin = atob(m[2]);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return createImageBitmap(new Blob([bytes], { type: m[1] }));
  }

  // ---------------------------------------------------------------------
  // Webcam virtuale
  // env: { getUserMedia, enumerateDevices } non modificati, onChange(vcam)
  // source: '' = webcam predefinita, 'none' = nessuna telecamera,
  //         altrimenti il nome del dispositivo (gli id cambiano da sito a sito)
  // ---------------------------------------------------------------------

  class VCam {
    constructor(cfg, env) {
      this.env = env;
      this.id = cfg.id;
      this.name = cfg.name;
      this.source = cfg.source || '';
      this.fx = mergeFx(cfg.fx);
      this.media = null;
      this.mediaSrc = '';
      this.out = makeCanvas();       this.octx = this.out.getContext('2d');
      this.geo = makeCanvas();       this.gctx = this.geo.getContext('2d');
      this.work = makeCanvas();      this.wctx = this.work.getContext('2d');
      this.small = makeCanvas(1, 1); this.sctx = this.small.getContext('2d');
      this.person = makeCanvas();    this.pctx = this.person.getContext('2d');
      this.mask = makeCanvas(1, 1);  this.mctx = this.mask.getContext('2d');
      this.maskImg = null;
      this.prevMask = null;
      this.bgStates = new Map();   // stato privato di ogni sfondo dei componenti
      this.fxStates = new Map();   // stato privato di ogni effetto dei componenti
      this.ltStates = new Map();   // stato privato di ogni stile di sottopancia
      this.hit = { elements: [], news: null, W: 0, H: 0 };
      this.regGen = registry.generation;
      this.elImages = new Map();   // id elemento -> immagine decodificata
      this.elSrc = new Map();      // id elemento -> data URL decodificato
      this.stream = null;
      this.loopTrack = null;
      this.untick = null;
      this.vid = null;
      this.gen = 0;
      this.starting = null;
      this.status = 'idle';
      this.error = '';
      this.outStream = this.out.captureStream(30);
      this.loadMedia();
      this.drawIdle();
    }

    get running() { return !!(this.stream || this.untick); }

    setStatus(status, error = '') {
      this.status = status;
      this.error = error;
      if (this.env.onChange) this.env.onChange(this);
    }

    update(cfg) {
      const sourceChanged = (cfg.source || '') !== this.source;
      this.name = cfg.name;
      this.source = cfg.source || '';
      this.fx = mergeFx(cfg.fx);
      this.loadMedia();
      if (sourceChanged && (this.running || this.starting)) this.start().catch(() => {});
    }

    loadMedia() {
      const src = this.fx.bgImage || '';
      if (src === this.mediaSrc) return;
      this.mediaSrc = src;
      this.media = null;
      if (src) decodeDataUrl(src).then((bmp) => { if (this.mediaSrc === src) this.media = bmp; }).catch(() => {});
    }

    // Decodifica (una volta) le immagini degli elementi e scarta quelle eliminate
    syncElementImages() {
      const live = new Set();
      for (const el of this.fx.elements) {
        if (el.type !== 'image' || !el.image) continue;
        live.add(el.id);
        if (this.elSrc.get(el.id) === el.image) continue;
        const src = el.image;
        this.elSrc.set(el.id, src);
        this.elImages.delete(el.id);
        decodeDataUrl(src).then((bmp) => { if (bmp && this.elSrc.get(el.id) === src) this.elImages.set(el.id, bmp); }).catch(() => {});
      }
      for (const id of [...this.elSrc.keys()]) if (!live.has(id)) { this.elSrc.delete(id); this.elImages.delete(id); }
    }

    workCanvas(name, W, H) {
      let c = this[name];
      if (!c || c.width !== W || c.height !== H) c = this[name] = makeCanvas(W, H);
      return c;
    }

    // Effetti dei componenti, nell'ordine del pacchetto (sotto testi ed elementi)
    applyEffects(W, H, hasSource) {
      const fx = this.fx, o = this.octx;
      const attivi = [...registry.effects].filter(([id, comp]) => (fx.effects[id] || 0) > 0 && visibile(comp) && !registry.broken.has(`effetto:${id}`));
      // il volto si cerca solo se un effetto attivo lo usa
      const datiVolto = hasSource && attivi.some(([, comp]) => comp.volto) ? this.updateFace(W, H) : null;
      const info = { nome: this.name, testo: fx.text, logo: fx.logo };
      for (const [id, comp] of attivi) {
        const v = fx.effects[id] || 0;
        let stato = this.fxStates.get(id);
        if (!stato) { stato = {}; this.fxStates.set(id, stato); }
        o.save();
        try {
          comp.apply({ o, W, H, k: v / 100, out: this.out, stato, canvas: (name) => this.workCanvas(`fx:${id}:${name}`, W, H),
            volto: datiVolto, voltoStato: { state: face.state, error: face.error }, info, t: performance.now() / 1000 });
        } catch (e) {
          markBroken('effetto', id, e);
        } finally {
          o.restore();
        }
      }
    }

    // Sottopancia: lo stile (componente) riceve i testi già pronti
    drawLowerThird(W, H) {
      const n = this.fx.news;
      if (!n.style) return;
      const comp = registry.lowerThirds.get(n.style);
      if (!comp || registry.broken.has(`sottopancia:${n.style}`)) return;
      let stato = this.ltStates.get(n.style);
      if (!stato) { stato = {}; this.ltStates.set(n.style, stato); }
      const testi = {
        etichetta: n.label.trim(),
        nome: n.name.trim(),
        ruolo: n.role.trim(),
        notizia: n.headline.trim(),
        scorrimento: n.ticker.split('|').map((x) => x.trim()).filter(Boolean),
        ora: n.clock ? new Date().toLocaleTimeString(LOCALE(), { hour: '2-digit', minute: '2-digit' }) : ''
      };
      const o = this.octx, t = performance.now() / 1000;
      const s = n.size / 100, px = W * 0.05, py = H * 0.8;           // perno: in basso a sinistra
      const dx = (n.x / 100) * W, dy = (n.y / 100) * H;
      const place = () => { o.translate(px + dx, py + dy); o.scale(s, s); o.translate(-px, -py); };
      const toHit = (r) => ({ kind: 'news', x: px + dx + (r.x - px) * s, y: py + dy + (r.y - py) * s, w: r.w * s, h: r.h * s });
      try {
        if (typeof comp.blocco === 'function') {
          o.save();
          place();
          const r = comp.blocco(o, W, H, t, testi, stato);
          o.restore();
          if (r && [r.x, r.y, r.w, r.h].every(Number.isFinite)) this.hit.news = toHit(r);
          if (typeof comp.striscia === 'function') { o.save(); comp.striscia(o, W, H, t, testi, stato); o.restore(); }
        } else {
          o.save();
          place();
          comp.draw(o, W, H, t, testi, stato);
          o.restore();
          this.hit.news = toHit({ x: 0, y: H * 0.6, w: W, h: H * 0.4 });
        }
      } catch (e) {
        o.restore();
        markBroken('sottopancia', n.style, e);
      }
    }

    drawIdle() {
      drawMessage(this.octx, this.out.width, this.out.height, T('{name} — no signal', { name: this.name }));
    }

    ensure() {
      if (this.running) return Promise.resolve();
      if (!this.starting) this.starting = this.start().finally(() => { this.starting = null; });
      return this.starting;
    }

    async openSource(gen) {
      const env = this.env, want = this.source;
      const findReal = async () => (await env.enumerateDevices()).find((d) =>
        d.kind === 'videoinput' && d.deviceId && (want ? d.label === want : !isVirtualLabel(d.label)));
      const open = async (deviceId) => {
        const video = { width: { ideal: 1280 }, height: { ideal: 720 } };
        if (deviceId) video.deviceId = { exact: deviceId };
        try {
          return await env.getUserMedia({ video, audio: false });
        } catch (e) {
          if (deviceId && (e.name === 'OverconstrainedError' || e.name === 'NotFoundError')) return open('');
          throw e;
        }
      };
      const stopAll = (s) => s.getTracks().forEach((t) => t.stop());

      // I nomi dei dispositivi sono visibili solo dopo il permesso: se la prima
      // apertura non prende la webcam giusta, si riprova con l'elenco completo.
      const first = want ? await findReal() : null;
      let s = await open(first && first.deviceId);
      if (gen !== this.gen) { stopAll(s); return null; }
      const label = s.getVideoTracks()[0].label;
      if (want ? label !== want : isVirtualLabel(label)) {
        const alt = await findReal();
        if (alt) {
          stopAll(s);
          s = await open(alt.deviceId);
          if (gen !== this.gen) { stopAll(s); return null; }
        } else if (!want) {
          stopAll(s);
          throw Object.assign(new Error(T('No real webcam found.')), { name: 'NotFoundError' });
        }
      }
      return s;
    }

    async start() {
      this.stop(false);
      const gen = this.gen;
      if (this.source === NO_CAMERA) {
        const pace = makePacer();
        this.untick = subscribeTick(() => { if (gen === this.gen) pace(() => this.render(null, 1280, 720)); });
        this.setStatus('live');
        return;
      }
      this.setStatus('starting');
      let s;
      try {
        s = await this.openSource(gen);
      } catch (e) {
        if (gen !== this.gen) return;
        this.drawIdle();
        this.setStatus('error', errorMessage(e));
        throw e;
      }
      if (!s) return;
      this.stream = s;
      const track = s.getVideoTracks()[0];
      track.addEventListener('ended', () => {
        if (this.stream === s) { this.stop(true); this.setStatus('error', T('The real webcam was disconnected.')); }
      });
      this.startLoop(track, gen);
      this.setStatus('live');
    }

    // Con MediaStreamTrackProcessor (Chrome/Edge) i fotogrammi arrivano anche
    // con la scheda in secondo piano.
    startLoop(track, gen) {
      if (typeof MediaStreamTrackProcessor !== 'undefined') {
        const t = track.clone();
        this.loopTrack = t;
        const reader = new MediaStreamTrackProcessor({ track: t }).readable.getReader();
        const pace = makePacer(0);   // la webcam detta il ritmo; si salta solo se il disegno è lento
        (async () => {
          try {
            while (gen === this.gen) {
              const { value: frame, done } = await reader.read();
              if (done) break;
              try {
                if (gen === this.gen) pace(() => this.render(frame, frame.displayWidth, frame.displayHeight));
              } finally {
                frame.close();
              }
            }
          } catch { /* traccia chiusa */ } finally {
            reader.cancel().catch(() => {});
            t.stop();
          }
        })();
      } else {
        const v = this.vid = document.createElement('video');
        v.muted = true;
        v.playsInline = true;
        v.srcObject = this.stream;
        v.play().catch(() => {});
        const step = () => {
          if (gen !== this.gen) return;
          this.render(v, v.videoWidth, v.videoHeight);
          requestAnimationFrame(step);
        };
        step();
      }
    }

    stop(showIdle = true) {
      this.gen++;
      if (this.loopTrack) this.loopTrack.stop();
      if (this.stream) this.stream.getTracks().forEach((t) => t.stop());
      if (this.untick) this.untick();
      if (this.vid) this.vid.srcObject = null;
      this.loopTrack = this.stream = this.untick = this.vid = null;
      if (showIdle) { this.drawIdle(); this.setStatus('idle'); }
    }

    // Punti del volto, posa della testa ed espressioni sul fotogramma corrente (this.geo)
    updateFace(W, H) {
      if (face.state !== 'ready') { if (face.state === 'idle') loadFace(); return null; }
      try {
        const r = face.landmarker.detectForVideo(this.geo, nextTimestamp());
        if (!r || !r.faceLandmarks || !r.faceLandmarks.length) return null;
        face.trovati++;
        const esp = {};
        const cat = r.faceBlendshapes && r.faceBlendshapes[0] ? r.faceBlendshapes[0].categories : [];
        for (const c of cat) esp[c.categoryName] = c.score;
        const m = r.facialTransformationMatrixes && r.facialTransformationMatrixes[0];
        return { punti: r.faceLandmarks[0], matrice: m ? Float32Array.from(m.data) : null, espressioni: esp, W, H };
      } catch (e) {
        face.state = 'error';
        face.error = e && e.message ? e.message : String(e);
        return null;
      }
    }

    updateMask() {
      if (seg.state !== 'ready') { if (seg.state === 'idle') loadSegmenter(); return false; }
      let ok = false;
      try {
        seg.segmenter.segmentForVideo(this.geo, nextTimestamp(), (res) => {
          const masks = res.confidenceMasks;
          if (!masks || !masks.length) return;
          const m = masks[masks.length - 1];             // ultima categoria = persona
          const data = m.getAsFloat32Array();
          const mw = m.width, mh = m.height;
          if (this.mask.width !== mw || this.mask.height !== mh || !this.maskImg) {
            this.mask.width = mw;
            this.mask.height = mh;
            this.maskImg = this.mctx.createImageData(mw, mh);
            this.prevMask = new Float32Array(mw * mh);
          }
          const px = this.maskImg.data, prev = this.prevMask, fx = this.fx;
          // soglia: con sensibilità alta serve più certezza per tenere un punto come "persona"
          const width = 0.04 + 0.52 * (fx.segSoft / 100);                 // 50% -> 0,30
          const lo = 0.2 + 0.6 * (fx.segSens / 100) - width / 2;          // 50% -> 0,35
          const keep = fx.segStab / 100, take = 1 - keep;                 // 35% -> come prima
          const scale = 255 / width;
          for (let i = 0; i < data.length; i++) {
            const v = prev[i] = prev[i] * keep + data[i] * take;            // meno sfarfallio
            px[i * 4 + 3] = Math.min(255, Math.max(0, (v - lo) * scale));  // bordo morbido
          }
          this.mctx.putImageData(this.maskImg, 0, 0);
          ok = true;
        });
      } catch (e) {
        seg.state = 'error';
        seg.error = e && e.message ? e.message : String(e);
        segChanged();
      }
      return ok;
    }

    drawBackground(W, H, hasSource) {
      const o = this.octx, fx = this.fx, t = performance.now() / 1000;
      switch (fx.bg) {
        case 'blur':
          o.fillStyle = '#000';
          o.fillRect(0, 0, W, H);
          if (hasSource) {
            const pad = fx.bgBlur * 2;
            o.filter = `blur(${fx.bgBlur}px)`;
            o.drawImage(this.geo, -pad, -pad, W + 2 * pad, H + 2 * pad);
            o.filter = 'none';
          }
          break;
        case 'color': o.fillStyle = fx.bgColor; o.fillRect(0, 0, W, H); break;
        case 'media':
          // Le immagini tue sono solo uno sfondo dietro di te: senza telecamera non vengono mostrate.
          o.fillStyle = '#000';
          o.fillRect(0, 0, W, H);
          if (!hasSource) drawMessage(o, W, H, T('Your image is used as a background behind you'), '#000');
          else if (!this.media || !drawCover(o, this.media, W, H)) drawMessage(o, W, H, T('Upload an image in the settings'), '#000');
          break;
        default: {
          // Sfondo dei componenti; se manca o è in errore, nero
          o.fillStyle = '#000';
          o.fillRect(0, 0, W, H);
          const comp = registry.backgrounds.get(fx.bg);
          if (!comp || !visibile(comp) || registry.broken.has(`sfondo:${fx.bg}`)) break;
          let stato = this.bgStates.get(fx.bg);
          if (!stato) { stato = {}; this.bgStates.set(fx.bg, stato); }
          o.save();
          try {
            comp.draw(o, W, H, t, stato);
          } catch (e) {
            markBroken('sfondo', fx.bg, e);
          } finally {
            o.restore();
          }
        }
      }
    }

    // src: VideoFrame, <video> oppure null (nessuna telecamera)
    render(src, vw, vh) {
      if (!vw || !vh) return;
      const fx = this.fx;
      if (this.regGen !== registry.generation) {   // componenti aggiornati: stati da rifare
        this.regGen = registry.generation;
        this.bgStates.clear();
        this.fxStates.clear();
        this.ltStates.clear();
      }
      const scale = Math.min(1, MAX_WIDTH / vw);
      const W = Math.round(vw * scale), H = Math.round(vh * scale);
      for (const c of [this.out, this.geo, this.work, this.person]) {
        if (c.width !== W || c.height !== H) { c.width = W; c.height = H; }
      }
      const bgOn = fx.bg !== 'none';
      let masked = false;

      if (src) {
        // 1. Geometria: zoom e ribaltamenti
        const g = this.gctx, z = fx.zoom / 100;
        g.setTransform(1, 0, 0, 1, 0, 0);
        g.clearRect(0, 0, W, H);
        g.translate(W / 2, H / 2);
        g.scale((fx.flipH ? -1 : 1) * z, (fx.flipV ? -1 : 1) * z);
        g.translate(-W / 2, -H / 2);
        g.drawImage(src, 0, 0, W, H);
        g.setTransform(1, 0, 0, 1, 0, 0);

        // 2. Modifiche al video reale
        const p = Math.max(1, fx.pixel), filter = filterString(fx, p), w = this.wctx;
        w.setTransform(1, 0, 0, 1, 0, 0);
        w.globalAlpha = 1;
        w.filter = 'none';
        w.clearRect(0, 0, W, H);
        if (p > 1) {
          const sw = Math.max(1, Math.ceil(W / p)), sh = Math.max(1, Math.ceil(H / p));
          if (this.small.width !== sw || this.small.height !== sh) { this.small.width = sw; this.small.height = sh; }
          const s = this.sctx;
          s.clearRect(0, 0, sw, sh);
          s.filter = filter;
          s.drawImage(this.geo, 0, 0, sw, sh);
          s.filter = 'none';
          w.imageSmoothingEnabled = false;
          w.drawImage(this.small, 0, 0, W, H);
          w.imageSmoothingEnabled = true;
        } else {
          w.filter = filter;
          w.drawImage(this.geo, 0, 0);
          w.filter = 'none';
        }

        // 3. Persona: originale e modificata secondo l'intensità
        const pc = this.pctx, k = fx.mix / 100;
        pc.globalCompositeOperation = 'source-over';
        pc.globalAlpha = 1;
        pc.clearRect(0, 0, W, H);
        if (k < 1) pc.drawImage(this.geo, 0, 0);
        if (k > 0) { pc.globalAlpha = k; pc.drawImage(this.work, 0, 0); pc.globalAlpha = 1; }

        // 4. Ritaglio, solo se c'è uno sfondo da mostrare
        if (bgOn && this.updateMask()) {
          pc.globalCompositeOperation = 'destination-in';
          pc.imageSmoothingEnabled = true;
          pc.drawImage(this.mask, 0, 0, W, H);
          pc.globalCompositeOperation = 'source-over';
          masked = true;
        }
      }

      // 5. Miscelazione: sfondo + persona + sovrimpressioni
      const o = this.octx;
      o.setTransform(1, 0, 0, 1, 0, 0);
      o.filter = 'none';
      o.globalAlpha = 1;
      o.globalCompositeOperation = 'source-over';
      if (bgOn && (masked || !src)) this.drawBackground(W, H, !!src);
      else { o.fillStyle = '#000'; o.fillRect(0, 0, W, H); }
      if (src) o.drawImage(this.person, 0, 0);
      this.applyEffects(W, H, !!src);
      drawOverlays(o, fx, W, H);
      this.hit = { elements: [], news: null, W, H };   // riquadri per trascinare con il mouse
      this.drawLowerThird(W, H);
      if (fx.elements.length) {
        this.syncElementImages();
        drawElements(o, fx.elements, this.elImages, W, H, performance.now() / 1000, this.hit.elements);
      }
      if (this.env.onFrame) this.env.onFrame(this);   // fotogramma pronto (es. per la webcam di Windows)
    }
  }

  return {
    NO_CAMERA, DEFAULT_ID, ADJUST, TOGGLES, MIXING, BG_BLUR, SEGMENT, SLIDERS, NEWS_FIELDS, NEWS_POSITION, defaultNews,
    ELEMENT_TYPES, MAX_ELEMENTS, newElement, effectDefaults,
    register, catalog, onRegistryChange, whenComponents, util: { makeCanvas, risorsa, decodeDataUrl, T }, T, setLingua,
    setEsempi3D, setBase, face,
    defaultFx, mergeFx, normalizeState, newId, isVirtualLabel, errorMessage,
    seg, setSegmentationProvider, onSegChange, loadSegmenter, retrySegmenter, segStatusText,
    VCam
  };
})();
