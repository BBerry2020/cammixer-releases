/*
 * CamMixer - ponte tra l'estensione e il sito, e pannello in pagina.
 * Gira nel contesto isolato dell'estensione: il sito non può leggere né
 * modificare il pannello né le impostazioni salvate.
 */
(() => {
  'use strict';
  if (window.__webcamVirtualiBridge) return;
  window.__webcamVirtualiBridge = true;

  const TAG = '__webcamVirtuali';
  const base = chrome.runtime.getURL('');
  let state = null;           // impostazioni (già validate dal service worker)
  let meta = null;            // cursori e opzioni del motore, dal service worker
  let catalog = null;         // componenti caricati nella pagina: sfondi, effetti, animazioni
  let active = [];            // webcam virtuali in uso in questa pagina
  let segInfo = { state: 'idle', error: '' };
  let pending = {};           // modifiche dal pannello non ancora salvate
  let saveTimer = null;

  const post = (m) => window.postMessage({ [TAG]: 'ext', ...m }, '*');
  const sendState = () => { if (state) post({ type: 'state', state, base }); };
  const alive = () => { try { return !!chrome.runtime.id; } catch { return false; } };
  const ask = (msg) => chrome.runtime.sendMessage(msg).then((r) => {
    if (!r || !r.ok) throw new Error((r && r.error) || 'errore');
    return r.data;
  });

  // Lettura diretta (veloce: molti siti chiedono la fotocamera appena si aprono);
  // il service worker serve solo al primissimo avvio, quando non c'è ancora nulla di salvato.
  const gotState = (s) => { if (s && Array.isArray(s.vcams)) { state = s; sendState(); renderPanel(); } };
  chrome.storage.local.get('state')
    .then((r) => (r.state ? gotState(r.state) : ask({ type: 'get-state' }).then(gotState)))
    .catch(() => {});
  ask({ type: 'meta' }).then((m) => { meta = m; renderPanel(); }).catch(() => {});
  // I componenti vengono iniettati dal service worker, letti dal disco: sempre l'ultima versione
  const needComponents = () => { if (alive()) ask({ type: 'need-components' }).catch(() => {}); };
  needComponents();
  // Mentre una webcam virtuale è in uso, si controlla spesso se i componenti sono cambiati
  setInterval(() => {
    if (!active.length) return;
    if (!alive()) { renderPanel(); return; }   // motore ricaricato: lo si segnala nel pannello
    ask({ type: 'check-components' }).catch(() => {});
  }, 10000);
  chrome.storage.local.get('panelCollapsed').then((r) => { panel.collapsed = !!r.panelCollapsed; renderPanel(); }).catch(() => {});

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.state || !changes.state.newValue) return;
    state = changes.state.newValue;
    // le modifiche appena fatte nel pannello restano visibili finché non vengono salvate
    for (const [id, patch] of Object.entries(pending)) {
      const c = state.vcams.find((x) => x.id === id);
      if (c) Object.assign(c.fx, patch);
    }
    sendState();
    renderPanel();
  });

  // Il salvataggio passa dal service worker, che accetta solo chiavi e valori validi
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      const batch = pending;
      pending = {};
      if (!alive()) return;
      for (const [id, patch] of Object.entries(batch)) ask({ type: 'edit', id, patch }).catch(() => {});
    }, 200);
  }

  function b64ToBuffer(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes.buffer;
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data[TAG] !== 'page') return;
    const m = e.data;
    if (m.type === 'hello') {
      sendState();
    } else if (m.type === 'need-components') {
      needComponents();
    } else if (m.type === 'catalog') {
      const k = m.catalog;
      const okList = (l) => Array.isArray(l) && l.every((x) => x && typeof x.id === 'string' && typeof x.label === 'string');
      if (k && okList(k.backgrounds) && okList(k.effects) && okList(k.animations)) {
        catalog = {
          version: String(k.version || ''), loaded: !!k.loaded,
          backgrounds: k.backgrounds.slice(0, 60), effects: k.effects.slice(0, 40),
          lowerThirds: okList(k.lowerThirds) ? k.lowerThirds.slice(0, 40) : [],
          errors: Array.isArray(k.errors) ? k.errors.slice(0, 5).map((e) => `${String(e.id)}: ${String(e.message)}`) : []
        };
        renderPanel();
      }
    } else if (m.type === 'need-loader') {
      if (!alive()) return post({ type: 'loader', ok: false, error: 'estensione ricaricata: ricarica la pagina' });
      chrome.runtime.sendMessage({ type: 'inject-mediapipe' })
        .then((r) => post({ type: 'loader', ok: !!(r && r.ok), error: r && !r.ok ? String(r.error || '') : '' }))
        .catch((err) => post({ type: 'loader', ok: false, error: String(err && err.message || err) }));
    } else if (m.type === 'need-model') {
      if (!alive()) return post({ type: 'model', modello: m.modello, error: 'estensione ricaricata: ricarica la pagina' });
      const modello = m.modello === 'volto' ? 'volto' : 'ritaglio';
      chrome.runtime.sendMessage({ type: 'get-model', modello })
        .then((r) => post(r && r.ok ? { type: 'model', modello, buffer: b64ToBuffer(r.data) } : { type: 'model', modello, error: (r && r.error) || 'errore' }))
        .catch((err) => post({ type: 'model', modello, error: String(err && err.message || err) }));
    } else if (m.type === 'active') {
      const wasActive = active.length > 0;
      active = Array.isArray(m.vcams) ? m.vcams.filter((v) => v && typeof v.id === 'string').slice(0, 4) : [];
      // appena una webcam virtuale entra in uso lo si dice subito al service worker,
      // che rinvia un eventuale aggiornamento del motore finché la chat è attiva
      if (!wasActive && active.length && alive()) ask({ type: 'check-components' }).catch(() => {});
      if (m.seg && typeof m.seg.state === 'string') segInfo = { state: m.seg.state, error: String(m.seg.error || '') };
      renderPanel();
    }
  });

  // =====================================================================
  // Pannello in pagina: compare quando il sito usa una webcam virtuale
  // =====================================================================

  const PANEL_SLIDERS = ['brightness', 'contrast', 'saturate', 'blur', 'pixel', 'zoom', 'mix', 'bgBlur', 'segSens'];
  const PANEL_TOGGLES = ['invert', 'flipH'];
  const panel = { host: null, root: null, collapsed: false, built: false, els: {} };

  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .wrap { position: fixed; right: 16px; bottom: 16px; z-index: 2147483647; color: #e6e9ed; font-size: 13px; line-height: 1.4; }
    .pill, .card { background: rgba(20, 23, 28, .94); border: 1px solid rgba(255, 255, 255, .12); box-shadow: 0 8px 28px rgba(0, 0, 0, .35); }
    .pill { display: flex; align-items: center; gap: 8px; padding: 7px 14px; border-radius: 999px; color: inherit; font: inherit; font-weight: 600; cursor: pointer; }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: #ff5a4f; flex: none; }
    .card { width: 272px; max-height: calc(100vh - 32px); overflow: auto; border-radius: 12px; padding: 12px 14px 14px; }
    .head { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; cursor: move; user-select: none; }
    .head strong { flex: 1; font-size: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .icon { width: 26px; height: 26px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, .15); background: transparent; color: inherit; cursor: pointer; font: 600 15px/1 system-ui, sans-serif; }
    .status { color: #9aa4b0; font-size: 12px; margin: -2px 0 10px; }
    .status.err { color: #ff8a80; }
    label { display: block; margin: 0 0 8px; }
    .row { display: flex; justify-content: space-between; }
    .row output { color: #9aa4b0; font-variant-numeric: tabular-nums; }
    select, input[type=text] { width: 100%; margin-top: 3px; padding: 5px 8px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, .18); background: #0e1114; color: inherit; font: inherit; }
    input[type=range] { width: 100%; margin: 2px 0 0; accent-color: #4a90e2; }
    .checks { display: flex; flex-wrap: wrap; gap: 4px 14px; margin: 2px 0 10px; }
    .checks label { display: flex; align-items: center; gap: 6px; margin: 0; color: #c9d1d9; }
    .checks input { accent-color: #4a90e2; margin: 0; }
    .more { width: 100%; margin-top: 4px; padding: 7px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, .18); background: #4a90e2; color: #0e1114; font: inherit; font-weight: 600; cursor: pointer; }
    .reset { width: 100%; margin-top: 4px; padding: 6px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, .18); background: transparent; color: inherit; font: inherit; cursor: pointer; }
    [hidden] { display: none !important; }
  `;

  function buildPanel() {
    const host = document.createElement('webcam-virtuali-pannello');
    const root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = CSS;
    const wrap = document.createElement('div');
    wrap.className = 'wrap';
    root.append(style, wrap);

    const pill = document.createElement('button');
    pill.className = 'pill';
    const pillDot = document.createElement('span');
    pillDot.className = 'dot';
    const pillText = document.createElement('span');
    pill.append(pillDot, pillText);
    pill.onclick = () => { if (!dragged) setCollapsed(false); };

    const card = document.createElement('div');
    card.className = 'card';
    const head = document.createElement('div');
    head.className = 'head';
    const dot = document.createElement('span');
    dot.className = 'dot';
    const title = document.createElement('strong');
    const min = document.createElement('button');
    min.className = 'icon';
    min.textContent = '–';
    min.title = 'Riduci';
    min.onclick = () => setCollapsed(true);
    head.append(dot, title, min);
    const status = document.createElement('div');
    status.className = 'status';

    const bgLabel = document.createElement('label');
    bgLabel.textContent = 'Sfondo';
    const bg = document.createElement('select');
    bgLabel.append(bg);
    bg.onchange = () => edit({ bg: bg.value });

    const sliders = {};
    const sliderBox = document.createElement('div');
    for (const id of PANEL_SLIDERS) {
      const s = meta.SLIDERS.find((x) => x.id === id);
      if (!s) continue;
      const label = document.createElement('label');
      const row = document.createElement('div');
      row.className = 'row';
      const name = document.createElement('span');
      name.textContent = s.label;
      const out = document.createElement('output');
      row.append(name, out);
      const input = document.createElement('input');
      input.type = 'range';
      input.min = s.min;
      input.max = s.max;
      input.oninput = () => { out.textContent = fmt(s, Number(input.value)); edit({ [id]: Number(input.value) }); };
      if (s.hint) label.title = s.hint;
      label.append(row, input);
      sliderBox.append(label);
      sliders[id] = { label, input, out, s };
    }

    const fxBox = document.createElement('div');   // effetti dei componenti, ricostruiti a ogni aggiornamento

    const checks = document.createElement('div');
    checks.className = 'checks';
    const toggles = {};
    for (const id of PANEL_TOGGLES) {
      const t = meta.TOGGLES.find((x) => x.id === id);
      if (!t) continue;
      const label = document.createElement('label');
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.onchange = () => edit({ [id]: cb.checked });
      label.append(cb, t.label);
      checks.append(label);
      toggles[id] = cb;
    }

    const textLabel = document.createElement('label');
    textLabel.textContent = 'Testo sovrapposto';
    const text = document.createElement('input');
    text.type = 'text';
    text.maxLength = 60;
    text.placeholder = 'Es. un nome';
    text.oninput = () => edit({ text: text.value.trim() });
    textLabel.append(text);

    const newsLabel = document.createElement('label');
    newsLabel.textContent = 'Sottopancia';
    const newsStyle = document.createElement('select');
    newsStyle.onchange = () => { const cur = currentConfig(); if (cur) edit({ news: { ...cur.fx.news, style: newsStyle.value } }); };
    newsLabel.append(newsStyle);
    const headLabel = document.createElement('label');
    headLabel.textContent = 'Notizia';
    const headline = document.createElement('input');
    headline.type = 'text';
    headline.maxLength = 90;
    headline.placeholder = 'Il titolo in primo piano';
    headline.oninput = () => { const cur = currentConfig(); if (cur) edit({ news: { ...cur.fx.news, headline: headline.value } }); };
    headLabel.append(headline);
    const posLabel = document.createElement('label');
    const posRow = document.createElement('div');
    posRow.className = 'row';
    const posName = document.createElement('span');
    posName.textContent = 'Altezza sottopancia';
    const posOut = document.createElement('output');
    posRow.append(posName, posOut);
    const posInput = document.createElement('input');
    posInput.type = 'range';
    posInput.min = -70;
    posInput.max = 20;
    posInput.oninput = () => {
      const cur = currentConfig();
      if (!cur) return;
      posOut.textContent = `${posInput.value}%`;
      edit({ news: { ...cur.fx.news, y: Number(posInput.value) } });
    };
    posLabel.append(posRow, posInput);

    const reset = document.createElement('button');
    reset.className = 'reset';
    reset.textContent = 'Ripristina effetti';
    reset.title = 'Riporta modifiche ed effetti ai valori iniziali (sfondo, testi ed elementi restano)';
    reset.onclick = () => edit({ ...meta.RESET });

    const more = document.createElement('button');
    more.className = 'more';
    more.textContent = 'Tutte le impostazioni…';
    more.onclick = () => { if (alive()) chrome.runtime.sendMessage({ type: 'open-options' }).catch(() => {}); };

    card.append(head, status, bgLabel, sliderBox, fxBox, checks, textLabel, newsLabel, headLabel, posLabel, reset, more);
    wrap.append(pill, card);

    // I tasti premuti nel pannello non arrivano al sito (niente scorciatoie accidentali)
    for (const type of ['keydown', 'keyup', 'keypress']) root.addEventListener(type, (e) => e.stopPropagation());

    // Trascinamento dal titolo o dalla pillola
    let dragged = false;
    const startDrag = (e) => {
      if (e.button !== 0 || e.target === min) return;
      const r0 = wrap.getBoundingClientRect();
      const sx = e.clientX, sy = e.clientY;
      const right0 = window.innerWidth - r0.right, bottom0 = window.innerHeight - r0.bottom;
      dragged = false;
      const move = (ev) => {
        const dx = ev.clientX - sx, dy = ev.clientY - sy;
        if (Math.abs(dx) + Math.abs(dy) > 4) dragged = true;
        wrap.style.right = `${Math.max(0, Math.min(window.innerWidth - 60, right0 - dx))}px`;
        wrap.style.bottom = `${Math.max(0, Math.min(window.innerHeight - 40, bottom0 - dy))}px`;
      };
      const up = () => { window.removeEventListener('pointermove', move, true); window.removeEventListener('pointerup', up, true); };
      window.addEventListener('pointermove', move, true);
      window.addEventListener('pointerup', up, true);
    };
    head.addEventListener('pointerdown', startDrag);
    pill.addEventListener('pointerdown', startDrag);

    (document.body || document.documentElement).append(host);
    Object.assign(panel, { host, root, built: true, els: { pill, pillText, card, title, status, bg, sliders, fxBox, toggles, text, newsStyle, headline, headLabel, posLabel, posInput, posOut }, fxSig: '', fxSliders: {} });
  }

  function fmt(s, v) { return s.off !== undefined && v === s.off ? 'no' : `${v}${s.unit}`; }

  function setCollapsed(c) {
    panel.collapsed = c;
    if (alive()) chrome.storage.local.set({ panelCollapsed: c }).catch(() => {});
    renderPanel();
  }

  function currentConfig() {
    if (!state || !active.length) return null;
    return state.vcams.find((c) => c.id === active[0].id) || null;
  }

  function edit(patch) {
    const c = currentConfig();
    if (!c) return;
    Object.assign(c.fx, patch);
    pending[c.id] = { ...(pending[c.id] || {}), ...patch };
    sendState();   // effetto immediato nella pagina
    save();        // e salvato per le altre schede e le impostazioni
    renderPanel();
  }

  function renderPanel() {
    const c = currentConfig();
    if (!c || !meta || !catalog) { if (panel.host) panel.host.style.display = 'none'; return; }
    if (!panel.built) buildPanel();
    panel.host.style.display = '';
    const el = panel.els;
    const info = active[0];
    el.pill.hidden = !panel.collapsed;
    el.card.hidden = panel.collapsed;
    el.pillText.textContent = c.name;
    el.title.textContent = `Webcam virtuale: ${c.name}`;

    let msg = '', err = false;
    if (!alive()) { msg = "Estensione aggiornata: ricarica la pagina per usare le novità (il video continua)."; err = true; }
    else if (info.status === 'error') { msg = info.error; err = true; }
    else if (c.fx.bg !== 'none' && c.source !== meta.NO_CAMERA) {
      if (segInfo.state === 'error') { msg = `Ritaglio non disponibile (${segInfo.error}).`; err = true; }
      else if (segInfo.state !== 'ready') msg = 'Caricamento del ritaglio…';
    }
    if (!msg && catalog.errors.length) { msg = `Componente disattivato per un errore: ${catalog.errors[0]}`; err = true; }
    el.status.textContent = msg;
    el.status.className = err ? 'status err' : 'status';
    el.status.hidden = !msg;

    const noCam = c.source === meta.NO_CAMERA;
    const bgs = catalog.backgrounds.some((b) => b.id === c.fx.bg) ? catalog.backgrounds
      : [...catalog.backgrounds, { id: c.fx.bg, label: `${c.fx.bg} (componente non disponibile)` }];
    el.bg.replaceChildren(...bgs.map((b) => {
      const o = new Option(b.label, b.id);
      if (b.id === 'media' && (!c.fx.bgImage || noCam)) {
        o.disabled = true;
        o.textContent = noCam ? 'Immagine tua (serve la telecamera)' : 'Immagine tua (caricala nelle impostazioni)';
      }
      return o;
    }));
    el.bg.value = c.fx.bg;

    for (const [id, s] of Object.entries(el.sliders)) {
      if (id === 'bgBlur') s.label.hidden = c.fx.bg !== 'blur';
      else if (id === 'segSens') s.label.hidden = c.fx.bg === 'none' || noCam;   // serve solo col ritaglio attivo
      else s.label.hidden = noCam;   // senza telecamera non c'è video reale da modificare
      if (panel.root.activeElement !== s.input) s.input.value = c.fx[id];
      s.out.textContent = fmt(s.s, c.fx[id]);
    }
    for (const [id, cb] of Object.entries(el.toggles)) {
      cb.checked = !!c.fx[id];
      cb.parentElement.hidden = noCam;
    }
    if (panel.root.activeElement !== el.text) el.text.value = c.fx.text;
    const news = c.fx.news || { style: '', headline: '' };
    const lts = [{ id: '', label: 'Nessuno' }, ...(catalog.lowerThirds || [])];
    if (news.style && !lts.some((x) => x.id === news.style)) lts.push({ id: news.style, label: `${news.style} (non disponibile)` });
    el.newsStyle.replaceChildren(...lts.map((x) => new Option(x.label, x.id)));
    el.newsStyle.value = news.style;
    el.headLabel.hidden = !news.style;
    el.posLabel.hidden = !news.style;
    if (panel.root.activeElement !== el.posInput) el.posInput.value = Number(news.y) || 0;
    el.posOut.textContent = `${Number(news.y) || 0}%`;
    if (panel.root.activeElement !== el.headline) el.headline.value = news.headline;
    renderEffects(c);
  }

  // Cursori degli effetti: dipendono dai componenti caricati, quindi si ricostruiscono
  // quando arriva una versione nuova (senza ricaricare la pagina)
  function renderEffects(c) {
    const sig = catalog.effects.map((e) => `${e.id}=${e.label}`).join('|');
    if (sig !== panel.fxSig) {
      panel.fxSig = sig;
      panel.fxSliders = {};
      panel.els.fxBox.replaceChildren(...catalog.effects.map((e) => {
        const label = document.createElement('label');
        const row = document.createElement('div');
        row.className = 'row';
        const name = document.createElement('span');
        name.textContent = e.label;
        const out = document.createElement('output');
        row.append(name, out);
        const input = document.createElement('input');
        input.type = 'range';
        input.min = 0;
        input.max = 100;
        input.oninput = () => {
          const cur = currentConfig();
          if (!cur) return;
          out.textContent = `${input.value}%`;
          edit({ effects: { ...(cur.fx.effects || {}), [e.id]: Number(input.value) } });
        };
        label.append(row, input);
        panel.fxSliders[e.id] = { input, out };
        return label;
      }));
    }
    const values = c.fx.effects || {};
    for (const [id, s] of Object.entries(panel.fxSliders)) {
      const v = Number(values[id]) || 0;
      if (panel.root.activeElement !== s.input) s.input.value = v;
      s.out.textContent = `${v}%`;
    }
  }
})();
