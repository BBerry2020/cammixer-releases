/*
 * CamMixer - service worker
 * - custodisce le impostazioni: le valida e le salva (anche le modifiche dal pannello nei siti)
 * - aggiorna al volo i componenti (componenti/componenti.js) nelle pagine aperte
 * - si ricarica da sola quando cambiano i file del motore (quando nessuna webcam virtuale è in uso)
 * - scarica una volta il modello di ritaglio della persona e lo tiene in cache
 * - tiene aperto il documento che invia la webcam virtuale alla webcam di Windows (Teams, Zoom...)
 * - apre la pagina delle impostazioni
 */
importScripts('core.js');
const C = WebcamVirtualiCore;

const MODEL_URL = 'https://storage.googleapis.com/mediapipe-models/image_segmenter/selfie_segmenter_landscape/float16/latest/selfie_segmenter_landscape.tflite';
// Modelli di MediaPipe: «ritaglio» sempre, «volto» solo per gli esempi 3D sul volto
const MODELLI = {
  ritaglio: MODEL_URL,
  volto: 'https://storage.googleapis.com/mediapipe-models/face_landmarker/face_landmarker/float16/latest/face_landmarker.task'
};
const CACHE = 'webcam-virtuali-modello-v1';
const COMPONENTS_FILE = 'componenti/componenti.js';
const COMPONENTS_ALARM = 'controllo-componenti';
// Rilasci di CamMixer (estensione, installer per Windows, programma per macOS): sempre qui
const RILASCI_PAGINA = 'https://github.com/BBerry2020/cammixer-releases';
const RILASCI_MANIFESTO = 'https://raw.githubusercontent.com/BBerry2020/cammixer-releases/main/aggiornamenti.json';
const RILASCI_ALARM = 'controllo-rilasci';

chrome.runtime.onInstalled.addListener(async (details) => {
  await getState();   // al primo avvio salva le impostazioni iniziali (Webcam1 predefinita)
  await rememberEngine();
  await startComponentsWatch();
  await ensureWindowsBridge().catch(() => {});
  await startReleasesWatch();
  if (details.reason === 'install') chrome.runtime.openOptionsPage();
});
chrome.runtime.onStartup.addListener(async () => {
  await rememberEngine(); startComponentsWatch(); ensureWindowsBridge().catch(() => {}); startReleasesWatch();
});

// Dopo un riavvio automatico del motore: riapre le impostazioni se erano aperte
chrome.storage.local.get('reopenOptions').then(async ({ reopenOptions }) => {
  if (!reopenOptions) return;
  await chrome.storage.local.remove('reopenOptions');
  await rememberEngine();
  chrome.runtime.openOptionsPage();
}).catch(() => {});

chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

// Le modifiche vengono applicate una alla volta, per non perderne nessuna
let queue = Promise.resolve();
const serial = (fn) => (queue = queue.then(fn, fn));

async function getState() {
  const stored = (await chrome.storage.local.get('state')).state;
  const state = C.normalizeState(stored);
  if (!stored) await chrome.storage.local.set({ state });
  return state;
}

// =====================================================================
// Componenti aggiornabili al volo
// L'estensione è caricata da una cartella: il browser rilegge dal disco i file
// modificati. Quando componenti.js cambia (impronta diversa) viene iniettato
// di nuovo in tutte le pagine aperte; le impostazioni si aggiornano da sole.
// =====================================================================

async function componentsHash() {
  const res = await fetch(chrome.runtime.getURL(COMPONENTS_FILE), { cache: 'no-store' });
  if (!res.ok) throw new Error(`componenti non leggibili (HTTP ${res.status})`);
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(await res.text()));
  return [...new Uint8Array(buf)].slice(0, 8).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function injectComponents(target) {
  return chrome.scripting.executeScript({ target, world: 'MAIN', files: [COMPONENTS_FILE], injectImmediately: true });
}

let checking = null;
function checkComponents() {
  if (checking) return checking;
  checking = (async () => {
    const hash = await componentsHash();
    const { components } = await chrome.storage.local.get('components');
    if (components && components.hash === hash) return { changed: false, hash, at: components.at };
    const at = Date.now();
    await chrome.storage.local.set({ components: { hash, at } });   // avvisa le pagine delle impostazioni
    if (components) {
      // nuova versione: la si inietta in tutte le pagine aperte (dove l'estensione non c'è, non fa nulla)
      const tabs = await chrome.tabs.query({});
      await Promise.all(tabs.map((t) => injectComponents({ tabId: t.id, allFrames: true }).catch(() => {})));
    }
    return { changed: !!components, hash, at };
  })().finally(() => { checking = null; });
  return checking;
}

// =====================================================================
// Motore (tutti gli altri file): se cambia sul disco l'estensione si ricarica da sola.
// L'impronta del motore in uso viene salvata quando l'estensione si carica; se la
// copia sul disco è diversa e nessuna webcam virtuale è in uso, si ricarica.
// =====================================================================

const ENGINE_FILES = ['manifest.json', 'core.js', 'inject.js', 'bridge.js', 'background.js', 'options.html', 'options.js',
  'ponte-windows.html', 'ponte-windows.js'];

async function engineHash() {
  const parts = await Promise.all(ENGINE_FILES.map(async (f) => {
    const res = await fetch(chrome.runtime.getURL(f), { cache: 'no-store' });
    return `${f}\n${res.ok ? await res.text() : res.status}`;
  }));
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(parts.join('\n\u0000\n')));
  return [...new Uint8Array(buf)].slice(0, 8).map((b) => b.toString(16).padStart(2, '0')).join('');
}

async function rememberEngine() {
  try { await chrome.storage.local.set({ engine: { hash: await engineHash(), at: Date.now() } }); } catch { /* ignora */ }
}

async function markInUse() {
  try { await chrome.storage.session.set({ lastInUse: Date.now() }); } catch { /* ignora */ }
}

async function checkEngine() {
  const { engine } = await chrome.storage.local.get('engine');
  if (!engine) return rememberEngine();
  const hash = await engineHash();
  if (hash === engine.hash) return;
  // una chat sta usando una webcam virtuale: si aspetta (il controllo si ripete ogni 30 secondi)
  const { lastInUse } = await chrome.storage.session.get('lastInUse');
  if (lastInUse && Date.now() - lastInUse < 25000) return;
  const options = await chrome.runtime.getContexts({ contextTypes: ['TAB'], documentUrls: [chrome.runtime.getURL('options.html')] });
  if (options.length) await chrome.storage.local.set({ reopenOptions: true });
  chrome.runtime.reload();
}

async function startComponentsWatch() {
  // controllo ogni 30 secondi (il minimo consentito), più quelli chiesti da pagine e impostazioni
  await chrome.alarms.create(COMPONENTS_ALARM, { periodInMinutes: 0.5 });
  await checkComponents().catch(() => {});
}

// ---------------------------------------------------------------------
// Rilasci: ogni 6 ore si legge aggiornamenti.json di cammixer-releases e si segnala
// nelle impostazioni se c'è una versione più recente dell'estensione (solo lettura:
// un'estensione caricata da una cartella non può aggiornarsi da sola; su Windows la
// aggiorna il programma CamMixer).
// ---------------------------------------------------------------------

function confrontaVersioni(a, b) {
  const x = String(a).split('.').map((n) => parseInt(n, 10) || 0), y = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0) ? 1 : -1;
  return 0;
}

async function checkReleases() {
  const attuale = chrome.runtime.getManifest().version;
  const res = await fetch(RILASCI_MANIFESTO, { cache: 'no-store', credentials: 'omit' });
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  const m = await res.json();
  const e = m && typeof m.estensione === 'object' ? m.estensione : null;
  const versione = e && /^\d+\.\d+\.\d+$/.test(e.versione || '') ? e.versione : '';
  // programmi per Windows e macOS: versione e indirizzo, solo se pubblicati in cammixer-releases
  const prog = (k) => {
    const x = m && typeof m[k] === 'object' ? m[k] : null;
    const ok = x && /^\d+\.\d+\.\d+$/.test(x.versione || '') && /^https:\/\/(github\.com|raw\.githubusercontent\.com)\/BBerry2020\/cammixer-releases\//.test(x.url || '');
    return ok ? { versione: x.versione, url: x.url } : null;
  };
  const rilascio = {
    controllato: Date.now(), attuale, versione,
    nuova: !!versione && confrontaVersioni(versione, attuale) > 0,
    programmi: /^\d+\.\d+\.\d+$/.test(m && m.versione || '') ? m.versione : '',
    windows: prog('windows'), macos: prog('macos'),
    pagina: RILASCI_PAGINA
  };
  await chrome.storage.local.set({ rilascio });
  return rilascio;
}

async function startReleasesWatch() {
  await chrome.alarms.create(RILASCI_ALARM, { periodInMinutes: 360, delayInMinutes: 1 });
}

chrome.alarms.onAlarm.addListener(async (a) => {
  if (a.name === RILASCI_ALARM) { await checkReleases().catch(() => {}); return; }
  if (a.name !== COMPONENTS_ALARM) return;
  await checkComponents().catch(() => {});
  await checkEngine().catch(() => {});
  await ensureWindowsBridge().catch(() => {});
});

// =====================================================================
// Webcam di Windows (Teams, Zoom, Fotocamera...)
// Un documento offscreen nascosto resta collegato al programma ponte per Windows
// e, quando un'app apre la webcam "CamMixer", le invia la webcam virtuale scelta.
// =====================================================================

const BRIDGE_URL = 'ponte-windows.html';

async function getWindowsSettings() {
  const { windows } = await chrome.storage.local.get('windows');
  return {
    attiva: !windows || windows.attiva !== false,
    webcam: (windows && typeof windows.webcam === 'string') ? windows.webcam : ''
  };
}

let ensuring = null;
function ensureWindowsBridge() {
  if (ensuring) return ensuring;
  ensuring = (async () => {
    if (!chrome.offscreen) return;
    const { attiva } = await getWindowsSettings();
    const open = await chrome.runtime.getContexts({ contextTypes: ['OFFSCREEN_DOCUMENT'] });
    if (attiva && !open.length) {
      await chrome.offscreen.createDocument({
        url: BRIDGE_URL,
        reasons: ['USER_MEDIA'],
        justification: 'Invia la webcam virtuale scelta alle app del computer (Teams, Zoom...) tramite il programma CamMixer.'
      });
    } else if (!attiva && open.length) {
      await chrome.offscreen.closeDocument();
      await chrome.storage.session.remove('windowsStato');
    }
  })().finally(() => { ensuring = null; });
  return ensuring;
}
ensureWindowsBridge().catch(() => {});   // a ogni avvio del service worker

// Il documento offscreen non può leggere chrome.storage: gli si segnalano i cambiamenti
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  if (changes.windows) ensureWindowsBridge().catch(() => {});
  if (changes.state || changes.windows || changes.components) {
    chrome.runtime.sendMessage({
      type: 'windows-aggiorna',
      impostazioni: !!changes.windows,
      components: changes.components && changes.components.newValue ? changes.components.newValue.hash : ''
    }).catch(() => {});
  }
});

// =====================================================================
// Messaggi da pagine, pannello e impostazioni
// =====================================================================

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (!msg || typeof msg.type !== 'string' || sender.id !== chrome.runtime.id) return false;
  const reply = (p) => {
    p.then((data) => sendResponse({ ok: true, data }))
      .catch((e) => sendResponse({ ok: false, error: String((e && e.message) || e) }));
    return true; // risposta asincrona
  };
  switch (msg.type) {
    case 'meta':
      return reply(Promise.resolve({
        NO_CAMERA: C.NO_CAMERA, SLIDERS: C.SLIDERS, TOGGLES: C.TOGGLES, RESET: C.effectDefaults()
      }));
    case 'get-state':
      return reply(serial(getState));
    case 'edit':
      return reply(serial(async () => {
        const state = await getState();
        const c = state.vcams.find((x) => x.id === msg.id);
        if (!c || !msg.patch || typeof msg.patch !== 'object') return false;
        c.fx = C.mergeFx({ ...c.fx, ...msg.patch });   // solo chiavi e valori ammessi
        await chrome.storage.local.set({ state });
        return true;
      }));
    case 'need-components':
      // una pagina si è appena aperta: riceve i componenti attuali, letti dal disco
      if (!sender.tab) return false;
      checkComponents().catch(() => {});
      return reply(injectComponents({ tabId: sender.tab.id, frameIds: [sender.frameId || 0] }).then(() => true));
    case 'check-components': {
      // dai siti arriva solo mentre una webcam virtuale è in uso; dalla pagina delle
      // impostazioni (anch'essa in una scheda, ma con indirizzo dell'estensione) ogni 3 secondi
      // il documento della webcam di Windows la segnala in uso mentre un'app la sta usando
      const fromSite = !!sender.tab && !String(sender.url || '').startsWith(chrome.runtime.getURL(''));
      if (fromSite || msg.inUso === true) markInUse();
      else checkEngine().catch(() => {});
      return reply(checkComponents());
    }
    case 'check-releases':
      return reply(checkReleases());
    case 'get-model':
      return reply(getModelBase64(msg.modello));
    case 'inject-mediapipe':
      // caricatore di MediaPipe (definisce ModuleFactory) nel mondo della pagina che lo chiede
      if (!sender.tab) return false;
      return reply(chrome.scripting.executeScript({
        target: { tabId: sender.tab.id, frameIds: [sender.frameId || 0] },
        world: 'MAIN', files: ['mediapipe/wasm/vision_wasm_internal.js'], injectImmediately: true
      }).then(() => true));
    case 'get-windows':
      return reply(getWindowsSettings());
    case 'windows-stato':
      // dal documento della webcam di Windows: la pagina delle impostazioni lo mostra
      if (sender.tab || !String(sender.url || '').startsWith(chrome.runtime.getURL(BRIDGE_URL))) return false;
      if (!msg.stato || typeof msg.stato !== 'object') return false;
      return reply(chrome.storage.session.set({ windowsStato: { ...msg.stato, at: Date.now() } }).then(() => true));
    case 'open-options':
      chrome.runtime.openOptionsPage();
      return false;
    default:
      return false;
  }
});

async function getModelBase64(nome) {
  const url = MODELLI[nome] || MODEL_URL;
  const cache = await caches.open(CACHE);
  let res = await cache.match(url);
  if (!res) {
    let net;
    try {
      net = await fetch(url);
    } catch {
      throw new Error('download del modello non riuscito: serve Internet al primo uso');
    }
    if (!net.ok) throw new Error(`download del modello non riuscito (HTTP ${net.status})`);
    await cache.put(url, net.clone());
    res = net;
  }
  const bytes = new Uint8Array(await res.arrayBuffer());
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}
