/*
 * CamMixer - Italian translation of the interface (Italiano).
 * Keys are the English texts used in the code and in the pages (whitespace-normalised HTML for
 * elements with data-t); {name} placeholders must be kept as they are.
 * To add a language: copy this file as lingua-<id>.js, translate the values, add the language to
 * LINGUE in lingua.js and load the file wherever lingua-it.js is loaded.
 */
CamMixerLingua.aggiungi('it', {
  "Brightness":
    "Luminosità",
  "Contrast":
    "Contrasto",
  "Saturation":
    "Saturazione",
  "Hue":
    "Tonalità",
  "Blur":
    "Sfocatura",
  "Black and white":
    "Bianco e nero",
  "Sepia":
    "Seppia",
  "Negative":
    "Negativo",
  "Flip horizontally":
    "Ribalta orizzontale",
  "Flip vertically":
    "Ribalta verticale",
  "Adjustment strength":
    "Intensità delle modifiche",
  "Blur strength":
    "Intensità sfocatura",
  "Cut-out sensitivity":
    "Sensibilità ritaglio",
  "Soft edge":
    "Bordo morbido",
  "Stability":
    "Stabilità",
  "Blurred":
    "Sfocato",
  "Solid colour":
    "Colore pieno",
  "Your image":
    "Immagine tua",
  "Text":
    "Testo",
  "Image":
    "Immagine",
  "Label":
    "Etichetta",
  "Role":
    "Ruolo",
  "Headline":
    "Notizia",
  "Scrolling ticker":
    "Striscia che scorre",
  "Horizontal":
    "Orizzontale",
  "Vertical":
    "Verticale",
  "Size":
    "Dimensione",
  "Name":
    "Nome",
  "None":
    "Nessuno",
  "Pixel":
    "Pixel",
  "Zoom":
    "Zoom",
  "Emoji":
    "Emoji",
  "Higher removes more background (no halo around you); if parts of you disappear, lower it.":
    "Più alta toglie più sfondo (via l'alone intorno a te); se sparisce parte di te, abbassala.",
  "Higher softens the outline; lower makes it sharp.":
    "Più alto sfuma il contorno; più basso lo rende netto.",
  "Higher reduces outline flicker but follows movements with a slight delay.":
    "Più alta riduce lo sfarfallio del contorno ma segue i movimenti con un po' di ritardo.",
  "E.g. BREAKING NEWS, LIVE":
    "Es. ULTIM'ORA, IN DIRETTA",
  "E.g. First Last":
    "Es. Nome Cognome",
  "E.g. Special correspondent":
    "Es. Inviato speciale",
  "The main headline":
    "Il titolo in primo piano",
  "News items separated by | (vertical bar)":
    "Notizie separate da | (barra verticale)",
  "BREAKING NEWS":
    "ULTIM'ORA",
  "Virtual webcam":
    "Webcam virtuale",
  "Webcam access denied: allow it from the camera icon in the address bar.":
    "Accesso alla webcam negato: consentilo dall'icona della fotocamera nella barra degli indirizzi.",
  "No webcam found. You can choose “No camera” as the source.":
    "Nessuna webcam trovata. Puoi scegliere «Nessuna telecamera» come sorgente.",
  "The webcam is in use by another application.":
    "La webcam è in uso da un'altra applicazione.",
  "The chosen webcam is not available.":
    "La webcam scelta non è disponibile.",
  "Cannot start the webcam: {error}":
    "Impossibile avviare la webcam: {error}",
  "the library could not be loaded":
    "caricamento della libreria non riuscito",
  "Choose a background: the person is cut out and placed in front of it.":
    "Scegli uno sfondo: la persona viene ritagliata e messa in primo piano.",
  "Without a camera the background fills the whole video.":
    "Senza telecamera lo sfondo occupa tutto il video.",
  "Person cut-out active.":
    "Ritaglio della persona attivo.",
  "Cut-out not available ({error}).":
    "Ritaglio non disponibile ({error}).",
  "Loading the cut-out model…":
    "Caricamento del modello di ritaglio…",
  "invalid component package":
    "pacchetto di componenti non valido",
  "{name} — no signal":
    "{name} — nessun segnale",
  "No real webcam found.":
    "Nessuna webcam reale trovata.",
  "The real webcam was disconnected.":
    "La webcam reale è stata scollegata.",
  "Your image is used as a background behind you":
    "L'immagine tua si usa come sfondo dietro di te",
  "Upload an image in the settings":
    "Carica un'immagine nelle impostazioni",
  "No animation":
    "Nessuna",
  "extension folder not reachable":
    "cartella dell'estensione non raggiungibile",
  "3D examples not available: {error}":
    "Esempi 3D non disponibili: {error}",
  "Loading the 3D examples…":
    "Caricamento degli esempi 3D…",
  "Face tracking not available: {error}":
    "Tracciamento del volto non disponibile: {error}",
  "Loading face tracking…":
    "Caricamento del tracciamento del volto…",
  "Neon grid (animated)":
    "Griglia al neon (animato)",
  "Starfield (animated)":
    "Campo stellare (animato)",
  "Ring tunnel (animated)":
    "Tunnel di anelli (animato)",
  "Northern lights (animated)":
    "Aurora boreale (animato)",
  "Oscilloscope (animated)":
    "Oscilloscopio (animato)",
  "Lava lamp (animated)":
    "Lampada di lava (animato)",
  "Plasma (animated)":
    "Plasma (animato)",
  "VHS noise (animated)":
    "Disturbo VHS (animato)",
  "3D TV studio (3D example)":
    "Studio TV 3D (esempio 3D)",
  "3D crystals (3D example)":
    "Cristalli 3D (esempio 3D)",
  "TV scanlines":
    "Linee TV",
  "Film grain":
    "Grana",
  "Vignette":
    "Vignettatura",
  "Glow (3D, graphics card)":
    "Bagliore (3D, scheda video)",
  "CRT monitor (3D, graphics card)":
    "Monitor CRT (3D, scheda video)",
  "Chromatic aberration (3D, graphics card)":
    "Aberrazione cromatica (3D, scheda video)",
  "3D glasses (follow your face)":
    "Occhiali 3D (seguono il volto)",
  "3D crown (follows your face)":
    "Corona 3D (segue il volto)",
  "3D robot avatar (covers your face)":
    "Avatar robot 3D (copre il volto)",
  "Rotating 3D logo":
    "Logo 3D rotante",
  "🕶️ Glasses":
    "🕶️ Occhiali",
  "👑 Crown":
    "👑 Corona",
  "🤖 Robot":
    "🤖 Robot",
  "Breaking news (red)":
    "Ultim'ora (rosso)",
  "TV news (blue)":
    "Telegiornale (blu)",
  "Pulse":
    "Pulsa",
  "Bounce":
    "Rimbalza",
  "Float":
    "Fluttua",
  "Spin":
    "Ruota",
  "Blink":
    "Lampeggia",
  "Scroll":
    "Scorre",
  "Rainbow":
    "Arcobaleno",
  "Glitch":
    "Glitch",
  "Minimal":
    "Minimal",
  "Neon":
    "Neon",
  "Sport":
    "Sport",
  "model not available":
    "modello non disponibile",
  "· in websites":
    "· nei siti",
  "No camera":
    "Senza telecamera",
  "Output · {name}":
    "Output · {name}",
  "No camera: this virtual webcam only shows background, animations and text.":
    "Nessuna telecamera: questa webcam virtuale mostra solo sfondo, animazioni e testo.",
  "Starting the real webcam…":
    "Avvio della webcam reale…",
  "Real webcam not active":
    "Webcam reale non attiva",
  "Preview stopped.":
    "Anteprima ferma.",
  "Stop":
    "Ferma",
  "Start":
    "Avvia",
  "No camera (background and text only)":
    "Nessuna telecamera (solo sfondo e testo)",
  "{id} (component not available)":
    "{id} (componente non disponibile)",
  "Your image (needs the camera)":
    "Immagine tua (serve la telecamera)",
  "Change image…":
    "Cambia immagine…",
  "Choose an image…":
    "Scegli un'immagine…",
  "Choose an image to put behind you.":
    "Scegli un'immagine da mettere dietro di te.",
  "No effects available in the components.":
    "Nessun effetto disponibile nei componenti.",
  "Logo text (empty: {text})":
    "Testo del logo (vuoto: {text})",
  "Choose an object: it follows your face and copies its movements.":
    "Scegli un oggetto: segue il volto e ne copia i movimenti.",
  "Face tracking active.":
    "Tracciamento del volto attivo.",
  "Loading face tracking (the first time it downloads the model)…":
    "Caricamento del tracciamento del volto (la prima volta scarica il modello)…",
  "Use an image…":
    "Usa un'immagine…",
  "Remove the image":
    "Togli l'immagine",
  "Logo image":
    "Immagine del logo",
  "Rotation":
    "Rotazione",
  "Green phosphor terminal (animated)":
    "Terminale a fosfori verdi (animato)",
  "CGA graphics (animated)":
    "Grafica CGA (animato)",
  "EGA graphics (animated)":
    "Grafica EGA (animato)",
  "Digital rain (animated)":
    "Pioggia digitale (animato)",
  "Green phosphor monitor":
    "Monitor a fosfori verdi",
  "CGA palette (4 colours)":
    "Tavolozza CGA (4 colori)",
  "EGA palette (16 colours)":
    "Tavolozza EGA (16 colori)",
  "Turns the image or text on the logo to straighten it":
    "Ruota l'immagine o il testo sul logo per raddrizzarlo",
  "With an image the logo shows it; otherwise the text.":
    "Con un'immagine il logo mostra quella; altrimenti il testo.",
  "First Last":
    "Nome Cognome",
  "Special correspondent":
    "Inviato speciale",
  "The headline of the main story":
    "Il titolo della notizia in primo piano",
  "First story of the day | Second story | The weather forecast for tomorrow":
    "Prima notizia della giornata | Seconda notizia | Le previsioni del tempo per domani",
  "The one used in websites ({name})":
    "Quella usata nei siti ({name})",
  "The one used in websites":
    "Quella usata nei siti",
  "Off.":
    "Disattivata.",
  "Off: the Windows “CamMixer” webcam shows a message instead of the video.":
    "Disattivata: la webcam «CamMixer» di Windows mostra un messaggio invece del video.",
  "Connecting to the CamMixer program for {system}…":
    "Collegamento al programma CamMixer per {system}…",
  "The CamMixer program for {system} is not reachable: install it (see below) or restart the computer.":
    "Il programma CamMixer per {system} non è raggiungibile: installalo (vedi sotto) oppure riavvia il computer.",
  "The CamMixer program for {system} is running, but it could not create the webcam: {error}.":
    "Il programma CamMixer per {system} è avviato, ma non ha potuto creare la webcam: {error}.",
  "In use, but “{webcam}” does not start: {error}":
    "In uso, ma «{webcam}» non parte: {error}",
  "In use: sending “{webcam}” at {width}×{height}, {fps} frames per second.":
    "In uso: invio di «{webcam}» a {width}×{height}, {fps} fotogrammi al secondo.",
  "Ready (CamMixer program for macOS {version}): in OBS add a Browser source with this address, then “Start Virtual Camera”. OBS is not reading it right now.":
    "Pronto (programma CamMixer per macOS {version}): in OBS aggiungi una sorgente Browser con questo indirizzo, poi «Avvia fotocamera virtuale». OBS ora non lo sta leggendo.",
  "Ready: the “CamMixer” webcam is available in Windows apps (program {version}). No app is using it.":
    "Pronta: la webcam «CamMixer» è disponibile nelle app di Windows (programma {version}). Nessuna app la sta usando.",
  "Open the releases page":
    "Apri la pagina dei rilasci",
  "CamMixer {new} for Windows is out (you have {old}): download the installer from the releases page and run it (Windows asks for administrator permission).":
    "È uscita CamMixer {new} per Windows (hai la {old}): scarica l'installer dalla pagina dei rilasci e avvialo (Windows chiede il permesso di amministratore).",
  "Retry":
    "Riprova",
  "Install now":
    "Installa ora",
  "Downloading version {version}…":
    "Scaricamento della versione {version}…",
  "Installing version {version}…":
    "Installazione della versione {version}…",
  "Update to version {version} failed ({error}).":
    "Aggiornamento alla versione {version} non riuscito ({error}).",
  "Version {version} available: it installs itself as soon as OBS is not using the stream.":
    "Versione {version} disponibile: si installa da sola appena OBS non usa il flusso.",
  "Copied":
    "Copiato",
  "Copy":
    "Copia",
  "Components not loaded.":
    "Componenti non caricati.",
  "Engine {engine} · components {components} · {backgrounds} backgrounds, {effects} effects, {animations} animations · loaded at {time}.":
    "Motore {engine} · componenti {components} · {backgrounds} sfondi, {effects} effetti, {animations} animazioni · caricati alle {time}.",
  "Last update not valid, the previous ones stay active: {error}":
    "Ultimo aggiornamento non valido, restano attivi quelli di prima: {error}",
  "Turned off because of an error: {list}.":
    "Disattivati per errore: {list}.",
  "file not readable":
    "file non leggibile",
  "{message} (line {line})":
    "{message} (riga {line})",
  "Extension {current}: version {new} is out; it comes with the update of the CamMixer program (box above) or from ":
    "Estensione {current}: è uscita la {new}, arriva con l'aggiornamento del programma CamMixer (riquadro qui sopra) oppure da ",
  "Extension {current}: version {new} is out. Download it from ":
    "Estensione {current}: è uscita la {new}. Scaricala da ",
  "Extension {current}, up to date (last checked at {time}). Releases in ":
    "Estensione {current}, aggiornata (ultimo controllo alle {time}). Rilasci in ",
  "Extension {current}. CamMixer releases (extension and programs for Windows and macOS) are in ":
    "Estensione {current}. I rilasci di CamMixer (estensione e programmi per Windows e macOS) sono in ",
  "Updated.":
    "Aggiornati.",
  "Already up to date.":
    "Già aggiornati.",
  "Check failed.":
    "Controllo non riuscito.",
  "Delete":
    "Elimina",
  "Colour":
    "Colore",
  "{id} (not available)":
    "{id} (non disponibile)",
  "Animation":
    "Animazione",
  "No elements. Add a text, an emoji or an image: they appear over the video, animated too.":
    "Nessun elemento. Aggiungi un testo, un'emoji o un'immagine: compaiono sopra il video, anche animati.",
  "Cannot read the image.":
    "Impossibile leggere l'immagine.",
  "Reset “{name}” to the initial settings? Background, texts and elements will be removed.":
    "Riportare «{name}» alle impostazioni iniziali? Sfondo, testi ed elementi verranno tolti.",
  "Delete all virtual webcams and settings? The extension will start again from Webcam1, as if just installed.":
    "Cancellare tutte le webcam virtuali e le impostazioni? L'estensione ripartirà da Webcam1, come appena installata.",
  "Delete the virtual webcam “{name}”?":
    "Eliminare la webcam virtuale «{name}»?",
  "Untitled":
    "Senza nome",
  "<b>Real webcam</b> → <b>Adjustments</b> → <b>Cut-out and background</b> → <b>Mixing</b> → <b class=\"hl\">Virtual webcam in websites</b>":
    "<b>Webcam reale</b> → <b>Modifiche</b> → <b>Ritaglio e sfondo</b> → <b>Miscelazione</b> → <b class=\"hl\">Webcam virtuale nei siti</b>",
  "Virtual webcams":
    "Webcam virtuali",
  "+ New virtual webcam":
    "+ Nuova webcam virtuale",
  "Use it in websites instead of the real webcam":
    "Usala nei siti al posto della webcam reale",
  "Virtual webcam preview":
    "Anteprima della webcam virtuale",
  "Drag the lower third, texts, emoji and images to move them":
    "Trascina il sottopancia, i testi, le emoji e le immagini per spostarli",
  "Mirror":
    "Specchia",
  "Real webcam":
    "Webcam reale",
  "Source of the virtual webcam":
    "Sorgente della webcam virtuale",
  "Drag the lower third, texts, emoji and images on the preview to move them.":
    "Trascina sull'anteprima il sottopancia, i testi, le emoji e le immagini per spostarli.",
  "Background behind you":
    "Sfondo dietro di te",
  "Background":
    "Sfondo",
  "Remove":
    "Rimuovi",
  "If a halo of background stays around you, raise the sensitivity; if parts of you disappear (hair, shoulders), lower it.":
    "Se intorno a te resta un alone di sfondo, alza la sensibilità; se sparisce parte di te (capelli, spalle), abbassala.",
  "Real video adjustments":
    "Modifiche al video reale",
  "Mixing":
    "Miscelazione",
  "Overlay text":
    "Testo sovrapposto",
  "E.g. a name":
    "Es. un nome",
  "Date and time":
    "Data e ora",
  "Adjustments and effects go back to their initial values; background, texts and elements stay":
    "Modifiche ed effetti tornano ai valori iniziali; sfondo, testi ed elementi restano",
  "Reset effects":
    "Ripristina effetti",
  "This virtual webcam goes back to new: no background, texts or elements":
    "Questa webcam virtuale torna come nuova: senza sfondo, testi ed elementi",
  "Reset all":
    "Ripristina tutto",
  "Video effects":
    "Effetti sul video",
  "They apply to background and person; texts and elements stay sharp on top.":
    "Si applicano a sfondo e persona; testi ed elementi restano nitidi sopra.",
  "3D object on your face":
    "Oggetto 3D sul volto",
  "Overlay elements":
    "Elementi sovrapposti",
  "+ Text":
    "+ Testo",
  "+ Emoji":
    "+ Emoji",
  "+ Image…":
    "+ Immagine…",
  "Lower third (TV news style)":
    "Sottopancia (stile telegiornale)",
  "Style":
    "Stile",
  "Show the time":
    "Mostra l'ora",
  "Or drag it on the preview. The scrolling ticker stays at the bottom.":
    "Oppure trascinalo sull'anteprima. La striscia che scorre resta in basso.",
  "Sample texts":
    "Testi di esempio",
  "Initial position":
    "Posizione iniziale",
  "Styles are components: new ones show up here without restarting anything.":
    "Gli stili sono componenti: se ne arrivano di nuovi compaiono qui senza riavviare nulla.",
  "Webcam for Teams, Zoom and the other apps on the computer":
    "Webcam per Teams, Zoom e le altre app del computer",
  "Send a virtual webcam to the apps on the computer (Teams desktop, Zoom…)":
    "Invia una webcam virtuale alle app del computer (Teams per desktop, Zoom…)",
  "Virtual webcam to send":
    "Webcam virtuale da inviare",
  "Loading…":
    "Caricamento…",
  "Address for the OBS Browser source":
    "Indirizzo per la sorgente Browser di OBS",
  "Windows 11, only once: download and run <b>CamMixer-Setup.exe</b> from <a href=\"https://github.com/BBerry2020/cammixer-releases\" target=\"_blank\" rel=\"noopener\">cammixer-releases</a>. Then in Teams: <b>Settings › Devices › Camera › CamMixer</b>. The video comes from here, so Microsoft Edge must stay open; the real webcam turns on only while an app is using “CamMixer”. Updates show up above.":
    "Windows 11, una volta sola: scarica e avvia <b>CamMixer-Setup.exe</b> da <a href=\"https://github.com/BBerry2020/cammixer-releases\" target=\"_blank\" rel=\"noopener\">cammixer-releases</a>. Poi in Teams: <b>Impostazioni › Dispositivi › Fotocamera › CamMixer</b>. Il video parte da qui, quindi Microsoft Edge deve restare aperto; la webcam reale si accende solo mentre un'app usa «CamMixer». Gli aggiornamenti compaiono qui sopra.",
  "macOS, only once: in Terminal run <code>curl -fsSL https://raw.githubusercontent.com/BBerry2020/cammixer-releases/main/installa-mac.sh | bash</code>. Then in <a href=\"https://obsproject.com\" target=\"_blank\" rel=\"noopener\">OBS Studio</a> add a <b>Browser</b> source with the address above (1280×720, fit to screen) and press <b>Start Virtual Camera</b>; in Teams choose <b>OBS Virtual Camera</b>. The browser must stay open; the macOS program updates itself.":
    "macOS, una volta sola: nel Terminale esegui <code>curl -fsSL https://raw.githubusercontent.com/BBerry2020/cammixer-releases/main/installa-mac.sh | bash</code>. Poi in <a href=\"https://obsproject.com\" target=\"_blank\" rel=\"noopener\">OBS Studio</a> aggiungi una sorgente <b>Browser</b> con l'indirizzo qui sopra (1280×720, adattata allo schermo) e premi <b>Avvia fotocamera virtuale</b>; in Teams scegli <b>OBS Virtual Camera</b>. Il browser deve restare aperto; il programma per macOS si aggiorna da solo.",
  "3D examples (experimental)":
    "Esempi 3D (sperimentali)",
  "Turn on the 3D examples (Three.js)":
    "Attiva gli esempi 3D (Three.js)",
  "Adds the <b>3D TV studio</b> and <b>3D crystals</b> backgrounds; the <b>Glow</b>, <b>CRT monitor</b> and <b>Chromatic aberration</b> effects (computed by the graphics card), <b>3D glasses</b>, <b>3D crown</b> and <b>3D robot avatar</b> (they follow your face), and the <b>Rotating 3D logo</b> (it shows your text or an image). You then choose them like the other backgrounds and effects. They use the graphics card: on a computer without graphics acceleration the video may slow down. The face effects download the MediaPipe face model (a few MB) the first time and keep it on the computer.":
    "Aggiunge agli sfondi <b>Studio TV 3D</b> e <b>Cristalli 3D</b>; agli effetti <b>Bagliore</b>, <b>Monitor CRT</b> e <b>Aberrazione cromatica</b> (calcolati dalla scheda video), <b>Occhiali 3D</b>, <b>Corona 3D</b> e <b>Avatar robot 3D</b> (seguono il volto), <b>Logo 3D rotante</b> (mostra un testo o un'immagine). Li scegli poi come gli altri sfondi ed effetti. Usano la scheda video: su un computer senza accelerazione grafica il video può rallentare. Gli effetti sul volto scaricano al primo uso il modello di MediaPipe per il volto (qualche MB) e restano sul computer.",
  "Version and components":
    "Versione e componenti",
  "CamMixer releases (extension and programs for Windows and macOS) are in <a href=\"https://github.com/BBerry2020/cammixer-releases\" target=\"_blank\" rel=\"noopener\">cammixer-releases</a>.":
    "I rilasci di CamMixer (estensione e programmi per Windows e macOS) sono in <a href=\"https://github.com/BBerry2020/cammixer-releases\" target=\"_blank\" rel=\"noopener\">cammixer-releases</a>.",
  "Check for updates":
    "Controlla aggiornamenti",
  "Animated backgrounds, effects and animations live in the <code>componenti/componenti.js</code> file in the extension folder. When that file changes, the extension reloads it by itself within a few seconds, also in open chats: no need for \"Reload\", and the settings stay.":
    "Sfondi animati, effetti e animazioni stanno nel file <code>componenti/componenti.js</code> della cartella dell'estensione. Quando quel file cambia, l'estensione lo ricarica da sola entro pochi secondi, anche nelle chat aperte: non serve \"Ricarica\" e le impostazioni restano.",
  "How to use it in a video chat":
    "Come usarla in una chat video",
  "Tick <b>Use it in websites instead of the real webcam</b> on the virtual webcam you want to show. From then on websites only see the virtual webcams and get the ticked one, even if they had remembered the real webcam.":
    "Spunta <b>Usala nei siti al posto della webcam reale</b> sulla webcam virtuale che vuoi mostrare. Da quel momento i siti vedono solo le webcam virtuali e ricevono quella spuntata, anche se si erano memorizzati la webcam reale.",
  "Open the chat website and allow camera access as usual. On websites that let you choose the camera, the virtual webcams appear in the list with their name. The Edge or Chrome camera menu (icon in the address bar) only shows the real webcams: no need to touch it.":
    "Apri il sito della chat e consenti l'accesso alla fotocamera come al solito. Nei siti che fanno scegliere la fotocamera, le webcam virtuali compaiono nell'elenco con il loro nome. Il menu della fotocamera di Edge o Chrome (icona nella barra degli indirizzi) mostra solo le webcam reali: non serve toccarlo.",
  "During the chat, at the bottom right you find a panel to change background and effects on the fly (it can be collapsed and moved).":
    "Durante la chat, in basso a destra trovi un pannello per cambiare sfondo ed effetti al volo (si può ridurre e spostare).",
  "If the website was already open when you installed or updated the extension, reload it.":
    "Se il sito era già aperto quando hai installato o aggiornato l'estensione, ricaricalo.",
  "To use the real webcam again, untick it: the extension becomes invisible to websites.":
    "Per usare di nuovo la webcam reale, togli la spunta: l'estensione diventa invisibile ai siti.",
  "Reset the extension…":
    "Ripristina l'estensione…",
  "Deletes all virtual webcams and settings and starts again from Webcam1, as if just installed.":
    "Cancella tutte le webcam virtuali e le impostazioni e riparte da Webcam1, come appena installata.",
  "English":
    "English",
  "Italiano":
    "Italiano",
  "Language · Lingua":
    "Language · Lingua",
  "error":
    "errore",
  "extension reloaded: reload the page":
    "estensione ricaricata: ricarica la pagina",
  "Collapse":
    "Riduci",
  "Lower third":
    "Sottopancia",
  "Lower third height":
    "Altezza sottopancia",
  "Bring adjustments and effects back to their initial values (background, texts and elements stay)":
    "Riporta modifiche ed effetti ai valori iniziali (sfondo, testi ed elementi restano)",
  "All settings…":
    "Tutte le impostazioni…",
  "Virtual webcam: {name}":
    "Webcam virtuale: {name}",
  "Extension updated: reload the page to use what is new (the video keeps going).":
    "Estensione aggiornata: ricarica la pagina per usare le novità (il video continua).",
  "Loading the cut-out…":
    "Caricamento del ritaglio…",
  "Component turned off because of an error: {error}":
    "Componente disattivato per un errore: {error}",
  "Your image (upload it in the settings)":
    "Immagine tua (caricala nelle impostazioni)",
  "components not readable (HTTP {status})":
    "componenti non leggibili (HTTP {status})",
  "model download failed: Internet is needed the first time":
    "download del modello non riuscito: serve Internet al primo uso",
  "model download failed (HTTP {status})":
    "download del modello non riuscito (HTTP {status})",
  "MediaPipe loader not available":
    "caricatore di MediaPipe non disponibile",
  "extension not reachable":
    "estensione non raggiungibile",
  "model not received":
    "modello non ricevuto",
  "MediaPipe loader not received":
    "caricatore di MediaPipe non ricevuto",
  "no answer":
    "nessuna risposta",
  "Hello!":
    "Ciao!",
  "Screenshot not available":
    "Foto non disponibile",
  "A recording is already running.":
    "È già in corso una registrazione.",
  "This browser cannot record video.":
    "Questo browser non sa registrare video.",
  "Recording failed.":
    "Registrazione non riuscita.",
  "Small file (1.5 Mbit/s)":
    "File piccolo (1,5 Mbit/s)",
  "Standard (4 Mbit/s)":
    "Normale (4 Mbit/s)",
  "High (8 Mbit/s)":
    "Alta (8 Mbit/s)",
  "Recording and screenshots":
    "Registrazione e foto",
  "Video format":
    "Formato del video",
  "Quality":
    "Qualità",
  "Record the microphone too":
    "Registra anche il microfono",
  "The <b>Record</b> and <b>Screenshot</b> buttons are next to the preview, and in the panel inside websites during a chat. They save what the virtual webcam sends, as the others see it (not mirrored): videos in MP4 or WebM, screenshots in PNG at full resolution, in the browser's downloads folder. A recording lasts at most 60 minutes.":
    "I pulsanti <b>Registra</b> e <b>Foto</b> sono accanto all'anteprima, e nel pannello dentro i siti durante una chat. Salvano quello che manda la webcam virtuale, come lo vedono gli altri (non specchiato): video in MP4 o WebM, foto in PNG a piena risoluzione, nella cartella dei download del browser. Una registrazione dura al massimo 60 minuti.",
  "This browser cannot record video: only screenshots are available.":
    "Questo browser non sa registrare video: sono disponibili solo le foto.",
  "Saved {file} ({time}, {size}) in the downloads folder.":
    "Salvato {file} ({time}, {size}) nella cartella dei download.",
  "The recording stopped at the limit (60 minutes or 1.5 GB).":
    "La registrazione si è fermata al limite (60 minuti o 1,5 GB).",
  "This browser cannot record sound in this format: the video has no audio.":
    "Questo browser non sa registrare l'audio in questo formato: il video è senza sonoro.",
  "The recording ended with an error: {error}":
    "La registrazione è finita con un errore: {error}",
  "Recording failed: {error}":
    "Registrazione non riuscita: {error}",
  "Stop recording":
    "Ferma la registrazione",
  "Record":
    "Registra",
  "Records what the virtual webcam sends, as a compressed video":
    "Registra quello che manda la webcam virtuale, in un video compresso",
  "Screenshot":
    "Foto",
  "Saves the current frame as a PNG image":
    "Salva il fotogramma attuale come immagine PNG",
  "Recording {name}: {time}, {size} ({format}{audio}).":
    "Registrazione di {name}: {time}, {size} ({format}{audio}).",
  ", with microphone":
    ", con microfono",
  "Microphone not available ({error}): recording without sound.":
    "Microfono non disponibile ({error}): si registra senza sonoro.",
  "Cannot start the recording: {error}":
    "Impossibile avviare la registrazione: {error}",
  "Screenshot saved: {file}":
    "Foto salvata: {file}",
  "Screenshot not available: {error}":
    "Foto non disponibile: {error}",
  "The virtual webcam is not in use in this page.":
    "La webcam virtuale non è in uso in questa pagina.",
  "Stop · {time}":
    "Ferma · {time}",
  "Stop the recording and save it":
    "Ferma la registrazione e salvala",
  "Recording with microphone: {size}":
    "In registrazione con microfono: {size}",
  "Recording: {size}":
    "In registrazione: {size}"
});
