/* CamMixer - pagina delle impostazioni */
(() => {
  'use strict';
  const C = WebcamVirtualiCore;
  const L = CamMixerLingua;   // lingua dell'interfaccia (inglese o italiano)
  const T = L.T;
  const $ = (id) => document.getElementById(id);
  const md = navigator.mediaDevices;

  const vcams = [];
  let selected = null;
  let defaultId = null;
  let active = true;
  let lastSaved = '';
  let esempi3d = false;   // esempi 3D (Three.js) attivi
  let saveTimer = null;

  const env = {
    getUserMedia: (c) => md.getUserMedia(c),
    enumerateDevices: () => md.enumerateDevices(),
    onChange: (v) => {
      // la webcam virtuale registrata si è spenta (errore, webcam reale scollegata): il video si salva
      if (registratore.info.vcamId === v.id && (v.status === 'error' || v.status === 'idle')) registratore.ferma('fine');
      if (v === selected) { showSource(); showOutput(); listSources(); }
    }
  };

  // Ritaglio: libreria nell'estensione, modello dal service worker (scaricato una volta)
  C.setBase(chrome.runtime.getURL(''));
  C.setSegmentationProvider(async (nome = 'ritaglio') => {
    const vision = await import(chrome.runtime.getURL('mediapipe/vision_bundle.mjs'));
    const r = await chrome.runtime.sendMessage({ type: 'get-model', modello: nome });
    if (!r || !r.ok) throw new Error((r && r.error) || T('model not available'));
    const bin = atob(r.data);
    const model = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) model[i] = bin.charCodeAt(i);
    return { vision, wasmPath: chrome.runtime.getURL('mediapipe/wasm'), model };
  });
  C.onSegChange(() => updateSegStatus());

  // ---------------------------------------------------------------------
  // Salvataggio e sincronizzazione con il pannello nei siti
  // ---------------------------------------------------------------------

  const snapshot = () => ({
    vcams: vcams.map((v) => ({ id: v.id, name: v.name, source: v.source, fx: v.fx })),
    defaultId,
    esempi3d,
    lingua: L.attuale
  });

  function save(now = false) {
    clearTimeout(saveTimer);
    const run = () => {
      const s = snapshot();
      lastSaved = JSON.stringify(s);
      chrome.storage.local.set({ state: s }).catch(() => {});
    };
    if (now) run(); else saveTimer = setTimeout(run, 250);
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.state) return;
    if (JSON.stringify(changes.state.newValue) === lastSaved) return;   // è il nostro salvataggio
    const s = C.normalizeState(changes.state.newValue);
    if (s.lingua !== L.attuale) { location.reload(); return; }
    defaultId = s.defaultId;
    esempi3d = s.esempi3d;
    C.setEsempi3D(esempi3d);
    $('esempi3d').checked = esempi3d;
    const ids = new Set(s.vcams.map((c) => c.id));
    for (let i = vcams.length - 1; i >= 0; i--) {
      if (!ids.has(vcams[i].id)) {
        if (registratore.info.vcamId === vcams[i].id) registratore.ferma('fine');
        vcams[i].stop(false);
        vcams.splice(i, 1);
      }
    }
    for (const c of s.vcams) {
      const v = vcams.find((x) => x.id === c.id);
      if (v) v.update(c); else vcams.push(new C.VCam(c, env));
    }
    if (!vcams.includes(selected)) selected = vcams[0];
    renderTabs();
    syncEditor();
    refreshRunning();
  });

  // ---------------------------------------------------------------------
  // Webcam virtuali
  // ---------------------------------------------------------------------

  function refreshRunning() {
    for (const v of vcams) {
      if (active && v === selected) v.ensure().catch(() => {});
      else if (v.running) v.stop(true);
    }
  }

  function renderTabs() {
    $('tabs').replaceChildren(...vcams.map((v) => {
      const b = document.createElement('button');
      b.className = 'tab';
      b.setAttribute('role', 'tab');
      b.setAttribute('aria-selected', String(v === selected));
      b.textContent = v.name;
      if (v.id === defaultId) {
        const tag = document.createElement('span');
        tag.className = 'tag';
        tag.textContent = T('· in websites');
        b.append(tag);
      }
      if (v.source === C.NO_CAMERA) b.title = T('No camera');
      b.onclick = () => selectVcam(v);
      return b;
    }));
    $('camDelete').disabled = vcams.length < 2;
    renderWindows();
  }

  function syncEditor() {
    $('camName').value = selected.name;
    $('camDefault').checked = selected.id === defaultId;
    $('outTitle').textContent = T('Output · {name}', { name: selected.name });
    $('live').textContent = `LIVE · ${selected.name}`;
    const video = $('video');
    if (video.srcObject !== selected.outStream) { video.srcObject = selected.outStream; video.play().catch(() => {}); }
    syncControls();
    renderElements();
    renderNews();
    showSource();
    showOutput();
    listSources();
  }

  function selectVcam(v) {
    // si registra la webcam virtuale in anteprima: cambiandola, la registrazione si chiude e si salva
    if (registratore.attivo && registratore.info.vcamId !== v.id) registratore.ferma('cambio');
    selected = v;
    renderTabs();
    syncEditor();
    refreshRunning();
  }

  function nextName() {
    let n = vcams.length + 1;
    while (vcams.some((v) => v.name === `Webcam${n}`)) n++;
    return `Webcam${n}`;
  }

  // ---------------------------------------------------------------------
  // Anteprime
  // ---------------------------------------------------------------------

  const srcVideo = $('source');

  function showSource() {
    const v = selected, ov = $('src-overlay');
    if (v.source === C.NO_CAMERA) {
      srcVideo.srcObject = null;
      ov.textContent = T('No camera: this virtual webcam only shows background, animations and text.');
      ov.hidden = false;
    } else if (v.stream) {
      if (srcVideo.srcObject !== v.stream) { srcVideo.srcObject = v.stream; srcVideo.play().catch(() => {}); }
      ov.hidden = true;
    } else {
      srcVideo.srcObject = null;
      ov.textContent = v.status === 'error' ? v.error : (v.status === 'starting' ? T('Starting the real webcam…') : T('Real webcam not active'));
      ov.hidden = false;
    }
    if (!srcVideo.srcObject) $('src-res').textContent = '';
  }

  function showOutput() {
    const v = selected, ov = $('overlay');
    const live = active && v.status === 'live';
    $('live').hidden = !live;
    if (!active) { ov.textContent = T('Preview stopped.'); ov.hidden = false; }
    else if (v.status === 'error') { ov.textContent = v.error; ov.hidden = false; }
    else ov.hidden = true;
    $('toggle').textContent = active ? T('Stop') : T('Start');
    showRecording();
  }

  // ---------------------------------------------------------------------
  // Registrazione (video compresso) e foto di quello che manda la webcam virtuale
  // ---------------------------------------------------------------------

  const R = C.registrazione;
  let sceltaReg = R.normalizza(null);
  let recMsg = '', recErr = false, recAvvio = false;
  const registratore = new R.Registratore({
    onChange: () => showRecording(),
    onFile: (f) => {
      scarica(f);
      const parti = [T('Saved {file} ({time}, {size}) in the downloads folder.', { file: f.nome, time: R.durata(f.durata), size: R.byte(f.byte) })];
      if (f.motivo === 'limite') parti.push(T('The recording stopped at the limit (60 minutes or 1.5 GB).'));
      if (f.senzaAudio) parti.push(T('This browser cannot record sound in this format: the video has no audio.'));
      if (f.errore) parti.push(T('The recording ended with an error: {error}', { error: f.errore.message || f.errore.name || f.errore }));
      setRecMsg(parti.join(' '), !!f.errore);
    },
    onError: (e) => setRecMsg(T('Recording failed: {error}', { error: (e && (e.message || e.name)) || e }), true)
  });

  function setRecMsg(testo, errore = false) {
    recMsg = testo;
    recErr = errore;
    showRecording();
  }

  // Il file va nella cartella dei download del browser (Edge o Chrome chiedono dove salvarlo, se impostati così)
  function scarica(f) {
    const url = URL.createObjectURL(f.blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = f.nome;
    document.body.append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  }

  function showRecording() {
    if (!selected) return;
    const i = registratore.info, btn = $('recBtn');
    const pronta = active && selected.status === 'live';
    btn.classList.toggle('on', i.attivo);
    btn.textContent = i.attivo ? T('Stop recording') : T('Record');
    btn.title = i.attivo ? '' : T('Records what the virtual webcam sends, as a compressed video');
    btn.disabled = recAvvio || (!i.attivo && (!pronta || !R.formati().length));
    $('shotBtn').textContent = T('Screenshot');
    $('shotBtn').title = T('Saves the current frame as a PNG image');
    $('shotBtn').disabled = !pronta;
    $('recBadge').hidden = !i.attivo;
    const st = $('recStatus');
    if (i.attivo) {
      $('recBadge').textContent = `REC ${R.durata(i.durata)}`;
      st.textContent = T('Recording {name}: {time}, {size} ({format}{audio}).', {
        name: i.nome, time: R.durata(i.durata), size: R.byte(i.byte), format: i.formato.toUpperCase(), audio: i.audio ? T(', with microphone') : ''
      });
      st.classList.remove('danger');
    } else {
      st.textContent = recMsg;
      st.classList.toggle('danger', recErr);
    }
    st.hidden = !st.textContent;
  }

  async function toggleRecording() {
    if (registratore.attivo) { registratore.ferma(); return; }
    const v = selected;
    recAvvio = true;
    setRecMsg('');
    let audio = null, avviso = '';
    if (sceltaReg.audio) {
      try {
        audio = await md.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } });
      } catch (e) {
        avviso = T('Microphone not available ({error}): recording without sound.', { error: e.message || e.name });
      }
    }
    recAvvio = false;
    if (v !== selected || !active) { if (audio) audio.getTracks().forEach((t) => t.stop()); showRecording(); return; }
    try {
      registratore.avvia(v, sceltaReg, audio);
      setRecMsg(avviso, !!avviso);
    } catch (e) {
      setRecMsg(T('Cannot start the recording: {error}', { error: e.message || e.name }), true);
    }
  }

  async function screenshot() {
    try {
      const f = await R.foto(selected);
      scarica(f);
      const frame = $('video').closest('.frame');
      frame.classList.remove('flash');
      void frame.offsetWidth;   // l'animazione riparte anche a scatti ravvicinati
      frame.classList.add('flash');
      if (!registratore.attivo) setRecMsg(T('Screenshot saved: {file}', { file: f.nome }));
    } catch (e) {
      setRecMsg(T('Screenshot not available: {error}', { error: e.message || e.name }), true);
    }
  }

  async function buildRecording() {
    try { sceltaReg = R.normalizza((await chrome.storage.local.get('registrazione')).registrazione); } catch { /* ignora */ }
    const formati = R.formati();
    $('recFormat').replaceChildren(...formati.map((f) => new Option(f.label, f.id)));
    $('recFormat').disabled = !formati.length;
    $('recNoFormat').hidden = formati.length > 0;
    $('recQuality').replaceChildren(...R.QUALITA.map((q) => new Option(T(q.label), q.id)));
    $('recFormat').value = sceltaReg.formato;
    $('recQuality').value = sceltaReg.qualita;
    $('recAudio').checked = sceltaReg.audio;
    const salvaScelta = () => {
      sceltaReg = R.normalizza({ formato: $('recFormat').value, qualita: $('recQuality').value, audio: $('recAudio').checked });
      chrome.storage.local.set({ registrazione: sceltaReg }).catch(() => {});
    };
    for (const id of ['recFormat', 'recQuality', 'recAudio']) $(id).addEventListener('change', salvaScelta);
    $('recBtn').onclick = () => { toggleRecording(); };
    $('shotBtn').onclick = () => { screenshot(); };
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area !== 'local' || !changes.registrazione) return;
      sceltaReg = R.normalizza(changes.registrazione.newValue);
      $('recFormat').value = sceltaReg.formato;
      $('recQuality').value = sceltaReg.qualita;
      $('recAudio').checked = sceltaReg.audio;
    });
    showRecording();
  }

  const fmtRes = (el) => (el.videoWidth ? `${el.videoWidth}×${el.videoHeight}` : '');
  srcVideo.addEventListener('resize', () => { $('src-res').textContent = fmtRes(srcVideo); });
  $('video').addEventListener('resize', () => { $('res').textContent = fmtRes($('video')); });

  async function listSources() {
    const sel = $('sourceCam');
    let cams = [];
    try { cams = (await md.enumerateDevices()).filter((d) => d.kind === 'videoinput' && !C.isVirtualLabel(d.label)); } catch { /* ignora */ }
    const opts = [new Option(T('No camera (background and text only)'), C.NO_CAMERA)];
    cams.forEach((c, i) => opts.push(new Option(c.label || `Webcam ${i + 1}`, c.label || '')));
    sel.replaceChildren(...opts);
    const used = selected.stream && selected.stream.getVideoTracks()[0];
    sel.value = selected.source === C.NO_CAMERA ? C.NO_CAMERA : (selected.source || (used ? used.label : '') || (cams[0] ? cams[0].label : ''));
  }

  // ---------------------------------------------------------------------
  // Controlli
  // ---------------------------------------------------------------------

  function fmt(s, v) { return s.off !== undefined && v === s.off ? 'no' : `${v}${s.unit}`; }

  function buildSlider(container, s) {
    const wrap = document.createElement('div');
    wrap.className = 'slider';
    wrap.id = `fx-${s.id}-box`;
    if (s.hint) wrap.title = T(s.hint);
    const head = document.createElement('label');
    head.className = 'slider-head';
    head.htmlFor = `fx-${s.id}`;
    const name = document.createElement('span');
    name.textContent = T(s.label);
    const out = document.createElement('output');
    out.id = `fx-${s.id}-out`;
    head.append(name, out);
    const input = document.createElement('input');
    input.type = 'range';
    input.id = `fx-${s.id}`;
    input.min = s.min;
    input.max = s.max;
    input.addEventListener('input', () => {
      selected.fx[s.id] = Number(input.value);
      out.textContent = fmt(s, selected.fx[s.id]);
      save();
    });
    wrap.append(head, input);
    container.append(wrap);
  }

  function syncControls() {
    const fx = selected.fx;
    for (const s of C.SLIDERS) { $(`fx-${s.id}`).value = fx[s.id]; $(`fx-${s.id}-out`).textContent = fmt(s, fx[s.id]); }
    for (const t of C.TOGGLES) $(`fx-${t.id}`).checked = fx[t.id];
    $('text').value = fx.text;
    $('clock').checked = fx.clock;
    $('bgColor').value = fx.bgColor;
    syncBackground();
    renderEffects();
  }

  function syncBackground() {
    const fx = selected.fx, noCam = selected.source === C.NO_CAMERA;
    const list = C.catalog().backgrounds;
    const bgs = list.some((b) => b.id === fx.bg) ? list : [...list, { id: fx.bg, label: T('{id} (component not available)', { id: fx.bg }) }];
    $('bgType').replaceChildren(...bgs.map((b) => {
      const o = new Option(T(b.label), b.id);
      if (b.id === 'media' && noCam) { o.disabled = true; o.textContent = T('Your image (needs the camera)'); }
      return o;
    }));
    $('bgType').value = fx.bg;
    $('bgColorRow').hidden = fx.bg !== 'color';
    $('fx-bgBlur-box').hidden = fx.bg !== 'blur';
    $('bgImageRow').hidden = fx.bg !== 'media';
    $('bgPick').textContent = fx.bgImage ? T('Change image…') : T('Choose an image…');
    $('bgClear').hidden = !fx.bgImage;
    $('segBox').hidden = fx.bg === 'none' || noCam;   // regolazioni del ritaglio: solo se serve
    $('adjust').parentElement.style.opacity = noCam ? '0.5' : '';
    updateSegStatus();
  }

  function updateSegStatus() {
    const el = $('segStatus');
    let text = C.segStatusText(selected);
    if (selected.fx.bg === 'media' && !selected.fx.bgImage) text = T('Choose an image to put behind you.');
    el.textContent = text;
  }

  // Immagine di sfondo: ridotta a 1280×720 al massimo e salvata nell'estensione
  async function loadImage(file) {
    const bmp = await createImageBitmap(file);
    const s = Math.min(1, 1280 / bmp.width, 720 / bmp.height);
    const c = document.createElement('canvas');
    c.width = Math.round(bmp.width * s);
    c.height = Math.round(bmp.height * s);
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    bmp.close();
    return c.toDataURL('image/jpeg', 0.85);
  }

  // ---------------------------------------------------------------------
  // Effetti dei componenti (cursori 0-100, valori in fx.effects)
  // ---------------------------------------------------------------------

  let effectsSig = '';
  // Effetti: un cursore per effetto; gli oggetti 3D sul volto (effetti «volto») hanno un comando
  // unico (Nessuno / Occhiali / Corona / Robot) con una sola dimensione; il «Logo 3D rotante» ha
  // anche testo e immagine.
  let faceSize = 50;

  function renderEffects() {
    const all = C.catalog().effects;
    const list = all.filter((e) => !e.volto);
    const volto = all.filter((e) => e.volto);
    const sig = all.map((e) => `${e.id}=${e.label}=${e.volto ? 1 : 0}`).join('|');
    const box = $('effects');
    if (sig !== effectsSig) {
      effectsSig = sig;
      box.replaceChildren(...list.map((e) => {
        const wrap = document.createElement('div');
        wrap.className = 'slider';
        const head = document.createElement('label');
        head.className = 'slider-head';
        head.htmlFor = `ef-${e.id}`;
        const name = document.createElement('span');
        name.textContent = T(e.label);
        const out = document.createElement('output');
        out.id = `ef-${e.id}-out`;
        head.append(name, out);
        const input = document.createElement('input');
        input.type = 'range';
        input.id = `ef-${e.id}`;
        input.min = 0;
        input.max = 100;
        input.addEventListener('input', () => {
          const v = Number(input.value);
          if (v > 0) selected.fx.effects[e.id] = v; else delete selected.fx.effects[e.id];
          out.textContent = `${v}%`;
          save();
          if (e.id === 'logo-3d') renderEffects();
        });
        wrap.append(head, input);
        if (e.id === 'logo-3d') wrap.append(logoOptions());
        return wrap;
      }));
      if (!list.length) {
        const p = document.createElement('p');
        p.className = 'hint';
        p.textContent = T('No effects available in the components.');
        box.replaceChildren(p);
      }
      // comando unico degli oggetti sul volto
      $('faceBox').hidden = !volto.length;
      $('faceChoices').replaceChildren(...[{ id: '', breve: 'None' }, ...volto].map((e) => {
        const b = document.createElement('button');
        b.type = 'button';
        b.setAttribute('role', 'radio');
        b.dataset.id = e.id;
        b.textContent = T(e.breve || e.label);
        b.addEventListener('click', () => {
          for (const f of volto) delete selected.fx.effects[f.id];
          if (e.id) selected.fx.effects[e.id] = Math.max(1, faceSize);
          save();
          renderEffects();
        });
        return b;
      }));
    }
    for (const e of list) {
      const v = Number(selected.fx.effects[e.id]) || 0;
      const input = $(`ef-${e.id}`);
      if (input && document.activeElement !== input) input.value = v;
      if ($(`ef-${e.id}-out`)) $(`ef-${e.id}-out`).textContent = `${v}%`;
    }
    // logo: campi visibili solo con l'effetto attivo
    if ($('logoOpts')) {
      const lg = selected.fx.logo || { testo: '', immagine: '' };
      $('logoOpts').hidden = !((Number(selected.fx.effects['logo-3d']) || 0) > 0);
      if (document.activeElement !== $('logoText')) $('logoText').value = lg.testo || '';
      $('logoText').placeholder = T('Logo text (empty: {text})', { text: selected.fx.text || selected.name });
      $('logoThumb').hidden = !lg.immagine;
      if (lg.immagine && $('logoThumb').src !== lg.immagine) $('logoThumb').src = lg.immagine;
      $('logoClear').hidden = !lg.immagine;
      const rot = Number(lg.rotazione) || 0;
      if (document.activeElement !== $('logoRot')) $('logoRot').value = rot;
      $('logoRotOut').textContent = `${rot}°`;
    }
    // oggetto sul volto scelto e sua dimensione
    const scelto = volto.find((e) => (Number(selected.fx.effects[e.id]) || 0) > 0);
    if (scelto) faceSize = Number(selected.fx.effects[scelto.id]);
    for (const b of $('faceChoices').children) b.setAttribute('aria-checked', String(b.dataset.id === (scelto ? scelto.id : '')));
    $('faceSizeBox').hidden = !scelto;
    if (document.activeElement !== $('faceSize')) $('faceSize').value = faceSize;
    $('faceSizeOut').textContent = `${faceSize}%`;
    const fs = C.face;
    $('faceStatus').textContent = !scelto ? T('Choose an object: it follows your face and copies its movements.')
      : fs.state === 'ready' ? T('Face tracking active.')
        : fs.state === 'error' ? T('Face tracking not available: {error}', { error: fs.error })
          : T('Loading face tracking (the first time it downloads the model)…');
  }

  // Campi del «Logo 3D rotante»: testo libero o immagine
  function logoOptions() {
    const box = document.createElement('div');
    box.className = 'logo-opts';
    box.id = 'logoOpts';
    const testo = document.createElement('input');
    testo.type = 'text';
    testo.id = 'logoText';
    testo.maxLength = 24;
    testo.addEventListener('input', () => {
      selected.fx.logo = { ...(selected.fx.logo || {}), testo: testo.value.slice(0, 24) };
      save();
    });
    const riga = document.createElement('div');
    riga.className = 'row';
    const scegli = document.createElement('button');
    scegli.type = 'button';
    scegli.textContent = T('Use an image…');
    const togli = document.createElement('button');
    togli.type = 'button';
    togli.id = 'logoClear';
    togli.textContent = T('Remove the image');
    const img = document.createElement('img');
    img.id = 'logoThumb';
    img.alt = T('Logo image');
    const file = document.createElement('input');
    file.type = 'file';
    file.accept = 'image/png,image/jpeg,image/webp,image/gif';
    file.hidden = true;
    scegli.addEventListener('click', () => file.click());
    file.addEventListener('change', async () => {
      const f = file.files && file.files[0];
      file.value = '';
      if (!f) return;
      try {
        const url = await loadElementImage(f);
        selected.fx.logo = { ...(selected.fx.logo || {}), immagine: url };
        save(true);
        renderEffects();
      } catch { /* immagine non leggibile */ }
    });
    togli.addEventListener('click', () => {
      selected.fx.logo = { ...(selected.fx.logo || {}), immagine: '' };
      save(true);
      renderEffects();
    });
    // rotazione del contenuto (per raddrizzare un'immagine o il testo dentro la moneta)
    const giro = document.createElement('div');
    giro.className = 'slider';
    giro.title = T('Turns the image or text on the logo to straighten it');
    const giroTesta = document.createElement('label');
    giroTesta.className = 'slider-head';
    giroTesta.htmlFor = 'logoRot';
    const giroNome = document.createElement('span');
    giroNome.textContent = T('Rotation');
    const giroOut = document.createElement('output');
    giroOut.id = 'logoRotOut';
    giroTesta.append(giroNome, giroOut);
    const giroInput = document.createElement('input');
    giroInput.type = 'range';
    giroInput.id = 'logoRot';
    giroInput.min = -180;
    giroInput.max = 180;
    giroInput.step = 1;
    giroInput.addEventListener('input', () => {
      const v = Number(giroInput.value);
      selected.fx.logo = { ...(selected.fx.logo || {}), rotazione: v };
      giroOut.textContent = `${v}°`;
      save();
    });
    // doppio clic: torna dritto
    giroInput.addEventListener('dblclick', () => { giroInput.value = 0; giroInput.dispatchEvent(new Event('input')); });
    giro.append(giroTesta, giroInput);
    const nota = document.createElement('p');
    nota.className = 'hint';
    nota.textContent = T('With an image the logo shows it; otherwise the text.');
    riga.append(scegli, togli, img, file);
    box.append(testo, riga, giro, nota);
    return box;
  }


  // ---------------------------------------------------------------------
  // Sottopancia (stile telegiornale)
  // ---------------------------------------------------------------------

  // testi di esempio nella lingua scelta
  const NEWS_EXAMPLE = () => ({
    label: T('BREAKING NEWS'), name: T('First Last'), role: T('Special correspondent'),
    headline: T('The headline of the main story'),
    ticker: T('First story of the day | Second story | The weather forecast for tomorrow')
  });

  function buildNewsFields() {
    $('newsFields').replaceChildren(...C.NEWS_FIELDS.map((f) => {
      const label = document.createElement('label');
      label.className = f.id === 'headline' || f.id === 'ticker' ? 'field wide' : 'field';
      const input = document.createElement('input');
      input.type = 'text';
      input.id = `news-${f.id}`;
      input.maxLength = f.max;
      input.placeholder = T(f.placeholder);
      input.addEventListener('input', () => { selected.fx.news[f.id] = input.value; save(); });
      label.append(T(f.label), input);
      return label;
    }));
    $('newsStyle').addEventListener('change', (e) => {
      const n = selected.fx.news;
      n.style = e.target.value;
      // primo utilizzo: testi di esempio, da sostituire con i propri
      if (n.style && !n.name && !n.role && !n.headline && !n.ticker) Object.assign(n, NEWS_EXAMPLE());
      renderNews();
      save();
    });
    $('newsClock').addEventListener('change', (e) => { selected.fx.news.clock = e.target.checked; save(); });
    $('newsPos').replaceChildren(...C.NEWS_POSITION.map((p) => {
      const wrap = document.createElement('div');
      wrap.className = 'slider';
      const head = document.createElement('label');
      head.className = 'slider-head';
      head.htmlFor = `news-${p.id}`;
      const name = document.createElement('span');
      name.textContent = T(p.label);
      const out = document.createElement('output');
      out.id = `news-${p.id}-out`;
      head.append(name, out);
      const input = document.createElement('input');
      input.type = 'range';
      input.id = `news-${p.id}`;
      input.min = p.min;
      input.max = p.max;
      input.addEventListener('input', () => { selected.fx.news[p.id] = Number(input.value); out.textContent = `${input.value}${p.unit}`; save(); });
      wrap.append(head, input);
      return wrap;
    }));
    $('newsPosReset').onclick = () => {
      for (const p of C.NEWS_POSITION) selected.fx.news[p.id] = p.value;
      renderNews();
      save();
    };
    $('newsExample').onclick = () => { Object.assign(selected.fx.news, NEWS_EXAMPLE()); renderNews(); save(); };
  }

  function renderNews() {
    const n = selected.fx.news;
    const styles = C.catalog().lowerThirds;
    const opts = [{ id: '', label: 'None' }, ...styles];
    if (n.style && !styles.some((x) => x.id === n.style)) opts.push({ id: n.style, label: T('{id} (component not available)', { id: n.style }) });
    $('newsStyle').replaceChildren(...opts.map((x) => new Option(T(x.label), x.id)));
    $('newsStyle').value = n.style;
    $('newsClock').checked = n.clock;
    for (const f of C.NEWS_FIELDS) {
      const input = $(`news-${f.id}`);
      if (document.activeElement !== input) input.value = n[f.id];
    }
    for (const p of C.NEWS_POSITION) {
      const input = $(`news-${p.id}`);
      if (document.activeElement !== input) input.value = n[p.id];
      $(`news-${p.id}-out`).textContent = `${n[p.id]}${p.unit}`;
    }
    $('newsPosBox').hidden = !n.style;
    $('newsPosReset').hidden = !n.style;
  }

  // ---------------------------------------------------------------------
  // Trascinamento sull'anteprima: sottopancia ed elementi
  // ---------------------------------------------------------------------

  function canvasPoint(e) {
    const v = $('video'), hit = selected.hit;
    if (!hit || !hit.W) return null;
    const rect = v.getBoundingClientRect();
    const sc = Math.min(rect.width / hit.W, rect.height / hit.H);
    const ox = rect.left + (rect.width - hit.W * sc) / 2, oy = rect.top + (rect.height - hit.H * sc) / 2;
    let x = (e.clientX - ox) / sc;
    const y = (e.clientY - oy) / sc;
    if ($('mirror').checked) x = hit.W - x;
    return { x, y, W: hit.W, H: hit.H };
  }

  function findTarget(p) {
    const hit = selected.hit;
    const inside = (b) => b && p.x >= b.x && p.x <= b.x + b.w && p.y >= b.y && p.y <= b.y + b.h;
    for (let i = hit.elements.length - 1; i >= 0; i--) {   // gli elementi sono sopra al sottopancia
      const b = hit.elements[i];
      const el = selected.fx.elements.find((x) => x.id === b.id);
      if (el && inside(b)) return { kind: 'element', obj: el, limits: { x: [0, 100], y: [0, 100] } };
    }
    if (selected.fx.news.style && inside(hit.news)) {
      const lim = Object.fromEntries(C.NEWS_POSITION.map((q) => [q.id, [q.min, q.max]]));
      return { kind: 'news', obj: selected.fx.news, limits: lim };
    }
    return null;
  }

  let drag = null;
  const layer = $('dragLayer');
  const clamp = (v, [a, b]) => Math.min(b, Math.max(a, v));
  layer.addEventListener('pointerdown', (e) => {
    const p = canvasPoint(e);
    const target = p && findTarget(p);
    if (!target) return;
    drag = { ...target, p0: p, x0: target.obj.x, y0: target.obj.y, mirror: $('mirror').checked };
    layer.setPointerCapture(e.pointerId);
    layer.classList.add('dragging');
    e.preventDefault();
  });
  layer.addEventListener('pointermove', (e) => {
    const p = canvasPoint(e);
    if (!drag) {
      layer.classList.toggle('can', !!(p && findTarget(p)));
      return;
    }
    if (!p) return;
    const dx = ((p.x - drag.p0.x) / p.W) * 100, dy = ((p.y - drag.p0.y) / p.H) * 100;
    drag.obj.x = Math.round(clamp(drag.x0 + dx, drag.limits.x) * 10) / 10;
    drag.obj.y = Math.round(clamp(drag.y0 + dy, drag.limits.y) * 10) / 10;
    save();
  });
  const endDrag = () => {
    if (!drag) return;
    const kind = drag.kind;
    drag = null;
    layer.classList.remove('dragging');
    if (kind === 'element') renderElements(); else renderNews();
    save(true);
  };
  layer.addEventListener('pointerup', endDrag);
  layer.addEventListener('pointercancel', endDrag);

  // ---------------------------------------------------------------------
  // Webcam di Windows (Teams, Zoom...): la invia un documento nascosto
  // dell'estensione al programma ponte; qui si sceglie quale e se ne vede lo stato.
  // ---------------------------------------------------------------------

  let winSettings = { attiva: true, webcam: '' };
  let winStatus = null;

  function renderWindows() {
    const sel = $('winCam');
    const def = vcams.find((v) => v.id === defaultId);
    const choices = [['', def ? T('The one used in websites ({name})', { name: def.name }) : T('The one used in websites')], ...vcams.map((v) => [v.id, v.name])];
    sel.replaceChildren(...choices.map(([value, text]) => {
      const o = document.createElement('option');
      o.value = value;
      o.textContent = text;
      return o;
    }));
    sel.value = vcams.some((v) => v.id === winSettings.webcam) ? winSettings.webcam : '';
    sel.disabled = !winSettings.attiva;
    $('winOn').checked = winSettings.attiva;
    showWindowsStatus();
  }

  const macLocale = /mac/i.test((navigator.userAgentData && navigator.userAgentData.platform) || navigator.platform || '');

  function showWindowsStatus() {
    const st = winStatus;
    const mac = st && st.piattaforma ? st.piattaforma === 'macos' : macLocale;
    const prog = mac ? 'macOS' : 'Windows';
    const v = { system: prog, version: st && st.versionePonte, webcam: st && (st.webcam || '…'), error: st && (st.errore || st.erroreCamera),
      width: st && st.larghezza, height: st && st.altezza, fps: st && st.fps };
    let text, bad = false;
    if (!winSettings.attiva) text = mac ? T('Off.') : T('Off: the Windows “CamMixer” webcam shows a message instead of the video.');
    else if (!st) text = T('Connecting to the CamMixer program for {system}…', v);
    else if (!st.collegato) {
      text = T('The CamMixer program for {system} is not reachable: install it (see below) or restart the computer.', v);
      bad = true;
    } else if (st.camera === 'errore') {
      text = T('The CamMixer program for {system} is running, but it could not create the webcam: {error}.', v);
      bad = true;
    } else if (st.consumatore && st.errore) {
      text = T('In use, but “{webcam}” does not start: {error}', v);
      bad = true;
    } else if (st.consumatore) {
      text = T('In use: sending “{webcam}” at {width}×{height}, {fps} frames per second.', v);
    } else if (mac) {
      text = T('Ready (CamMixer program for macOS {version}): in OBS add a Browser source with this address, then “Start Virtual Camera”. OBS is not reading it right now.', v);
    } else {
      text = T('Ready: the “CamMixer” webcam is available in Windows apps (program {version}). No app is using it.', v);
    }
    const el = $('winStatus');
    el.textContent = text;
    el.classList.toggle('danger', bad);
    $('winHelpWindows').hidden = mac;
    $('winHelpMac').hidden = !mac;

    // indirizzo per OBS (macOS)
    const obs = winSettings.attiva && st && st.collegato && st.indirizzoObs;
    $('winObsRow').hidden = !obs;
    if (obs && $('winObs').value !== st.indirizzoObs) $('winObs').value = st.indirizzoObs;

    // aggiornamento del programma
    // Windows: il programma non si aggiorna da solo; se in cammixer-releases c'è una versione più
    // recente di quella installata, qui c'è il collegamento alla pagina dei rilasci.
    if (!mac) {
      const nuovo = winSettings.attiva && st && st.collegato && st.versionePonte && rilascio && rilascio.windows &&
        confronta(rilascio.windows.versione, st.versionePonte) > 0;
      $('winUpdateRow').hidden = !nuovo;
      if (nuovo) {
        $('winUpdate').disabled = false;
        $('winUpdate').textContent = T('Open the releases page');
        $('winUpdateText').textContent = T('CamMixer {new} for Windows is out (you have {old}): download the installer from the releases page and run it (Windows asks for administrator permission).',
          { new: rilascio.windows.versione, old: st.versionePonte });
      }
      return;
    }
    const agg = winSettings.attiva && st && st.collegato && st.aggiornamento;
    $('winUpdateRow').hidden = !agg;
    if (agg) {
      const s = st.statoAggiornamento || 'disponibile';
      const b = $('winUpdate');
      let t;
      b.disabled = s === 'scaricamento' || s === 'installazione';
      const v = { version: st.aggiornamento, error: s.replace(/^errore:\s*/, '') };
      b.textContent = s.startsWith('errore') ? T('Retry') : T('Install now');
      if (s === 'scaricamento') t = T('Downloading version {version}…', v);
      else if (s === 'installazione') t = T('Installing version {version}…', v);
      else if (s.startsWith('errore')) t = T('Update to version {version} failed ({error}).', v);
      else t = T('Version {version} available: it installs itself as soon as OBS is not using the stream.', v);
      $('winUpdateText').textContent = t;
    }
  }

  $('winUpdate').addEventListener('click', () => {
    const mac = winStatus && winStatus.piattaforma === 'macos';
    if (mac) chrome.runtime.sendMessage({ type: 'windows-comando', comando: 'aggiorna' }).catch(() => {});
    else window.open((rilascio && rilascio.pagina) || 'https://github.com/BBerry2020/cammixer-releases', '_blank', 'noopener');
  });

  function confronta(a, b) {
    const x = String(a).split('.').map((n) => parseInt(n, 10) || 0), y = String(b).split('.').map((n) => parseInt(n, 10) || 0);
    for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0) ? 1 : -1;
    return 0;
  }
  $('winObsCopy').addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText($('winObs').value);
      $('winObsCopy').textContent = T('Copied');
      setTimeout(() => { $('winObsCopy').textContent = T('Copy'); }, 1500);
    } catch {
      $('winObs').select();
    }
  });

  function saveWindows() {
    chrome.storage.local.set({ windows: { ...winSettings } }).catch(() => {});
  }

  $('winOn').addEventListener('change', (e) => {
    winSettings.attiva = e.target.checked;
    if (!winSettings.attiva) winStatus = null;
    saveWindows();
    renderWindows();
  });
  $('winCam').addEventListener('change', (e) => {
    winSettings.webcam = e.target.value;
    saveWindows();
  });

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'session' && changes.windowsStato) {
      winStatus = changes.windowsStato.newValue || null;
      showWindowsStatus();
    }
    if (area === 'local' && changes.windows) {
      const w = changes.windows.newValue || {};
      winSettings = { attiva: w.attiva !== false, webcam: typeof w.webcam === 'string' ? w.webcam : '' };
      renderWindows();
    }
  });

  async function loadWindows() {
    try {
      const { windows } = await chrome.storage.local.get('windows');
      if (windows) winSettings = { attiva: windows.attiva !== false, webcam: typeof windows.webcam === 'string' ? windows.webcam : '' };
      winStatus = (await chrome.storage.session.get('windowsStato')).windowsStato || null;
    } catch { /* ignora */ }
    renderWindows();
  }

  // ---------------------------------------------------------------------
  // Componenti aggiornabili al volo
  // Quando componenti/componenti.js cambia sul disco, il service worker lo
  // segnala (storage "components") e qui lo si ricarica senza toccare nulla.
  // ---------------------------------------------------------------------

  let componentsError = '';
  let componentsHash = '';

  function showComponentsStatus() {
    const k = C.catalog();
    const el = $('compStatus');
    if (!k.loaded) { el.textContent = T('Components not loaded.'); return; }
    const when = k.loadedAt ? new Date(k.loadedAt).toLocaleTimeString(L.locale, { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '';
    let text = T('Engine {engine} · components {components} · {backgrounds} backgrounds, {effects} effects, {animations} animations · loaded at {time}.', {
      engine: chrome.runtime.getManifest().version, components: k.version || '—',
      backgrounds: k.backgrounds.length - 4, effects: k.effects.length, animations: k.animations.length - 1, time: when
    });
    if (componentsError) text += ' ' + T('Last update not valid, the previous ones stay active: {error}', { error: componentsError });
    if (k.errors.length) text += ' ' + T('Turned off because of an error: {list}.', { list: k.errors.map((e) => `${e.id} (${e.message})`).join('; ') });
    el.textContent = text;
    el.classList.toggle('danger', !!(componentsError || k.errors.length));
  }

  function reloadComponents(hash) {
    if (!hash || hash === componentsHash) return;
    componentsHash = hash;
    componentsError = '';
    const s = document.createElement('script');
    s.src = `componenti/componenti.js?v=${encodeURIComponent(hash)}`;
    s.onload = () => s.remove();
    s.onerror = () => { componentsError = T('file not readable'); showComponentsStatus(); s.remove(); };
    document.head.append(s);
  }

  // errori di sintassi nel file dei componenti: il pacchetto precedente resta attivo
  window.addEventListener('error', (e) => {
    if (e.filename && e.filename.includes('/componenti/componenti.js')) {
      componentsError = T('{message} (line {line})', { message: e.message, line: e.lineno });
      showComponentsStatus();
    }
  });

  C.onRegistryChange(() => {
    if (!selected) return;
    syncBackground();
    renderEffects();
    renderElements();
    renderNews();
    showComponentsStatus();
  });

  // Versione dell'estensione rispetto all'ultimo rilascio in cammixer-releases
  const RILASCI = 'https://github.com/BBerry2020/cammixer-releases';
  let rilascio = null;

  function showReleaseStatus() {
    const el = $('relStatus');
    const attuale = chrome.runtime.getManifest().version;
    const link = document.createElement('a');
    link.href = RILASCI; link.target = '_blank'; link.rel = 'noopener'; link.textContent = 'cammixer-releases';
    let testo;
    if (rilascio && rilascio.nuova) {
      const ws = winStatus && winStatus.collegato && winStatus.piattaforma === 'windows';
      testo = ws ? T('Extension {current}: version {new} is out; it comes with the update of the CamMixer program (box above) or from ', { current: attuale, new: rilascio.versione })
        : T('Extension {current}: version {new} is out. Download it from ', { current: attuale, new: rilascio.versione });
    } else if (rilascio && rilascio.versione) {
      testo = T('Extension {current}, up to date (last checked at {time}). Releases in ', {
        current: attuale, time: new Date(rilascio.controllato).toLocaleTimeString(L.locale, { hour: '2-digit', minute: '2-digit' })
      });
    } else {
      testo = T('Extension {current}. CamMixer releases (extension and programs for Windows and macOS) are in ', { current: attuale });
    }
    el.replaceChildren(testo, link, '.');
    el.classList.toggle('danger', !!(rilascio && rilascio.nuova));
  }

  async function checkReleasesNow() {
    try {
      const r = await chrome.runtime.sendMessage({ type: 'check-releases' });
      if (r && r.ok) rilascio = r.data;
    } catch { /* senza rete resta l'ultimo esito */ }
    showReleaseStatus();
    showWindowsStatus();
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.rilascio) { rilascio = changes.rilascio.newValue || null; showReleaseStatus(); showWindowsStatus(); }
  });

  async function checkComponentsNow(manual) {
    try {
      const r = await chrome.runtime.sendMessage({ type: 'check-components' });
      if (r && r.ok) reloadComponents(r.data.hash);
      if (manual) $('compCheckResult').textContent = r && r.ok && r.data.changed ? T('Updated.') : T('Already up to date.');
    } catch {
      if (manual) $('compCheckResult').textContent = T('Check failed.');
    }
  }

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === 'local' && changes.components && changes.components.newValue) reloadComponents(changes.components.newValue.hash);
  });

  // ---------------------------------------------------------------------
  // Elementi sovrapposti
  // ---------------------------------------------------------------------

  const EMOJI_PICKS = ['😎', '⭐', '🔥', '💥', '🎉', '❤️', '👽', '🤖', '📺', '🌈', '👑', '💬'];
  let imageTarget = null;   // elemento a cui assegnare l'immagine scelta (null = nuovo elemento)

  // Immagine di un elemento: max 512 px, PNG per mantenere la trasparenza
  $('faceSize').addEventListener('input', () => {
    faceSize = Math.max(1, Number($('faceSize').value));
    $('faceSizeOut').textContent = `${faceSize}%`;
    const scelto = C.catalog().effects.find((e) => e.volto && (Number(selected.fx.effects[e.id]) || 0) > 0);
    if (scelto) { selected.fx.effects[scelto.id] = faceSize; save(); }
  });

  async function loadElementImage(file) {
    const bmp = await createImageBitmap(file);
    const s = Math.min(1, 512 / bmp.width, 512 / bmp.height);
    const c = document.createElement('canvas');
    c.width = Math.max(1, Math.round(bmp.width * s));
    c.height = Math.max(1, Math.round(bmp.height * s));
    c.getContext('2d').drawImage(bmp, 0, 0, c.width, c.height);
    bmp.close();
    let url = c.toDataURL('image/png');
    if (url.length > 1.5e6) url = c.toDataURL('image/webp', 0.9);
    return url;
  }

  function elField(labelText, input) {
    const label = document.createElement('label');
    label.className = 'field';
    label.append(labelText, input);
    return label;
  }

  function elSlider(el, key, labelText, min, max) {
    const wrap = document.createElement('div');
    wrap.className = 'slider';
    const head = document.createElement('label');
    head.className = 'slider-head';
    const name = document.createElement('span');
    name.textContent = labelText;
    const out = document.createElement('output');
    out.textContent = `${el[key]}%`;
    head.append(name, out);
    const input = document.createElement('input');
    input.type = 'range';
    input.min = min;
    input.max = max;
    input.value = el[key];
    input.setAttribute('aria-label', labelText);
    input.addEventListener('input', () => { el[key] = Number(input.value); out.textContent = `${el[key]}%`; save(); });
    wrap.append(head, input);
    return wrap;
  }

  function elementCard(el) {
    const card = document.createElement('div');
    card.className = 'el-card';
    const head = document.createElement('div');
    head.className = 'el-head';
    const title = document.createElement('strong');
    title.textContent = T((C.ELEMENT_TYPES.find((t) => t.id === el.type) || {}).label || el.type);
    const del = document.createElement('button');
    del.textContent = T('Delete');
    del.onclick = () => {
      selected.fx.elements = selected.fx.elements.filter((x) => x !== el);
      renderElements();
      save(true);
    };
    head.append(title, del);
    card.append(head);

    if (el.type === 'text') {
      const input = document.createElement('input');
      input.type = 'text';
      input.maxLength = 60;
      input.value = el.text;
      input.addEventListener('input', () => { el.text = input.value; save(); });
      const color = document.createElement('input');
      color.type = 'color';
      color.value = el.color;
      color.addEventListener('input', () => { el.color = color.value; save(); });
      const row = document.createElement('div');
      row.className = 'field row';
      row.append(T('Colour'), color);
      card.append(elField(T('Text'), input), row);
    } else if (el.type === 'emoji') {
      const input = document.createElement('input');
      input.type = 'text';
      input.value = el.emoji;
      input.addEventListener('input', () => { el.emoji = [...input.value].slice(0, 8).join(''); save(); });
      const picks = document.createElement('div');
      picks.className = 'emoji-picks';
      for (const e of EMOJI_PICKS) {
        const b = document.createElement('button');
        b.textContent = e;
        b.onclick = () => { el.emoji = e; input.value = e; save(); };
        picks.append(b);
      }
      card.append(elField(T('Emoji'), input), picks);
    } else if (el.type === 'image') {
      if (el.image) {
        const img = document.createElement('img');
        img.className = 'el-thumb';
        img.src = el.image;
        img.alt = '';
        card.append(img);
      }
      const change = document.createElement('button');
      change.textContent = el.image ? T('Change image…') : T('Choose an image…');
      change.onclick = () => { imageTarget = el; $('elFile').click(); };
      card.append(change);
    }

    card.append(
      elSlider(el, 'x', T('Horizontal'), 0, 100),
      elSlider(el, 'y', T('Vertical'), 0, 100),
      elSlider(el, 'size', T('Size'), 2, 100)
    );
    const anim = document.createElement('select');
    const anims = C.catalog().animations.filter((a) => !a.soloTesto || el.type === 'text');
    if (!anims.some((a) => a.id === el.anim)) anims.push({ id: el.anim, label: T('{id} (not available)', { id: el.anim }) });
    for (const a of anims) anim.append(new Option(T(a.label), a.id));
    anim.value = el.anim;
    anim.addEventListener('change', () => { el.anim = anim.value; save(); });
    card.append(elField(T('Animation'), anim));
    return card;
  }

  function renderElements() {
    const box = $('elements');
    const els = selected.fx.elements;
    const full = els.length >= C.MAX_ELEMENTS;
    for (const id of ['addText', 'addEmoji', 'addImage']) $(id).disabled = full;
    if (!els.length) {
      const p = document.createElement('p');
      p.className = 'el-empty';
      p.textContent = T('No elements. Add a text, an emoji or an image: they appear over the video, animated too.');
      box.replaceChildren(p);
      return;
    }
    box.replaceChildren(...els.map(elementCard));
  }

  function addElement(el) {
    if (selected.fx.elements.length >= C.MAX_ELEMENTS) return;
    selected.fx.elements.push(el);
    renderElements();
    save(true);
  }

  function buildControls() {
    C.ADJUST.forEach((s) => buildSlider($('adjust'), s));
    C.MIXING.forEach((s) => buildSlider($('mixing'), s));
    C.SEGMENT.forEach((s) => buildSlider($('segSliders'), s));
    buildNewsFields();
    // i cursori degli effetti dipendono dai componenti: vedi renderEffects()
    $('addText').onclick = () => addElement(C.newElement('text'));
    $('addEmoji').onclick = () => addElement(C.newElement('emoji'));
    $('addImage').onclick = () => { imageTarget = null; $('elFile').click(); };
    $('elFile').addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      e.target.value = '';
      if (!file) return;
      try {
        const url = await loadElementImage(file);
        if (imageTarget && selected.fx.elements.includes(imageTarget)) {
          imageTarget.image = url;
          renderElements();
          save(true);
        } else {
          addElement(Object.assign(C.newElement('image'), { image: url }));
        }
      } catch {
        alert(T('Cannot read the image.'));
      }
      imageTarget = null;
    });
    buildSlider($('bgBlurBox'), C.BG_BLUR);
    for (const t of C.TOGGLES) {
      const label = document.createElement('label');
      label.className = 'check';
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.id = `fx-${t.id}`;
      cb.addEventListener('change', () => { selected.fx[t.id] = cb.checked; save(); });
      label.append(cb, ` ${T(t.label)}`);
      $('toggles').append(label);
    }
    $('bgType').addEventListener('change', (e) => {
      selected.fx.bg = e.target.value;
      if (selected.fx.bg !== 'none' && selected.source !== C.NO_CAMERA) C.retrySegmenter();
      syncBackground();
      save();
    });
    $('bgColor').addEventListener('input', (e) => { selected.fx.bgColor = e.target.value; save(); });
    $('bgPick').onclick = () => $('bgFile').click();
    $('bgFile').addEventListener('change', async (e) => {
      const file = e.target.files && e.target.files[0];
      e.target.value = '';
      if (!file) return;
      try {
        selected.fx.bgImage = await loadImage(file);
        selected.fx.bg = 'media';
        selected.loadMedia();
        syncBackground();
        save(true);
      } catch {
        $('segStatus').textContent = T('Cannot read the image.');
      }
    });
    $('bgClear').onclick = () => {
      selected.fx.bgImage = '';
      if (selected.fx.bg === 'media') selected.fx.bg = 'none';
      selected.loadMedia();
      syncBackground();
      save(true);
    };
    $('text').addEventListener('input', (e) => { selected.fx.text = e.target.value.trim(); save(); });
    $('clock').addEventListener('change', (e) => { selected.fx.clock = e.target.checked; save(); });
    // Ripristina effetti: modifiche ed effetti ai valori iniziali; sfondo, testi ed elementi restano
    $('reset').onclick = () => {
      Object.assign(selected.fx, C.effectDefaults());
      syncControls();
      save(true);
    };
    // Ripristina tutto: questa webcam virtuale torna come nuova (nome e sorgente restano)
    $('resetAll').onclick = () => {
      if (!confirm(T('Reset “{name}” to the initial settings? Background, texts and elements will be removed.', { name: selected.name }))) return;
      selected.fx = C.defaultFx();
      selected.loadMedia();
      syncControls();
      renderElements();
      save(true);
    };
    // Ripristina l'estensione: cancella tutto e riparte da Webcam1
    $('resetExt').onclick = async () => {
      if (!confirm(T('Delete all virtual webcams and settings? The extension will start again from Webcam1, as if just installed.'))) return;
      clearTimeout(saveTimer);
      for (const v of vcams) v.stop(false);
      const fresh = { ...C.normalizeState(null), lingua: L.attuale };
      lastSaved = JSON.stringify(fresh);
      await chrome.storage.local.set({ state: fresh, panelCollapsed: false });
      location.reload();
    };

    $('newCam').onclick = () => {
      const v = new C.VCam({ id: C.newId(), name: nextName(), source: selected.source, fx: C.defaultFx() }, env);
      vcams.push(v);
      selectVcam(v);
      save(true);
      $('camName').focus();
      $('camName').select();
    };
    $('camDelete').onclick = () => {
      if (vcams.length < 2) return;
      const v = selected;
      if (!confirm(T('Delete the virtual webcam “{name}”?', { name: v.name }))) return;
      if (registratore.info.vcamId === v.id) registratore.ferma('fine');
      v.stop(false);
      vcams.splice(vcams.indexOf(v), 1);
      if (defaultId === v.id) defaultId = null;
      selectVcam(vcams[0]);
      save(true);
    };
    $('camName').addEventListener('input', (e) => {
      selected.name = e.target.value.trim().slice(0, 40) || T('Untitled');
      $('outTitle').textContent = T('Output · {name}', { name: selected.name });
      $('live').textContent = `LIVE · ${selected.name}`;
      renderTabs();
      save();
    });
    $('camDefault').addEventListener('change', (e) => {
      defaultId = e.target.checked ? selected.id : null;   // una sola sostituisce la webcam reale
      renderTabs();
      save(true);
    });
    $('sourceCam').addEventListener('change', (e) => {
      selected.source = e.target.value;
      renderTabs();
      syncBackground();
      if (selected.fx.bg !== 'none' && selected.source !== C.NO_CAMERA) C.retrySegmenter();
      if (active) selected.start().catch(() => {}); else showSource();
      save(true);
    });
    $('mirror').addEventListener('change', (e) => $('video').classList.toggle('mirror', e.target.checked));
    $('toggle').onclick = () => {
      active = !active;
      if (!active) registratore.ferma('fine');   // anteprima ferma: la registrazione si salva
      refreshRunning();
      showOutput();
    };
    md.addEventListener('devicechange', () => listSources());
  }

  // Lingua dell'interfaccia: si salva e la pagina si ricarica nella nuova lingua
  async function cambiaLingua(id) {
    if (!L.imposta(id)) return;
    clearTimeout(saveTimer);
    const s = snapshot();
    lastSaved = JSON.stringify(s);
    try { await chrome.storage.local.set({ state: s }); } catch { /* ignora */ }
    location.reload();
  }

  // ---------------------------------------------------------------------
  // Avvio
  // ---------------------------------------------------------------------

  (async () => {
    let stored = null;
    try { stored = (await chrome.storage.local.get('state')).state; } catch { /* ignora */ }
    const s = C.normalizeState(stored);
    L.imposta(s.lingua);
    L.traduciPagina();
    $('lingue').replaceChildren(L.selettore(cambiaLingua));
    defaultId = s.defaultId;
    esempi3d = s.esempi3d;
    C.setEsempi3D(esempi3d);
    $('esempi3d').checked = esempi3d;
    $('esempi3d').addEventListener('change', (e) => {
      esempi3d = e.target.checked;
      C.setEsempi3D(esempi3d);   // il catalogo cambia: gli elenchi si aggiornano da soli
      save(true);
    });
    for (const c of s.vcams) vcams.push(new C.VCam(c, env));
    selected = vcams[0];
    buildControls();
    await buildRecording();
    renderTabs();
    syncEditor();
    if (!stored) save(true);
    if (selected.fx.bg !== 'none' && selected.source !== C.NO_CAMERA) C.loadSegmenter();
    refreshRunning();
    loadWindows();

    // Componenti: versione caricata con la pagina, poi controllo continuo mentre la pagina è aperta
    try { const r = await chrome.storage.local.get('components'); componentsHash = (r.components && r.components.hash) || ''; } catch { /* ignora */ }
    showComponentsStatus();
    $('compCheck').onclick = () => { checkComponentsNow(true); checkReleasesNow(); };
    // stato del tracciamento del volto (caricamento, attivo, errore) mentre un oggetto è scelto
    setInterval(() => { if (selected && !$('faceSizeBox').hidden) renderEffects(); }, 1500);
    try { rilascio = (await chrome.storage.local.get('rilascio')).rilascio || null; } catch { /* ignora */ }
    showReleaseStatus();
    if (!rilascio || Date.now() - rilascio.controllato > 3600 * 1000) checkReleasesNow();
    checkComponentsNow(false);
    setInterval(() => { if (document.visibilityState === 'visible') checkComponentsNow(false); }, 3000);
  })();
})();
