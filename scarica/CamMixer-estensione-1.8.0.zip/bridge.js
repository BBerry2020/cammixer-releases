/*
 * CamMixer - ponte tra l'estensione e il sito, e pannello in pagina.
 * Gira nel contesto isolato dell'estensione: il sito non può leggere né
 * modificare il pannello né le impostazioni salvate.
 */
(() => {
  'use strict';
  if (window.__webcamVirtualiBridge) return;
  window.__webcamVirtualiBridge = true;

  const TAG = '__webcamVirtuali';
  const L = CamMixerLingua;   // lingua dell'interfaccia (lingua.js, caricato prima di questo file)
  const T = L.T;
  const base = chrome.runtime.getURL('');
  let state = null;           // impostazioni (già validate dal service worker)
  let meta = null;            // cursori e opzioni del motore, dal service worker
  let catalog = null;         // componenti caricati nella pagina: sfondi, effetti, animazioni
  let active = [];            // webcam virtuali in uso in questa pagina
  let segInfo = { state: 'idle', error: '' };
  let pending = {};           // modifiche dal pannello non ancora salvate
  let saveTimer = null;
  // Registrazione dal pannello: la fa la pagina (inject.js), il file lo salva questo script
  let rec = { attivo: false, durata: 0, byte: 0 };
  let recMsg = '', recErr = false;
  let videoAtteso = false;    // si accetta un video solo dopo aver premuto Registra
  let fotoAttese = 0;         // e una foto solo dopo aver premuto Foto
  const FILE_OK = /^CamMixer-[\w.-]{1,40}-\d{4}-\d\d-\d\d_\d\d-\d\d-\d\d\.(mp4|webm|png)$/;
  const TIPI_FILE = { mp4: 'video/mp4', webm: 'video/webm', png: 'image/png' };

  const post = (m) => window.postMessage({ [TAG]: 'ext', ...m }, '*');
  const sendState = () => { if (state) post({ type: 'state', state, base }); };
  const alive = () => { try { return !!chrome.runtime.id; } catch { return false; } };
  const ask = (msg) => chrome.runtime.sendMessage(msg).then((r) => {
    if (!r || !r.ok) throw new Error((r && r.error) || T('error'));
    return r.data;
  });

  // Lettura diretta (veloce: molti siti chiedono la fotocamera appena si aprono);
  // il service worker serve solo al primissimo avvio, quando non c'è ancora nulla di salvato.
  const gotState = (s) => { if (s && Array.isArray(s.vcams)) { state = s; setLingua(); sendState(); renderPanel(); } };
  chrome.storage.local.get('state')
    .then((r) => (r.state ? gotState(r.state) : ask({ type: 'get-state' }).then(gotState)))
    .catch(() => {});
  ask({ type: 'meta' }).then((m) => { meta = m; renderPanel(); }).catch(() => {});
  // I componenti vengono iniettati dal service worker, letti dal disco: sempre l'ultima versione
  const needComponents = () => { if (alive()) ask({ type: 'need-components' }).catch(() => {}); };
  needComponents();
  // Mentre una webcam virtuale è in uso, si controlla spesso se i componenti sono cambiati
  setInterval(() => {
    if (!active.length) return;
    if (!alive()) { renderPanel(); return; }   // motore ricaricato: lo si segnala nel pannello
    ask({ type: 'check-components' }).catch(() => {});
  }, 10000);
  chrome.storage.local.get('panelCollapsed').then((r) => { panel.collapsed = !!r.panelCollapsed; renderPanel(); }).catch(() => {});

  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local' || !changes.state || !changes.state.newValue) return;
    state = changes.state.newValue;
    setLingua();
    // le modifiche appena fatte nel pannello restano visibili finché non vengono salvate
    for (const [id, patch] of Object.entries(pending)) {
      const c = state.vcams.find((x) => x.id === id);
      if (c) Object.assign(c.fx, patch);
    }
    sendState();
    renderPanel();
  });

  // Lingua scelta nelle impostazioni (o con le bandierine del pannello): il pannello si ricostruisce
  function setLingua() {
    if (!L.imposta(state && state.lingua) || !panel.built) return;
    panel.host.remove();
    Object.assign(panel, { host: null, root: null, built: false, els: {} });
  }

  // Il salvataggio passa dal service worker, che accetta solo chiavi e valori validi
  function save() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(() => {
      const batch = pending;
      pending = {};
      if (!alive()) return;
      for (const [id, patch] of Object.entries(batch)) ask({ type: 'edit', id, patch }).catch(() => {});
    }, 200);
  }

  function b64ToBuffer(b64) {
    const bin = atob(b64);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return bytes.buffer;
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data[TAG] !== 'page') return;
    const m = e.data;
    if (m.type === 'hello') {
      sendState();
    } else if (m.type === 'need-components') {
      needComponents();
    } else if (m.type === 'catalog') {
      const k = m.catalog;
      const okList = (l) => Array.isArray(l) && l.every((x) => x && typeof x.id === 'string' && typeof x.label === 'string');
      if (k && okList(k.backgrounds) && okList(k.effects) && okList(k.animations)) {
        catalog = {
          version: String(k.version || ''), loaded: !!k.loaded,
          backgrounds: k.backgrounds.slice(0, 60), effects: k.effects.slice(0, 40),
          lowerThirds: okList(k.lowerThirds) ? k.lowerThirds.slice(0, 40) : [],
          errors: Array.isArray(k.errors) ? k.errors.slice(0, 5).map((e) => `${String(e.id)}: ${String(e.message)}`) : []
        };
        renderPanel();
      }
    } else if (m.type === 'need-loader') {
      if (!alive()) return post({ type: 'loader', ok: false, error: T('extension reloaded: reload the page') });
      chrome.runtime.sendMessage({ type: 'inject-mediapipe' })
        .then((r) => post({ type: 'loader', ok: !!(r && r.ok), error: r && !r.ok ? String(r.error || '') : '' }))
        .catch((err) => post({ type: 'loader', ok: false, error: String(err && err.message || err) }));
    } else if (m.type === 'need-model') {
      if (!alive()) return post({ type: 'model', modello: m.modello, error: T('extension reloaded: reload the page') });
      const modello = m.modello === 'volto' ? 'volto' : 'ritaglio';
      chrome.runtime.sendMessage({ type: 'get-model', modello })
        .then((r) => post(r && r.ok ? { type: 'model', modello, buffer: b64ToBuffer(r.data) } : { type: 'model', modello, error: (r && r.error) || T('error') }))
        .catch((err) => post({ type: 'model', modello, error: String(err && err.message || err) }));
    } else if (m.type === 'rec-stato') {
      const i = m.info || {};
      rec = i.attivo ? { attivo: true, durata: Number(i.durata) || 0, byte: Number(i.byte) || 0, audio: !!i.audio } : { attivo: false, durata: 0, byte: 0 };
      renderPanel();
    } else if (m.type === 'rec-file') {
      salvaFile(m.file);
    } else if (m.type === 'rec-errore') {
      const err = String(m.errore || '').slice(0, 200);
      const testi = {
        spenta: () => T('The virtual webcam is not in use in this page.'),
        microfono: () => T('Microphone not available ({error}): recording without sound.', { error: err }),
        avvio: () => T('Cannot start the recording: {error}', { error: err }),
        foto: () => T('Screenshot not available: {error}', { error: err }),
        video: () => T('Recording failed: {error}', { error: err })
      };
      if (!testi[m.codice]) return;
      if (m.codice !== 'microfono') videoAtteso = videoAtteso && rec.attivo;
      if (m.codice === 'foto' || m.codice === 'spenta') fotoAttese = Math.max(0, fotoAttese - 1);
      recMsg = testi[m.codice]();
      recErr = true;
      renderPanel();
    } else if (m.type === 'active') {
      const wasActive = active.length > 0;
      active = Array.isArray(m.vcams) ? m.vcams.filter((v) => v && typeof v.id === 'string').slice(0, 4) : [];
      // appena una webcam virtuale entra in uso lo si dice subito al service worker,
      // che rinvia un eventuale aggiornamento del motore finché la chat è attiva
      if (!wasActive && active.length && alive()) ask({ type: 'check-components' }).catch(() => {});
      if (m.seg && typeof m.seg.state === 'string') segInfo = { state: m.seg.state, error: String(m.seg.error || '') };
      renderPanel();
    }
  });

  // File registrato o foto: salvato nei download da qui, con un nome controllato
  function salvaFile(f) {
    if (!f || !(f.blob instanceof Blob) || typeof f.nome !== 'string') return;
    const m = FILE_OK.exec(f.nome);
    if (!m || f.blob.type !== TIPI_FILE[m[1]]) return;
    if (m[1] === 'png') { if (fotoAttese <= 0) return; fotoAttese--; } else { if (!videoAtteso) return; videoAtteso = false; }
    const url = URL.createObjectURL(f.blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = f.nome;
    (panel.root || document.documentElement).append(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
    const dim = f.blob.size >= 1048576 ? `${(f.blob.size / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(f.blob.size / 1024))} KB`;
    if (m[1] === 'png') recMsg = T('Screenshot saved: {file}', { file: f.nome });
    else {
      const s = Math.floor((Number(f.durata) || 0) / 1000);
      const parti = [T('Saved {file} ({time}, {size}) in the downloads folder.', { file: f.nome, time: `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`, size: dim })];
      if (f.motivo === 'limite') parti.push(T('The recording stopped at the limit (60 minutes or 1.5 GB).'));
      if (f.senzaAudio) parti.push(T('This browser cannot record sound in this format: the video has no audio.'));
      recMsg = parti.join(' ');
    }
    recErr = false;
    renderPanel();
  }

  function premiRegistra() {
    const c = currentConfig();
    if (!c || !alive()) return;
    if (rec.attivo) { post({ type: 'rec-ferma' }); return; }
    recMsg = '';
    recErr = false;
    videoAtteso = true;
    chrome.storage.local.get('registrazione')
      .then((r) => post({ type: 'rec-avvia', id: c.id, opzioni: r.registrazione || null }))
      .catch(() => post({ type: 'rec-avvia', id: c.id, opzioni: null }));
    renderPanel();
  }

  function premiFoto() {
    const c = currentConfig();
    if (!c) return;
    fotoAttese++;
    post({ type: 'rec-foto', id: c.id });
  }

  // =====================================================================
  // Pannello in pagina: compare quando il sito usa una webcam virtuale
  // =====================================================================

  const PANEL_SLIDERS = ['brightness', 'contrast', 'saturate', 'blur', 'pixel', 'zoom', 'mix', 'bgBlur', 'segSens'];
  const PANEL_TOGGLES = ['invert', 'flipH'];
  const panel = { host: null, root: null, collapsed: false, built: false, els: {} };

  const CSS = `
    :host { all: initial; }
    * { box-sizing: border-box; font-family: system-ui, -apple-system, "Segoe UI", Roboto, sans-serif; }
    .wrap { position: fixed; right: 16px; bottom: 16px; z-index: 2147483647; color: #e6e9ed; font-size: 13px; line-height: 1.4; }
    .pill, .card { background: rgba(20, 23, 28, .94); border: 1px solid rgba(255, 255, 255, .12); box-shadow: 0 8px 28px rgba(0, 0, 0, .35); }
    .pill { display: flex; align-items: center; gap: 8px; padding: 7px 14px; border-radius: 999px; color: inherit; font: inherit; font-weight: 600; cursor: pointer; }
    .dot { width: 8px; height: 8px; border-radius: 50%; background: #ff5a4f; flex: none; }
    .card { width: 272px; max-height: calc(100vh - 32px); overflow: auto; border-radius: 12px; padding: 12px 14px 14px; }
    .head { display: flex; align-items: center; gap: 8px; margin-bottom: 8px; cursor: move; user-select: none; }
    .head strong { flex: 1; font-size: 14px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; }
    .cmx-lingue { display: flex; gap: 2px; }
    .cmx-lingue button { display: flex; align-items: center; padding: 3px; border-radius: 5px; border: 1px solid transparent; background: transparent; cursor: pointer; opacity: .5; }
    .cmx-lingue button:hover { opacity: .85; }
    .cmx-lingue button[aria-checked="true"] { opacity: 1; border-color: rgba(255, 255, 255, .35); }
    .cmx-lingue svg { display: block; width: 18px; height: 12px; border-radius: 2px; }
    .icon { width: 26px; height: 26px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, .15); background: transparent; color: inherit; cursor: pointer; font: 600 15px/1 system-ui, sans-serif; }
    .status { color: #9aa4b0; font-size: 12px; margin: -2px 0 10px; }
    .status.err { color: #ff8a80; }
    label { display: block; margin: 0 0 8px; }
    .row { display: flex; justify-content: space-between; }
    .row output { color: #9aa4b0; font-variant-numeric: tabular-nums; }
    select, input[type=text] { width: 100%; margin-top: 3px; padding: 5px 8px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, .18); background: #0e1114; color: inherit; font: inherit; }
    input[type=range] { width: 100%; margin: 2px 0 0; accent-color: #4a90e2; }
    .checks { display: flex; flex-wrap: wrap; gap: 4px 14px; margin: 2px 0 10px; }
    .checks label { display: flex; align-items: center; gap: 6px; margin: 0; color: #c9d1d9; }
    .checks input { accent-color: #4a90e2; margin: 0; }
    .more { width: 100%; margin-top: 4px; padding: 7px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, .18); background: #4a90e2; color: #0e1114; font: inherit; font-weight: 600; cursor: pointer; }
    .reset { width: 100%; margin-top: 4px; padding: 6px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, .18); background: transparent; color: inherit; font: inherit; cursor: pointer; }
    .recrow { display: flex; gap: 6px; margin: 0 0 6px; }
    .recrow button { flex: 1; padding: 6px 8px; border-radius: 6px; border: 1px solid rgba(255, 255, 255, .18); background: transparent; color: inherit; font: inherit; cursor: pointer; white-space: nowrap; }
    .recrow button:hover { background: rgba(255, 255, 255, .06); }
    .recb::before { content: ""; display: inline-block; width: 8px; height: 8px; margin-right: 6px; border-radius: 50%; background: #ff5a4f; }
    .recb.on { border-color: #ff5a4f; color: #ff8a80; font-weight: 600; font-variant-numeric: tabular-nums; }
    .recb.on::before { border-radius: 2px; }
    .recmsg { margin: 0 0 10px; color: #9aa4b0; font-size: 12px; overflow-wrap: anywhere; }
    .recmsg.err { color: #ff8a80; }
    .pill .rectag { color: #ff8a80; font-variant-numeric: tabular-nums; }
    [hidden] { display: none !important; }
  `;

  function buildPanel() {
    const host = document.createElement('webcam-virtuali-pannello');
    const root = host.attachShadow({ mode: 'closed' });
    const style = document.createElement('style');
    style.textContent = CSS;
    const wrap = document.createElement('div');
    wrap.className = 'wrap';
    root.append(style, wrap);

    const pill = document.createElement('button');
    pill.className = 'pill';
    const pillDot = document.createElement('span');
    pillDot.className = 'dot';
    const pillText = document.createElement('span');
    const pillRec = document.createElement('span');
    pillRec.className = 'rectag';
    pill.append(pillDot, pillText, pillRec);
    pill.onclick = () => { if (!dragged) setCollapsed(false); };

    const card = document.createElement('div');
    card.className = 'card';
    const head = document.createElement('div');
    head.className = 'head';
    const dot = document.createElement('span');
    dot.className = 'dot';
    const title = document.createElement('strong');
    const min = document.createElement('button');
    min.className = 'icon';
    min.textContent = '–';
    min.title = T('Collapse');
    min.onclick = () => setCollapsed(true);
    const lingue = L.selettore((id) => { if (id !== L.attuale && alive()) ask({ type: 'lingua', lingua: id }).catch(() => {}); }, true);
    head.append(dot, title, lingue, min);
    const status = document.createElement('div');
    status.className = 'status';

    const recRow = document.createElement('div');
    recRow.className = 'recrow';
    const recBtn = document.createElement('button');
    recBtn.className = 'recb';
    recBtn.onclick = premiRegistra;
    const shotBtn = document.createElement('button');
    shotBtn.textContent = T('Screenshot');
    shotBtn.title = T('Saves the current frame as a PNG image');
    shotBtn.onclick = premiFoto;
    recRow.append(recBtn, shotBtn);
    const recLine = document.createElement('div');
    recLine.className = 'recmsg';
    recLine.setAttribute('aria-live', 'polite');

    const bgLabel = document.createElement('label');
    bgLabel.textContent = T('Background');
    const bg = document.createElement('select');
    bgLabel.append(bg);
    bg.onchange = () => edit({ bg: bg.value });

    const sliders = {};
    const sliderBox = document.createElement('div');
    for (const id of PANEL_SLIDERS) {
      const s = meta.SLIDERS.find((x) => x.id === id);
      if (!s) continue;
      const label = document.createElement('label');
      const row = document.createElement('div');
      row.className = 'row';
      const name = document.createElement('span');
      name.textContent = T(s.label);
      const out = document.createElement('output');
      row.append(name, out);
      const input = document.createElement('input');
      input.type = 'range';
      input.min = s.min;
      input.max = s.max;
      input.oninput = () => { out.textContent = fmt(s, Number(input.value)); edit({ [id]: Number(input.value) }); };
      if (s.hint) label.title = T(s.hint);
      label.append(row, input);
      sliderBox.append(label);
      sliders[id] = { label, input, out, s };
    }

    const fxBox = document.createElement('div');   // effetti dei componenti, ricostruiti a ogni aggiornamento

    const checks = document.createElement('div');
    checks.className = 'checks';
    const toggles = {};
    for (const id of PANEL_TOGGLES) {
      const t = meta.TOGGLES.find((x) => x.id === id);
      if (!t) continue;
      const label = document.createElement('label');
      const cb = document.createElement('input');
      cb.type = 'checkbox';
      cb.onchange = () => edit({ [id]: cb.checked });
      label.append(cb, T(t.label));
      checks.append(label);
      toggles[id] = cb;
    }

    const textLabel = document.createElement('label');
    textLabel.textContent = T('Overlay text');
    const text = document.createElement('input');
    text.type = 'text';
    text.maxLength = 60;
    text.placeholder = T('E.g. a name');
    text.oninput = () => edit({ text: text.value.trim() });
    textLabel.append(text);

    const newsLabel = document.createElement('label');
    newsLabel.textContent = T('Lower third');
    const newsStyle = document.createElement('select');
    newsStyle.onchange = () => { const cur = currentConfig(); if (cur) edit({ news: { ...cur.fx.news, style: newsStyle.value } }); };
    newsLabel.append(newsStyle);
    const headLabel = document.createElement('label');
    headLabel.textContent = T('Headline');
    const headline = document.createElement('input');
    headline.type = 'text';
    headline.maxLength = 90;
    headline.placeholder = T('The main headline');
    headline.oninput = () => { const cur = currentConfig(); if (cur) edit({ news: { ...cur.fx.news, headline: headline.value } }); };
    headLabel.append(headline);
    const posLabel = document.createElement('label');
    const posRow = document.createElement('div');
    posRow.className = 'row';
    const posName = document.createElement('span');
    posName.textContent = T('Lower third height');
    const posOut = document.createElement('output');
    posRow.append(posName, posOut);
    const posInput = document.createElement('input');
    posInput.type = 'range';
    posInput.min = -70;
    posInput.max = 20;
    posInput.oninput = () => {
      const cur = currentConfig();
      if (!cur) return;
      posOut.textContent = `${posInput.value}%`;
      edit({ news: { ...cur.fx.news, y: Number(posInput.value) } });
    };
    posLabel.append(posRow, posInput);

    const reset = document.createElement('button');
    reset.className = 'reset';
    reset.textContent = T('Reset effects');
    reset.title = T('Bring adjustments and effects back to their initial values (background, texts and elements stay)');
    reset.onclick = () => edit({ ...meta.RESET });

    const more = document.createElement('button');
    more.className = 'more';
    more.textContent = T('All settings…');
    more.onclick = () => { if (alive()) chrome.runtime.sendMessage({ type: 'open-options' }).catch(() => {}); };

    card.append(head, status, recRow, recLine, bgLabel, sliderBox, fxBox, checks, textLabel, newsLabel, headLabel, posLabel, reset, more);
    wrap.append(pill, card);

    // I tasti premuti nel pannello non arrivano al sito (niente scorciatoie accidentali)
    for (const type of ['keydown', 'keyup', 'keypress']) root.addEventListener(type, (e) => e.stopPropagation());

    // Trascinamento dal titolo o dalla pillola
    let dragged = false;
    const startDrag = (e) => {
      if (e.button !== 0 || e.target.closest('button')) return;
      const r0 = wrap.getBoundingClientRect();
      const sx = e.clientX, sy = e.clientY;
      const right0 = window.innerWidth - r0.right, bottom0 = window.innerHeight - r0.bottom;
      dragged = false;
      const move = (ev) => {
        const dx = ev.clientX - sx, dy = ev.clientY - sy;
        if (Math.abs(dx) + Math.abs(dy) > 4) dragged = true;
        wrap.style.right = `${Math.max(0, Math.min(window.innerWidth - 60, right0 - dx))}px`;
        wrap.style.bottom = `${Math.max(0, Math.min(window.innerHeight - 40, bottom0 - dy))}px`;
      };
      const up = () => { window.removeEventListener('pointermove', move, true); window.removeEventListener('pointerup', up, true); };
      window.addEventListener('pointermove', move, true);
      window.addEventListener('pointerup', up, true);
    };
    head.addEventListener('pointerdown', startDrag);
    pill.addEventListener('pointerdown', startDrag);

    (document.body || document.documentElement).append(host);
    Object.assign(panel, { host, root, built: true, els: { pill, pillText, pillRec, recBtn, recLine, card, title, status, bg, sliders, fxBox, toggles, text, newsStyle, headline, headLabel, posLabel, posInput, posOut }, fxSig: '', fxSliders: {} });
  }

  function fmt(s, v) { return s.off !== undefined && v === s.off ? 'no' : `${v}${s.unit}`; }

  function setCollapsed(c) {
    panel.collapsed = c;
    if (alive()) chrome.storage.local.set({ panelCollapsed: c }).catch(() => {});
    renderPanel();
  }

  function currentConfig() {
    if (!state || !active.length) return null;
    return state.vcams.find((c) => c.id === active[0].id) || null;
  }

  function edit(patch) {
    const c = currentConfig();
    if (!c) return;
    Object.assign(c.fx, patch);
    pending[c.id] = { ...(pending[c.id] || {}), ...patch };
    sendState();   // effetto immediato nella pagina
    save();        // e salvato per le altre schede e le impostazioni
    renderPanel();
  }

  function renderPanel() {
    const c = currentConfig();
    if (!c || !meta || !catalog) { if (panel.host) panel.host.style.display = 'none'; return; }
    if (!panel.built) buildPanel();
    panel.host.style.display = '';
    const el = panel.els;
    const info = active[0];
    el.pill.hidden = !panel.collapsed;
    el.card.hidden = panel.collapsed;
    el.pillText.textContent = c.name;
    el.title.textContent = T('Virtual webcam: {name}', { name: c.name });

    let msg = '', err = false;
    if (!alive()) { msg = T('Extension updated: reload the page to use what is new (the video keeps going).'); err = true; }
    else if (info.status === 'error') { msg = info.error; err = true; }
    else if (c.fx.bg !== 'none' && c.source !== meta.NO_CAMERA) {
      if (segInfo.state === 'error') { msg = T('Cut-out not available ({error}).', { error: segInfo.error }); err = true; }
      else if (segInfo.state !== 'ready') msg = T('Loading the cut-out…');
    }
    if (!msg && catalog.errors.length) { msg = T('Component turned off because of an error: {error}', { error: catalog.errors[0] }); err = true; }
    el.status.textContent = msg;
    el.status.className = err ? 'status err' : 'status';
    el.status.hidden = !msg;

    const tempo = () => { const s = Math.floor(rec.durata / 1000); return `${String(Math.floor(s / 60)).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`; };
    el.recBtn.classList.toggle('on', rec.attivo);
    el.recBtn.textContent = rec.attivo ? T('Stop · {time}', { time: tempo() }) : T('Record');
    el.recBtn.title = rec.attivo ? T('Stop the recording and save it') : T('Records what the virtual webcam sends, as a compressed video');
    el.pillRec.textContent = rec.attivo ? ` · REC ${tempo()}` : '';
    if (rec.attivo) {
      const mb = rec.byte >= 1048576 ? `${(rec.byte / 1048576).toFixed(1)} MB` : `${Math.round(rec.byte / 1024)} KB`;
      el.recLine.textContent = rec.audio ? T('Recording with microphone: {size}', { size: mb }) : T('Recording: {size}', { size: mb });
      el.recLine.className = 'recmsg';
    } else {
      el.recLine.textContent = recMsg;
      el.recLine.className = recErr ? 'recmsg err' : 'recmsg';
    }
    el.recLine.hidden = !el.recLine.textContent;

    const noCam = c.source === meta.NO_CAMERA;
    const bgs = catalog.backgrounds.some((b) => b.id === c.fx.bg) ? catalog.backgrounds
      : [...catalog.backgrounds, { id: c.fx.bg, label: T('{id} (component not available)', { id: c.fx.bg }) }];
    el.bg.replaceChildren(...bgs.map((b) => {
      const o = new Option(T(b.label), b.id);
      if (b.id === 'media' && (!c.fx.bgImage || noCam)) {
        o.disabled = true;
        o.textContent = noCam ? T('Your image (needs the camera)') : T('Your image (upload it in the settings)');
      }
      return o;
    }));
    el.bg.value = c.fx.bg;

    for (const [id, s] of Object.entries(el.sliders)) {
      if (id === 'bgBlur') s.label.hidden = c.fx.bg !== 'blur';
      else if (id === 'segSens') s.label.hidden = c.fx.bg === 'none' || noCam;   // serve solo col ritaglio attivo
      else s.label.hidden = noCam;   // senza telecamera non c'è video reale da modificare
      if (panel.root.activeElement !== s.input) s.input.value = c.fx[id];
      s.out.textContent = fmt(s.s, c.fx[id]);
    }
    for (const [id, cb] of Object.entries(el.toggles)) {
      cb.checked = !!c.fx[id];
      cb.parentElement.hidden = noCam;
    }
    if (panel.root.activeElement !== el.text) el.text.value = c.fx.text;
    const news = c.fx.news || { style: '', headline: '' };
    const lts = [{ id: '', label: 'None' }, ...(catalog.lowerThirds || [])];
    if (news.style && !lts.some((x) => x.id === news.style)) lts.push({ id: news.style, label: T('{id} (not available)', { id: news.style }) });
    el.newsStyle.replaceChildren(...lts.map((x) => new Option(T(x.label), x.id)));
    el.newsStyle.value = news.style;
    el.headLabel.hidden = !news.style;
    el.posLabel.hidden = !news.style;
    if (panel.root.activeElement !== el.posInput) el.posInput.value = Number(news.y) || 0;
    el.posOut.textContent = `${Number(news.y) || 0}%`;
    if (panel.root.activeElement !== el.headline) el.headline.value = news.headline;
    renderEffects(c);
  }

  // Cursori degli effetti: dipendono dai componenti caricati, quindi si ricostruiscono
  // quando arriva una versione nuova (senza ricaricare la pagina)
  function renderEffects(c) {
    const volto = catalog.effects.filter((e) => e.volto);
    const normali = catalog.effects.filter((e) => !e.volto);
    const sig = catalog.effects.map((e) => `${e.id}=${e.label}=${e.volto ? 1 : 0}`).join('|');
    if (sig !== panel.fxSig) {
      panel.fxSig = sig;
      panel.fxSliders = {};
      panel.faceSelect = null;
      // oggetti 3D sul volto: un solo menu (la dimensione si regola nelle impostazioni)
      const extra = [];
      if (volto.length) {
        const label = document.createElement('label');
        const row = document.createElement('div');
        row.className = 'row';
        const name = document.createElement('span');
        name.textContent = T('3D object on your face');
        row.append(name);
        const sel = document.createElement('select');
        for (const e of [{ id: '', breve: 'None' }, ...volto]) {
          const o = document.createElement('option');
          o.value = e.id;
          o.textContent = T(e.breve || e.label);
          sel.append(o);
        }
        sel.onchange = () => {
          const cur = currentConfig();
          if (!cur) return;
          const eff = { ...(cur.fx.effects || {}) };
          let dim = 50;
          for (const e of volto) { if (eff[e.id] > 0) dim = eff[e.id]; delete eff[e.id]; }
          if (sel.value) eff[sel.value] = dim;
          edit({ effects: eff });
        };
        label.append(row, sel);
        panel.faceSelect = sel;
        extra.push(label);
      }
      panel.els.fxBox.replaceChildren(...extra, ...normali.map((e) => {
        const label = document.createElement('label');
        const row = document.createElement('div');
        row.className = 'row';
        const name = document.createElement('span');
        name.textContent = T(e.label);
        const out = document.createElement('output');
        row.append(name, out);
        const input = document.createElement('input');
        input.type = 'range';
        input.min = 0;
        input.max = 100;
        input.oninput = () => {
          const cur = currentConfig();
          if (!cur) return;
          out.textContent = `${input.value}%`;
          edit({ effects: { ...(cur.fx.effects || {}), [e.id]: Number(input.value) } });
        };
        label.append(row, input);
        panel.fxSliders[e.id] = { input, out };
        return label;
      }));
    }
    const values = c.fx.effects || {};
    if (panel.faceSelect && panel.root.activeElement !== panel.faceSelect) {
      const scelto = volto.find((e) => (Number(values[e.id]) || 0) > 0);
      panel.faceSelect.value = scelto ? scelto.id : '';
    }
    for (const [id, s] of Object.entries(panel.fxSliders)) {
      const v = Number(values[id]) || 0;
      if (panel.root.activeElement !== s.input) s.input.value = v;
      s.out.textContent = `${v}%`;
    }
  }
})();
