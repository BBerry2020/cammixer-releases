/*
 * CamMixer - script nel contesto del sito
 * Aggiunge le webcam virtuali all'elenco delle fotocamere e, quando il sito
 * ne chiede una (o la fotocamera predefinita), restituisce il video elaborato.
 */
(() => {
  'use strict';
  if (window.__webcamVirtualiPage) return;
  Object.defineProperty(window, '__webcamVirtualiPage', { value: true });
  if (typeof MediaDevices === 'undefined' || !navigator.mediaDevices) return; // pagina non sicura (http)

  const C = WebcamVirtualiCore;
  const T = C.T;   // messaggi nella lingua scelta (lingua.js)
  const TAG = '__webcamVirtuali';
  const md = navigator.mediaDevices;
  const proto = MediaDevices.prototype;
  const nativeGetUserMedia = proto.getUserMedia;
  const nativeEnumerateDevices = proto.enumerateDevices;

  const env = {
    getUserMedia: (c) => nativeGetUserMedia.call(md, c),
    enumerateDevices: () => nativeEnumerateDevices.call(md),
    onChange: () => notifyActive()
  };

  let state = null;
  let base = '';
  let resolveState;
  const stateReady = new Promise((r) => { resolveState = r; });
  const vcams = new Map();   // id -> VCam (creata al primo uso)
  const users = new Map();   // id -> tracce consegnate al sito e non ancora fermate
  let modelWaiters = [];
  let loaderWaiters = [];

  const post = (m) => window.postMessage({ [TAG]: 'page', ...m }, '*');

  function waitState(ms) {
    if (state) return Promise.resolve(state);
    return Promise.race([stateReady, new Promise((r) => setTimeout(() => r(null), ms))]);
  }

  // --- Stato dall'estensione -------------------------------------------

  function applyState(s, b) {
    C.setLingua(s && s.lingua);   // testi sul video e messaggi nella lingua scelta
    state = C.normalizeState(s);
    if (typeof b === 'string' && b.startsWith('chrome-extension://')) base = b;
    C.setBase(base);
    C.setEsempi3D(state.esempi3d);
    const ids = new Set(state.vcams.map((c) => c.id));
    for (const [id, v] of vcams) {
      if (ids.has(id)) continue;
      if (registratore.info.vcamId === id) registratore.ferma('fine');
      v.stop(false);
      vcams.delete(id);
    }
    for (const c of state.vcams) { const v = vcams.get(c.id); if (v) v.update(c); }
    resolveState(state);
    notifyActive();
  }

  function getVcam(id) {
    let v = vcams.get(id);
    if (!v) {
      const c = state && state.vcams.find((x) => x.id === id);
      if (!c) return null;
      v = new C.VCam(c, env);
      vcams.set(id, v);
    }
    return v;
  }

  window.addEventListener('message', (e) => {
    if (e.source !== window || !e.data || e.data[TAG] !== 'ext') return;
    const m = e.data;
    if (m.type === 'state') {
      applyState(m.state, m.base);
      postCatalog();
    } else if (m.type === 'loader') {
      const waiting = loaderWaiters;
      loaderWaiters = [];
      for (const w of waiting) {
        if (m.ok) w.resolve();
        else w.reject(new Error(m.error || T('MediaPipe loader not available')));
      }
    } else if (m.type === 'rec-avvia') {
      avviaRegistrazione(m);
    } else if (m.type === 'rec-ferma') {
      registratore.ferma();
    } else if (m.type === 'rec-foto') {
      const v = typeof m.id === 'string' && (users.get(m.id) || 0) > 0 ? vcams.get(m.id) : null;
      if (!v) return post({ type: 'rec-errore', codice: 'spenta' });
      R.foto(v).then((f) => post({ type: 'rec-file', file: { blob: f.blob, nome: f.nome, tipo: 'foto', byte: f.byte } }))
        .catch((e) => post({ type: 'rec-errore', codice: 'foto', errore: String((e && (e.message || e.name)) || e) }));
    } else if (m.type === 'model') {
      const nome = m.modello === 'volto' ? 'volto' : 'ritaglio';
      const waiting = modelWaiters.filter((w) => w.nome === nome);
      modelWaiters = modelWaiters.filter((w) => w.nome !== nome);
      for (const w of waiting) {
        if (m.buffer) w.resolve(new Uint8Array(m.buffer));
        else w.reject(new Error(m.error || T('model not available')));
      }
    }
  });

  // --- Registrazione e foto, comandate dal pannello -----------------------
  // Si registra l'uscita della webcam virtuale in uso; il file passa al pannello
  // (contesto isolato dell'estensione), che lo salva nei download.
  const R = C.registrazione;
  const registratore = new R.Registratore({
    onChange: (i) => post({ type: 'rec-stato', info: i }),
    onFile: (f) => post({ type: 'rec-file', file: { blob: f.blob, nome: f.nome, tipo: 'video', durata: f.durata, byte: f.byte,
      motivo: f.motivo, senzaAudio: f.senzaAudio, errore: f.errore ? String(f.errore.message || f.errore.name || f.errore) : '' } }),
    onError: (e) => post({ type: 'rec-errore', codice: 'video', errore: String((e && (e.message || e.name)) || e) })
  });

  async function avviaRegistrazione(m) {
    if (registratore.attivo) return post({ type: 'rec-stato', info: registratore.info });
    const v = typeof m.id === 'string' && (users.get(m.id) || 0) > 0 ? vcams.get(m.id) : null;
    if (!v) return post({ type: 'rec-errore', codice: 'spenta' });
    const opzioni = R.normalizza(m.opzioni);
    let audio = null;
    if (opzioni.audio) {
      try {
        audio = await nativeGetUserMedia.call(md, { audio: { echoCancellation: true, noiseSuppression: true } });
      } catch (e) {
        post({ type: 'rec-errore', codice: 'microfono', errore: String((e && (e.message || e.name)) || e) });
      }
    }
    try {
      registratore.avvia(v, opzioni, audio);
    } catch (e) {
      post({ type: 'rec-errore', codice: 'avvio', errore: String((e && (e.message || e.name)) || e) });
    }
  }

  // Ritaglio: la libreria è nell'estensione, il modello lo procura l'estensione
  C.setSegmentationProvider(async (nome = 'ritaglio') => {
    if (!base) throw new Error(T('extension not reachable'));
    const vision = await import(`${base}mediapipe/vision_bundle.mjs`);
    const model = await new Promise((resolve, reject) => {
      modelWaiters.push({ nome, resolve, reject });
      post({ type: 'need-model', modello: nome });
      setTimeout(() => reject(new Error(T('model not received'))), 60000);
    });
    // Il caricatore di MediaPipe (ModuleFactory) lo inietta l'estensione: MediaPipe altrimenti
    // aggiungerebbe un <script>, bloccato nei siti con Trusted Types o CSP severe (es. Teams sul web).
    const prepara = () => new Promise((resolve, reject) => {
      loaderWaiters.push({ resolve, reject });
      post({ type: 'need-loader' });
      setTimeout(() => reject(new Error(T('MediaPipe loader not received'))), 30000);
    });
    const fileset = { wasmLoaderPath: '', wasmBinaryPath: `${base}mediapipe/wasm/vision_wasm_internal.wasm` };
    return { vision, model, fileset, prepara };
  });
  C.onSegChange(() => notifyActive());

  // Componenti (sfondi, effetti, animazioni): arrivano dall'estensione subito dopo
  // l'apertura della pagina e di nuovo a ogni aggiornamento, senza ricaricare nulla.
  const postCatalog = () => post({ type: 'catalog', catalog: C.catalog() });
  C.onRegistryChange(postCatalog);

  function notifyActive() {
    const active = [];
    for (const v of vcams.values()) {
      if ((users.get(v.id) || 0) > 0) active.push({ id: v.id, name: v.name, status: v.status, error: v.error });
    }
    post({ type: 'active', vcams: active, seg: { state: C.seg.state, error: C.seg.error } });
  }

  // --- Dispositivi ------------------------------------------------------

  function fakeDeviceInfo(c) {
    const P = typeof InputDeviceInfo !== 'undefined' ? InputDeviceInfo : MediaDeviceInfo;
    const info = Object.create(P.prototype);
    const props = { deviceId: c.id, kind: 'videoinput', label: c.name, groupId: 'webcam-virtuali' };
    for (const [k, v] of Object.entries(props)) Object.defineProperty(info, k, { value: v, enumerable: true });
    Object.defineProperty(info, 'toJSON', { value: () => ({ ...props }) });
    Object.defineProperty(info, 'getCapabilities', {
      value: () => ({
        deviceId: c.id, groupId: 'webcam-virtuali',
        width: { min: 1, max: 1280 }, height: { min: 1, max: 720 }, frameRate: { min: 1, max: 30 },
        aspectRatio: { min: 0.001, max: 1280 }, facingMode: [], resizeMode: ['none', 'crop-and-scale']
      })
    });
    return info;
  }

  // Fotocamere indicate dal sito nella richiesta (deviceId semplice, exact, ideal o elenco)
  function requestedIds(video) {
    if (!video || typeof video !== 'object') return [];
    let id = video.deviceId;
    if (id && typeof id === 'object' && !Array.isArray(id)) id = id.exact ?? id.ideal;
    if (id == null || id === '') return [];
    return (Array.isArray(id) ? id : [id]).map(String);
  }

  // Con una webcam virtuale "al posto della webcam reale" (defaultId) il sito riceve
  // sempre una webcam virtuale: quella che ha scelto esplicitamente, altrimenti la
  // predefinita, anche se chiede una fotocamera reale precisa (molte chat ricordano
  // l'ultima fotocamera usata e la richiedono per id).
  // Senza defaultId l'estensione è trasparente e non consegna webcam virtuali.
  function pickVcam(constraints, st) {
    const video = constraints && constraints.video;
    if (!video || !st.defaultId) return null;
    const ids = requestedIds(video);
    return st.vcams.find((x) => ids.includes(x.id)) || st.vcams.find((x) => x.id === st.defaultId) || null;
  }

  // Modalità trasparente: se il sito chiede una webcam virtuale che aveva memorizzato,
  // riceve la webcam reale predefinita invece di un errore.
  function stripVirtualIds(constraints, st) {
    const video = constraints && constraints.video;
    const ids = requestedIds(video);
    if (!ids.length || !ids.some((id) => st.vcams.some((x) => x.id === id))) return constraints;
    const { deviceId, ...rest } = video;
    return { ...constraints, video: Object.keys(rest).length ? rest : true };
  }

  // La traccia consegnata al sito: quando il sito la ferma, si spegne anche la webcam reale
  function wrapTrack(v, t) {
    users.set(v.id, (users.get(v.id) || 0) + 1);
    let released = false;
    const release = () => {
      if (released) return;
      released = true;
      const n = Math.max(0, (users.get(v.id) || 1) - 1);
      users.set(v.id, n);
      if (n === 0) {
        if (registratore.info.vcamId === v.id) registratore.ferma('fine');   // chiamata finita: il video si salva
        v.stop(true);
      }
      notifyActive();
    };
    const nativeStop = t.stop;
    const nativeSettings = t.getSettings;
    Object.defineProperty(t, 'stop', { configurable: true, value: function stop() { nativeStop.call(t); release(); } });
    Object.defineProperty(t, 'label', { configurable: true, get: () => v.name });
    Object.defineProperty(t, 'getSettings', {
      configurable: true,
      value: function getSettings() { return { ...nativeSettings.call(t), deviceId: v.id, groupId: 'webcam-virtuali' }; }
    });
    t.addEventListener('ended', release);
    return t;
  }

  // Con la sostituzione attiva il sito vede solo le webcam virtuali (la predefinita per
  // prima: alcuni siti usano la prima dell'elenco); microfoni e altoparlanti restano.
  // Senza sostituzione l'elenco è quello vero.
  proto.enumerateDevices = async function enumerateDevices() {
    const list = await nativeEnumerateDevices.call(this);
    const st = await waitState(1500);
    if (!st || !st.defaultId) return list;
    const virtual = st.vcams.map(fakeDeviceInfo);
    const def = virtual.find((d) => d.deviceId === st.defaultId);
    const others = list.filter((d) => d.kind !== 'videoinput');
    return [def, ...virtual.filter((d) => d !== def), ...others].filter(Boolean);
  };

  proto.getUserMedia = async function getUserMedia(constraints) {
    const st = await waitState(3000);
    if (!st) return nativeGetUserMedia.call(this, constraints);
    const target = pickVcam(constraints, st);
    const v = target && getVcam(target.id);
    if (!v) return nativeGetUserMedia.call(this, stripVirtualIds(constraints, st));
    await C.whenComponents(1500);
    await v.ensure();
    const stream = new MediaStream();
    for (const t of v.outStream.getVideoTracks()) stream.addTrack(wrapTrack(v, t.clone()));
    if (constraints.audio) {
      try {
        const a = await nativeGetUserMedia.call(this, { audio: constraints.audio });
        a.getAudioTracks().forEach((t) => stream.addTrack(t));
      } catch (e) {
        stream.getTracks().forEach((t) => t.stop());
        throw e;
      }
    }
    notifyActive();
    return stream;
  };

  // Vecchie API a callback
  for (const k of ['getUserMedia', 'webkitGetUserMedia']) {
    if (typeof navigator[k] === 'function') {
      navigator[k] = function (c, ok, ko) { md.getUserMedia(c).then(ok, ko); };
    }
  }

  post({ type: 'hello' });   // il ponte risponde con le impostazioni
  // Il ponte chiede i componenti appena parte; se la risposta è arrivata prima di questo
  // script (o è andata persa) li si richiede.
  setTimeout(() => { if (!C.catalog().loaded) post({ type: 'need-components' }); }, 800);
  setTimeout(() => { if (!C.catalog().loaded) post({ type: 'need-components' }); }, 3000);
})();
